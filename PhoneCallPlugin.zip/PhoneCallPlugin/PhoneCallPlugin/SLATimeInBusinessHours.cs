﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using Microsoft.Xrm.Sdk;
using System.ServiceModel.Description;
using Microsoft.Xrm.Sdk.Client;
using Microsoft.Crm.Sdk.Messages;
using Microsoft.Xrm.Sdk.Query;

namespace AskHRCRM.Plugin.PhoneCallPlugIn
{
    public class SLATimeInBusinessHours
    {
        public double RetrieveSLArecord(IOrganizationService service, DateTime STARTTIME, DateTime ENDTIME, Guid SLAId)
        {
            double totaltime = 0;
            try
            {
                if (SLAId != Guid.Empty)
                {
                    Entity sla = (Entity)service.Retrieve("sla", SLAId, new ColumnSet(true));
                    if (sla != null && sla.Attributes.Contains("businesshoursid"))
                    {
                        Guid slaitemid = sla.Id;
                        int timezonecode = -1;
                        EntityReference calendar = (EntityReference)sla.Attributes["businesshoursid"];
                        Entity BusinessHourCalendar = service.Retrieve("calendar", calendar.Id, new ColumnSet(true));
                        if (BusinessHourCalendar != null)
                        {
                            //Added to get default calendar

                            var closures = BusinessHourCalendar.GetAttributeValue<EntityCollection>("calendarrules");
                            if (closures != null && closures[0].Contains("timezonecode"))
                                timezonecode = (int)closures[0]["timezonecode"];
                            TimeZoneInfo tt = GetTimeZone(service, timezonecode);

                            DateTime NewStartTime = tt != null ? TimeZoneInfo.ConvertTimeFromUtc(STARTTIME, tt) : STARTTIME;
                            DateTime NewEndTime = tt != null ? TimeZoneInfo.ConvertTimeFromUtc(ENDTIME, tt) : ENDTIME;

                            var workingHours = GetWorkingHours(service, calendar);

                            Console.WriteLine("StartTime:{0}-EndTime:{1}", NewStartTime, NewEndTime);

                            //-------------------- All dates collection start -----------------------//
                            var listAllDatesCollection = new List<DateTime>();
                            for (var date = NewStartTime.Date; date <= NewEndTime.Date; date = date.AddDays(1))
                            {
                                listAllDatesCollection.Add(date.Date);
                            }
                            //-------------------- All dates collection end -----------------------//

                            //---------------------Holiday collection start -----------------------//
                            EntityCollection HolidayRecords = new EntityCollection();
                            var listHolidayDates = new List<DateTime>();
                            if (BusinessHourCalendar.Contains("holidayschedulecalendarid"))
                            {
                                Entity holiDay = service.Retrieve("calendar", ((EntityReference)BusinessHourCalendar["holidayschedulecalendarid"]).Id, new ColumnSet(true));
                                if (holiDay != null)
                                {
                                    var holidayCalendarDB = GetHolidayCalenderDetail(service, holiDay.Attributes["name"].ToString());
                                    if (holidayCalendarDB != null && holidayCalendarDB.Count() > 0)
                                    {
                                        foreach (var entityItem in holidayCalendarDB)
                                        {
                                            HolidayRecords.Entities.Add(entityItem);
                                        }

                                        for (int j = 0; j < HolidayRecords.Entities.Count; j++)
                                        {
                                            for (DateTime dt = Convert.ToDateTime(HolidayRecords.Entities[j].Attributes["starttime"]);
                                                dt < Convert.ToDateTime(HolidayRecords.Entities[j].Attributes["effectiveintervalend"]); dt = dt.AddDays(1))
                                            {
                                                if (dt.Date >= NewStartTime.Date && dt.Date <= NewEndTime.Date)
                                                {
                                                    //from the collection get the range of the startdate and enddate
                                                    listHolidayDates.Add(dt.Date);
                                                }
                                            }
                                        }
                                    }
                                }
                            }
                            //---------------------Holiday collection End ----------------------//

                            //-------------------Weekend collection Start ------------------------//
                            var listWeekends = new List<DateTime>();
                            listWeekends = GetWeekendList(NewStartTime, NewEndTime, closures);
                            //-------------------Weekend collection End   ------------------------//
                            //-------------------Merge Holiday and weekends start ----------------------//
                            listHolidayDates.AddRange(listWeekends);
                            //-------------------Merge Holiday and weekends End ------------------------//
                            //--------Get the difference from the merge list to all the date range start ---------//
                            var listWorkingDays = listAllDatesCollection.Except(listHolidayDates);
                            //--------Get the difference from the merge list to all the date range end  ----------//

                            if (listWorkingDays.Count() > 0)
                            {
                                double firstDayTime = 0;
                                double endDayTime = 0;
                                double dayDiff = 0;
                                int count = 0;
                                double calculateFinalTimeSpan = 0;

                                var NewStartTimeInMinutes = NewStartTime.Subtract(new DateTime(NewStartTime.Year, NewStartTime.Month, NewStartTime.Day, 0, 0, 0)).TotalMinutes;
                                var NewEndTimeInMinutes = NewEndTime.Subtract(new DateTime(NewEndTime.Year, NewEndTime.Month, NewEndTime.Day, 0, 0, 0)).TotalMinutes;

                                foreach (var item in listWorkingDays)
                                {
                                    //v-degort: updated for production bug -- 2368731 -- changed first to first or default
                                    var workingHour = workingHours.Where(x => x.ApplicableDaysOfWeek.Contains(item.DayOfWeek)).FirstOrDefault();
                                    //v-degort: updated for production bug -- 2368731 -- start
                                    if (workingHour != null)
                                    {
                                        //v-degort: updated for production bug -- 2368731 -- end
                                        int StartTime = workingHour.StartTimeInMinutes;
                                    int EndTime = workingHour.EndTimeInMinutes;
                                    int WorkDuration = workingHour.Duration;
                                    //Same day calculation
                                    if ((item.Date).Equals(NewStartTime.Date) && (item.Date).Equals(NewEndTime.Date))
                                    {
                                        count += 1;
                                        //Started and end in business hour
                                        if (NewStartTimeInMinutes >= StartTime && NewEndTimeInMinutes < EndTime) // 8 to 17
                                        {
                                            calculateFinalTimeSpan = NewEndTimeInMinutes - NewStartTimeInMinutes;
                                        }
                                        //Start time before business hour
                                        else if (NewStartTimeInMinutes < StartTime)
                                        {
                                            //End time between business hours
                                            if (NewEndTimeInMinutes >= StartTime && NewEndTimeInMinutes < EndTime)
                                            {
                                                calculateFinalTimeSpan = NewEndTimeInMinutes - StartTime;
                                            }
                                            //Endtime after business hour
                                            else if (NewEndTimeInMinutes > EndTime)
                                            {
                                                calculateFinalTimeSpan = WorkDuration;
                                            }
                                        }
                                        //Started in business hour
                                        else if (NewStartTimeInMinutes >= StartTime && NewStartTimeInMinutes < EndTime)
                                        {
                                            //End time after business hour
                                            if (NewEndTimeInMinutes > EndTime)
                                            {
                                                calculateFinalTimeSpan = EndTime - NewStartTimeInMinutes;
                                            }
                                        }
                                        //Started and ended before business hour or Started and ended after business hour
                                        else if ((NewStartTimeInMinutes < StartTime && NewEndTimeInMinutes < StartTime)
                                                    || (NewStartTimeInMinutes > EndTime && NewEndTimeInMinutes > EndTime))
                                        {
                                            calculateFinalTimeSpan = 0;
                                        }
                                    }
                                    //Different day calculation
                                    else if ((item.Date).Equals(NewStartTime.Date))
                                    {
                                        count += 1;
                                        if (NewStartTimeInMinutes < StartTime)
                                        {
                                            firstDayTime = WorkDuration;
                                        }
                                        else if (NewStartTimeInMinutes >= StartTime && NewStartTimeInMinutes < EndTime)
                                        {
                                            firstDayTime = EndTime - NewStartTimeInMinutes; ;
                                        }
                                        else if (NewStartTimeInMinutes > EndTime)
                                        {
                                            firstDayTime = 0;
                                        }
                                    }
                                    //---------------------------First Day Work Calculation End-------------------------------------//

                                    //---------------------------Last Day Work Calculation Start-------------------------------------//
                                    else if ((item.Date).Equals(NewEndTime.Date))
                                    {
                                        count += 1;
                                        if (NewEndTimeInMinutes < StartTime)
                                        {
                                            endDayTime = 0;
                                        }
                                        else if (NewEndTimeInMinutes >= StartTime && NewEndTimeInMinutes < EndTime)
                                        {
                                            endDayTime = NewEndTimeInMinutes - StartTime;
                                        }
                                        else if (NewEndTimeInMinutes > EndTime)
                                        {
                                            endDayTime = WorkDuration;
                                        }
                                    }
                                    //In between days
                                    else
                                    {
                                        dayDiff += WorkDuration;
                                    }
                                }
                                totaltime = calculateFinalTimeSpan + firstDayTime + endDayTime + dayDiff;
                                totaltime = convert(totaltime);
                            }
                            //v-degort: updated for production bug -- 2368731 -- start
                        }
                        //v-degort: updated for production bug -- 2368731 -- end
                    }
                }
                    else
                    {
                        totaltime = convert(ENDTIME.Subtract(STARTTIME).TotalMinutes);
                    }
                }
            }
            catch (Exception ex)
            {
                throw ex;
            }
            return totaltime;
        }

        public List<DateTime> GetWeekendList(DateTime startDate, DateTime endDate, EntityCollection calendarRules)
        {
            List<DayOfWeek> NonWorkingDays = new List<DayOfWeek>();
            List<DayOfWeek> WorkingDays = new List<DayOfWeek>();
            List<DateTime> weekendList = new List<DateTime>();
            for (int i = 0; i < calendarRules.Entities.Count; i++)
            {
                if (calendarRules[i].Attributes.Contains("pattern") && calendarRules[i].Attributes["pattern"].ToString().Contains("BYDAY="))
                {
                    WorkingDays.AddRange(GetDayOfWeekFromPattern(calendarRules[i].Attributes["pattern"].ToString()));
                }
            }

            for (DateTime dt = startDate; dt <= endDate; dt = dt.AddDays(1.0))
            {
                if (!WorkingDays.Contains(dt.DayOfWeek))
                {
                    weekendList.Add(dt.Date);
                }
            }
            return weekendList;
        }

        public double convert(double mins)
        {
            int intHours = (int)(mins / 60);
            int intMinutes = (int)Math.Round(mins % 60);
            // int intMinutes = (int)(mins % 60);
            string strMinutes = intMinutes.ToString();
            strMinutes = (intMinutes * 10 / 6).ToString();
            if (int.Parse(strMinutes) < 10)
            {
                strMinutes = string.Format("0{0}", strMinutes);
            }
            string strConvertedTime = string.Concat(intHours, ".", strMinutes);
            return Convert.ToDouble(strConvertedTime);
        }

        public TimeZoneInfo GetTimeZone(IOrganizationService service, int crmTimeZoneCode)
        {
            var qe = new QueryExpression("timezonedefinition");
            qe.ColumnSet = new ColumnSet("standardname");
            qe.Criteria.AddCondition("timezonecode", ConditionOperator.Equal, crmTimeZoneCode);
            return TimeZoneInfo.FindSystemTimeZoneById(service.RetrieveMultiple(qe).Entities.First().Attributes["standardname"].ToString());
        }

        public IEnumerable<Entity> GetHolidayCalenderDetail(IOrganizationService service, String calendarName)
        {
            QueryExpression cal = new QueryExpression("calendar") { ColumnSet = { AllColumns = true } };
            cal.Criteria.AddCondition("name", ConditionOperator.Equal, calendarName);
            var holidayCalendars = service.RetrieveMultiple(cal);
            Entity holidayCalendar = holidayCalendars != null && holidayCalendars.Entities != null && holidayCalendars.Entities.Count > 0
                ? (holidayCalendars.Entities.Count > 0 && holidayCalendars.Entities.Count(hc => hc.Attributes.Contains("type")) > 0 && holidayCalendars.Entities.Count(hc => (hc.Attributes["type"] as OptionSetValue).Value == 2) > 0)
                    ? holidayCalendars.Entities.Where(hc => (hc.Attributes["type"] as OptionSetValue).Value == 2).First() : null
                : null;
            //Entity holidayCalendar = holidayCalendars != null && holidayCalendars.Entities != null && holidayCalendars.Entities.Count > 0
            //    ? holidayCalendars.Entities.Count == 1 ? holidayCalendars.Entities[0] : holidayCalendars.Entities[1]
            //    : null;
            if (holidayCalendar != null)
            {
                return holidayCalendar.GetAttributeValue<EntityCollection>("calendarrules").Entities;
            }
            return null;
        }

        /// <summary>
        /// All times in minutes
        /// </summary>
        /// <param name="service"></param>
        /// <param name="busHour"></param>
        /// <returns></returns>
        public List<WorkingHours> GetWorkingHours(IOrganizationService service, EntityReference busHour)
        {
            var workingHours = new List<WorkingHours>();
            Entity BusinessHourCalendar = service.Retrieve("calendar", busHour.Id, new ColumnSet(true));
            EntityCollection closures = BusinessHourCalendar.GetAttributeValue<EntityCollection>("calendarrules");
            foreach (var closure in closures.Entities)
            {
                Entity innerCal = service.Retrieve("calendar", ((EntityReference)closure["innercalendarid"]).Id, new ColumnSet(true));
                Entity workhour = innerCal.GetAttributeValue<EntityCollection>("calendarrules").Entities[0];
                int startHour = (int)workhour["offset"]; //8am
                int duration = (int)workhour["duration"]; //9 hours
                int endHour = startHour + duration; //5pm
                var workingHour = new WorkingHours();
                workingHour.Duration = (int)workhour["duration"];
                workingHour.StartTimeInMinutes = (int)workhour["offset"];
                workingHour.EndTimeInMinutes = workingHour.StartTimeInMinutes + workingHour.Duration;
                workingHour.ApplicableDaysOfWeek = GetDayOfWeekFromPattern(closure.Attributes["pattern"].ToString());
                workingHours.Add(workingHour);
            }
            return workingHours;
        }

        public List<DayOfWeek> GetDayOfWeekFromPattern(string pattern)
        {
            var lstWorkingDays = new List<DayOfWeek>();
            var workingDays = pattern.Split(';')[2].Replace("BYDAY=", "").Split(',');
            if (workingDays != null)
            {
                if (workingDays.Contains("SU")) lstWorkingDays.Add(DayOfWeek.Sunday);
                if (workingDays.Contains("MO")) lstWorkingDays.Add(DayOfWeek.Monday);
                if (workingDays.Contains("TU")) lstWorkingDays.Add(DayOfWeek.Tuesday);
                if (workingDays.Contains("WE")) lstWorkingDays.Add(DayOfWeek.Wednesday);
                if (workingDays.Contains("TH")) lstWorkingDays.Add(DayOfWeek.Thursday);
                if (workingDays.Contains("FR")) lstWorkingDays.Add(DayOfWeek.Friday);
                if (workingDays.Contains("SA")) lstWorkingDays.Add(DayOfWeek.Saturday);
            }
            return lstWorkingDays;
        }
    }
    public class WorkingHours
    {
        public List<DayOfWeek> ApplicableDaysOfWeek { get; set; }
        public int Duration { get; set; }
        public int StartTimeInMinutes { get; set; }
        //public List<BreakTime> BreakTimes { get; set; }
        public int EndTimeInMinutes { get; set; }
    }

    public class BreakTime
    {
        public int BreakTimeStart { get; set; }
        public int Duration { get; set; }
        public int BreakTimeEnds { get; set; }
    }

}