﻿//============================================================================
// Copyright(c) 2010 Microsoft, Inc.
// All rights reserved.
//----------------------------------------------------------------------------
// Project: CloudCRM - HR Support
// Workfile
// Author: v-sprema
// Revision
//
// Description: Update the Update Status field, when direction is outgoing
//
// Revisions:
//	Date			Inits		      Desc
//  15/02/2012    v-sprema          original code
//  03/19/2012    v-sprema          modified code (Condition for checking whether auto generated email is present)
//  03/29/2012    v-sprema          modified code (Merging Email & Phone Call Record, Check for Record Count & Set First Response)
//  03/29/2012    v-shaimo          1. Included the logic of first,subsequent response on SLA Log when Email is sent
//                                  2. Included the logic of Response reason when closing an SLA Log        
//  04/04/2012    v-pabab           1. Included Phone Call Tier field updation on Set State Dynamic Entity
//                                  2. Create New SLA Log on Outgoing Phone Call Activity Create
//                                  3. Included tracing functionality      
//08/23/2012      v-pabab/v-sprema  Commented SLA creation for outgoing activities like email and phone call.  Refactored code.
//08/28/2012      v-pabab/v-shaimo  Added Email Flip Logic.
//09/13/2012      v-pabab/v-thamut  Modified flip logic to grant and revoke access of queue to the user
//01/16/2013      v-pabab           Refactored code (Removed Global Variables)
//01/29/2013      v-pabab           Fixed bug (#1097897: Forward Email Activity: HRwebactivity attachments are being added while forwarding the email activity.) 
//08/30/2013      v-pabab           Forwarding an already EDM Forwarded Email should not copy Attachments from the EDM Activity. 
//01/31/2014      v-geoseb          Added condition to check whether the phonecall activity is open before trying to update it
//02/19/2015      v-sivide          Modified code (Creating a new SLA logs for subsequent incoming phone call Activities) and (Closing all SLA logs for outgoing call).
//------------------------------------------------------------------------------
using System;
using System.Collections.Generic;
using Microsoft.Xrm.Sdk.Query;
using Microsoft.Xrm.Sdk;
using System.ServiceModel;
using System.Linq;
using System.Text;
using Microsoft.Crm.Sdk.Messages;
using System.Collections.Specialized;
using System.Xml;
using System.Text.RegularExpressions;
using CommonCode;

[assembly: CLSCompliant(true)]
namespace AskHRCRM.Plugin.PhoneCallPlugIn
{
    public class PhoneCallPlugIn : IPlugin
    {
        CommonCodeDraft cmncode = new CommonCodeDraft();

        #region Class Members
        bool traceEnabled = false;
        Guid ccrmfbUserID = Guid.Empty;
        Guid ccrmfbCustomerID = Guid.Empty;
        #endregion

        # region Class Variables getting deallocated in finally block

        bool IncludesHoliday = false;
        bool IncludesWeekEnd = false;

        # endregion

        #region Constructor
        public PhoneCallPlugIn(string unsecureConfig, string secureConfig)
        {
            XmlDocument doc = new XmlDocument();
            doc.LoadXml(unsecureConfig);
            traceEnabled = (bool)PluginConfiguration.GetConfigDataBool(doc, "TraceEnabled");
            ccrmfbUserID = (Guid)PluginConfiguration.GetConfigDataGuid(doc, "ccrmfbUserGuid");
            ccrmfbCustomerID = (Guid)PluginConfiguration.GetConfigDataGuid(doc, "ccrmfbCustomerGuid");
        }
        #endregion

        #region Execute Method
        public void Execute(IServiceProvider serviceProvider)
        {
            ITracingService tracingService = (ITracingService)serviceProvider.GetService(typeof(ITracingService));
            if (tracingService == null)
                throw new InvalidPluginExecutionException("Failed to Retrieve Tracing service");

            lock (this)
            {
                string strMessage = string.Empty;

                try
                {
                    if (traceEnabled)
                    {
                        tracingService.Trace(string.Concat("Plugin_UpdateEmailPhonePlugIn", "Entered Execute Method", DateTime.Now.ToString(), "Information"));
                    }

                    if (serviceProvider == null)
                        throw new ArgumentNullException("serviceProvider");

                    Guid userId = Guid.Empty;
                    IOrganizationService _iOrgService = null;
                    int countOfRecord = 0;

                    IPluginExecutionContext _context = (IPluginExecutionContext)serviceProvider.GetService(typeof(IPluginExecutionContext));
                    IOrganizationServiceFactory _factory = (IOrganizationServiceFactory)serviceProvider.GetService(typeof(IOrganizationServiceFactory));
                    _iOrgService = _factory.CreateOrganizationService(_context.UserId);

                    userId = _context.UserId;

                    //Throw exception if unable to create IOrganizationService.
                    if (_iOrgService == null)
                        throw new InvalidPluginExecutionException("Unable to create IOrganizationService.");


                    #region Phone Call Activity SETSTATEDYNAMICENTITY message
                    //Close existing SLAs and update the Response field of SLAs and Tier field of Phone Call Activity
                    else if (_context.MessageName.ToUpperInvariant() == "SETSTATEDYNAMICENTITY")
                    {

                        //If the entity is phonecall
                        if (_context.PrimaryEntityName.ToUpperInvariant() == "PHONECALL")
                        {
                            if (traceEnabled)
                            {
                                tracingService.Trace(string.Concat("Plugin_UpdateEmailPhonePlugIn", "Entered SetStateDynamicEntity Step ", DateTime.Now.ToString(), "Information"));
                            }

                            #region PreOperation
                            //Check whether PreEntityImages is null & it contains the pre image
                            if (_context.PreEntityImages != null && _context.PreEntityImages.Contains("PreImage") && _context.PreEntityImages["PreImage"] is Entity)
                            {
                                Entity _preImageEntity = (Entity)_context.PreEntityImages["PreImage"];
                                bool direction = (bool)_preImageEntity["directioncode"];

                                //Check if the activity is in Open state before updating the record
                                if (_preImageEntity.Attributes.Contains("statecode") && ((OptionSetValue)_preImageEntity.Attributes["statecode"]).Value == 0)
                                {
                                    //Modified in Release-8 Check whether direction field is outgoing, if it true then close all existing SLA logs
                                    if (_preImageEntity.Contains("regardingobjectid") && _preImageEntity.Contains("directioncode") && (bool)_preImageEntity["directioncode"])
                                    {
                                        EntityReference regardobjectforMarkComplete = (EntityReference)_preImageEntity["regardingobjectid"];

                                        if (regardobjectforMarkComplete != null && regardobjectforMarkComplete.LogicalName == "incident")
                                        {
                                            //Get the Tier value from Case and assign it to the Phone Call Activity, added by v-pabab
                                            Entity caseObject = null;
                                            int tierValue = 0;

                                            caseObject = (Entity)_iOrgService.Retrieve("incident", regardobjectforMarkComplete.Id, new ColumnSet("new_assignedto"));

                                            if (caseObject != null)
                                            {
                                                if (caseObject.Attributes.Contains("new_assignedto"))
                                                    tierValue = ((OptionSetValue)caseObject.Attributes["new_assignedto"]).Value;

                                                if (tierValue != 0)
                                                {
                                                    _preImageEntity["new_casephonetier"] = new OptionSetValue(tierValue);
                                                }
                                            }

                                            countOfRecord = GetRecordCount(((EntityReference)_preImageEntity.Attributes["regardingobjectid"]).Id, _iOrgService, tracingService);
                                            if (countOfRecord == 1)
                                            {
                                                //1 = First Response
                                                _preImageEntity["scrum4_response"] = new OptionSetValue(1);
                                                //     _service.Update(_preImageEntity);
                                                cmncode.CloseExistingSLALogs(regardobjectforMarkComplete.Id, 2, userId, _iOrgService, tracingService, false);
                                            }
                                            else if (countOfRecord > 1)
                                            {
                                                //2 = SubSequent Response
                                                _preImageEntity["scrum4_response"] = new OptionSetValue(2);
                                                //     _service.Update(_preImageEntity);
                                                cmncode.CloseExistingSLALogs(regardobjectforMarkComplete.Id, 2, userId, _iOrgService, tracingService, false);
                                            }
                                            _iOrgService.Update(_preImageEntity);
                                        }
                                    }
                                    //Creating a new SLA logs for incoming phone call Activity. Added by v-sivide in Release-8
                                    else if (_preImageEntity.Contains("regardingobjectid") && _preImageEntity.Contains("directioncode") && !((bool)_preImageEntity["directioncode"]))
                                    {
                                        // v-degort : Move this code to single function
                                        if (_preImageEntity.Contains("release8_iscloned") && (bool)_preImageEntity.Attributes["release8_iscloned"])
                                        {
                                            return;
                                        }
                                        CheckSLALogCreation(userId, _iOrgService, _preImageEntity, tracingService);
                                    }
                                }
                            }
                            #endregion

                            #region Post StateChange Operation 

                            //added by v-dimish as part of SLA First Response functionality
                            // Update FirstResponseSent field of Case entity when an outgoing phone call record is created for that case in CRM
                            try
                            {
                                if (_context.Stage == 40 && _context.Depth == 1)// For Post SETSTATEDYNAMICENTITY message
                                {
                                    EntityReference regardingObjectid = null;
                                    Entity caseRetrieved = null;
                                    Entity phoneCallResponsePost = null;

                                    if (_context.PostEntityImages != null && _context.PostEntityImages.Contains("postImagePhoneCall") && _context.PostEntityImages["postImagePhoneCall"] is Entity)
                                    {
                                        phoneCallResponsePost = (Entity)_context.PostEntityImages["postImagePhoneCall"];

                                        //if isworkflowcreated field of Phone Call is no
                                        if (phoneCallResponsePost != null && phoneCallResponsePost.Id != Guid.Empty && (((OptionSetValue)phoneCallResponsePost["statecode"]).Value == 1) && (((OptionSetValue)phoneCallResponsePost["statuscode"]).Value == 2) && phoneCallResponsePost.Attributes.Contains("isworkflowcreated") && phoneCallResponsePost.Attributes.Contains("modifiedon") && phoneCallResponsePost.Attributes.Contains("regardingobjectid") && phoneCallResponsePost.Attributes.Contains("directioncode") && !Convert.ToBoolean(phoneCallResponsePost.Attributes["isworkflowcreated"]))
                                        {
                                            if (traceEnabled)
                                                tracingService.Trace("First Response Sent PhoneCall - isworkflowcreated field of Phone Call is no");

                                            bool directionOfPhoneCallPost = (bool)phoneCallResponsePost["directioncode"];
                                            if (directionOfPhoneCallPost)// if phone call is Outgoing (true)
                                            {

                                                //Guid fromUserId = ((EntityReference)((EntityCollection)phoneCallResponsePost["from"]).Entities[0].Attributes["partyid"]).Id;
                                                //tracingService.Trace("6afrom: " + fromUserId + " cui: " + ccrmfbUserID + " cci: " + ccrmfbCustomerID);
                                                //if (fromUserId != Guid.Empty && fromUserId != ccrmfbUserID && fromUserId != ccrmfbCustomerID)// if from is not ccrmfb account


                                                regardingObjectid = (EntityReference)phoneCallResponsePost["regardingobjectid"];
                                                //if Regarding of phone call is Case entity
                                                if (regardingObjectid != null && regardingObjectid.Id != Guid.Empty && regardingObjectid.LogicalName.ToString().ToUpper() == "INCIDENT")
                                                {
                                                    if (traceEnabled)
                                                        tracingService.Trace("First Response Sent Phone - RegardingObjectID of EMail: " + regardingObjectid.Id);
                                                 
                                                    caseRetrieved = _iOrgService.Retrieve("incident", regardingObjectid.Id, new ColumnSet(new string[] {"title","rel13_ownerchangedate", "rel13_actualfirstresponsetime", "slaid", "new_currentqueue", "firstresponsesent", "scrum9_manual", "rel13_actualfirstresponsetime", "rel13_firstreplyqueue", "createdon", "statecode" }));
                                                    string caseTitle = "";
                                                    if (caseRetrieved.Attributes.Contains("title"))
                                                    {
                                                        caseTitle = caseRetrieved["title"].ToString();
                                                    }                                                
                                                    var caseStatus = ((OptionSetValue)caseRetrieved["statecode"]).Value;
                                                    if (traceEnabled)
                                                        tracingService.Trace("caseTitle: "+ caseTitle +" First Response Sent Phone - Case Status: " + caseStatus + " caseRetrieved.Attributes.Containsrel13_ownerchangedate: " + caseRetrieved.Attributes.Contains("rel13_ownerchangedate"));
                                                    if (caseRetrieved.Attributes.Contains("rel13_ownerchangedate") && (caseStatus == 0) && !((bool)caseRetrieved["scrum9_manual"]) && !((bool)caseRetrieved["firstresponsesent"]))// Update FirstResponseSent field of Case entity only for Active non manual cases containing ownerchange timeif FirstResponseSent was earlier no. First Response sent is false (0) for No and true for yes
                                                    {
                                                        if (traceEnabled)
                                                            tracingService.Trace("First Response Sent Phone - Case RetrievedID: " + caseRetrieved.Id);
                                                        //Update Case with the KPI Details (Total business hours, Absolute Hours, KPI Met) for First Response Sent 
                                                        OnUpdateFirstResponseSent(tracingService, _iOrgService, _context, caseRetrieved, phoneCallResponsePost);
                                                    }
                                                }

                                            }
                                        }
                                    }
                                }
                            }
                            catch (Exception ex)
                            {
                                tracingService.Trace("FirstResponsePhone: {0}", ex.ToString());
                                throw;
                            }

                            #endregion
                        }
                    }
                    #endregion

                    #region Phone Call Activity Create message

                    else if (_context.MessageName.ToUpperInvariant() == "CREATE")
                    {
                        if (traceEnabled)
                        {
                            tracingService.Trace(string.Concat("Plugin_UpdateEmailPhonePlugIn", "Entered Create Step", DateTime.Now.ToString(), "Information"));

                            //LogEvent("CloudCRM_HRSupport_UpdateEmailPhonePlugInClass", "Entered Create Step", System.Diagnostics.EventLogEntryType.Information);
                        }

                        if (_context.PrimaryEntityName.ToLower() == "phonecall")
                        {
                            //Check whether PostImage is null 
                            if (_context.PostEntityImages != null && _context.PostEntityImages.Contains("PostImagePhoneCallCreate") && _context.PostEntityImages["PostImagePhoneCallCreate"] is Entity)
                            {
                                Entity _postImageEntity = (Entity)_context.PostEntityImages["PostImagePhoneCallCreate"];
                                Entity retrievedPhoneEnt = null;

                                if (_postImageEntity.Id != Guid.Empty)
                                {
                                    retrievedPhoneEnt = _iOrgService.Retrieve("phonecall", _postImageEntity.Id, new ColumnSet("statecode"));
                                }
                                //check if the phonecall activity is not already closed before trying to update it
                                if (retrievedPhoneEnt != null && retrievedPhoneEnt.Attributes.Contains("statecode") && retrievedPhoneEnt["statecode"].Equals(new OptionSetValue(0)))
                                {
                                    //bool direction = (bool)_postImageEntity["directioncode"];                            
                                    //Check whether direction field is outgoing, if it true then update the update status field with yes value
                                    if (_postImageEntity.Contains("regardingobjectid") && _postImageEntity.Contains("directioncode") && (bool)_postImageEntity["directioncode"])
                                    {
                                        EntityReference regardobjofphoneforSave = (EntityReference)_postImageEntity["regardingobjectid"];

                                        if (regardobjofphoneforSave != null && regardobjofphoneforSave.LogicalName == "incident")
                                        {
                                            countOfRecord = GetRecordCount(((EntityReference)_postImageEntity.Attributes["regardingobjectid"]).Id, _iOrgService, tracingService);
                                            if (countOfRecord == 1)
                                            {
                                                //1 = First Response
                                                _postImageEntity["scrum4_response"] = new OptionSetValue(1);
                                                _iOrgService.Update(_postImageEntity);
                                                //1-Email, 2-Phone Call, 3-Owner Change, 4-Resolved Case, 5-No Action Required
                                                cmncode.CloseExistingSLALogs(regardobjofphoneforSave.Id, 2, userId, _iOrgService, tracingService, false);
                                            }
                                            else if (countOfRecord > 1)
                                            {
                                                //2 = SubSequent Response
                                                _postImageEntity["scrum4_response"] = new OptionSetValue(2);
                                                _iOrgService.Update(_postImageEntity);
                                                //1-Email, 2-Phone Call, 3-Owner Change, 4-Resolved Case, 5-No Action Required
                                                cmncode.CloseExistingSLALogs(regardobjofphoneforSave.Id, 2, userId, _iOrgService, tracingService, false);
                                            }

                                            #region Commented Code in Scrum 5
                                            //Commented as part of requirement in Scrum 5, v-pabab, VSTF ID 993044
                                            //Entity caseObject = null;

                                            //caseObject = RetrieveEntityDetails(regardobjofphoneforSave.Id, "incident", new ColumnSet("ownerid", "new_currentqueue", "new_lob", "scrum4_caseorigin", "new_queuenameid"), _iOrgService);

                                            //if (caseObject != null) {
                                            //    int lob = 0;
                                            //    EntityReference owner = null;
                                            //    EntityReference queueName = null;
                                            //    EntityReference originatingQueue = null;

                                            //    if (caseObject.Attributes.Contains("new_lob"))
                                            //        lob = ((OptionSetValue)caseObject.Attributes["new_lob"]).Value;

                                            //    if (caseObject.Attributes.Contains("ownerid"))
                                            //        owner = (EntityReference)caseObject.Attributes["ownerid"];

                                            //    if (caseObject.Attributes.Contains("new_currentqueue"))
                                            //        queueName = (EntityReference)caseObject.Attributes["new_currentqueue"];

                                            //    if (caseObject.Attributes.Contains("new_queuenameid"))
                                            //        originatingQueue = (EntityReference)caseObject.Attributes["new_queuenameid"];
                                            //    
                                            //    CreateSLALogs(regardobjofphoneforSave.Id, "Phone Call", queueName, owner, lob, 0, originatingQueue, (Guid)_postImageEntity.Id, _service);
                                            //}
                                            #endregion
                                        }
                                    }
                                    //Creating a new SLA logs for incoming phone call Activity. Added by v-sivide in Release-8
                                    else if (_postImageEntity.Contains("regardingobjectid") && _postImageEntity.Contains("directioncode") && !((bool)_postImageEntity["directioncode"]))
                                    {
                                        if (_postImageEntity.Contains("release8_iscloned") && (bool)_postImageEntity.Attributes["release8_iscloned"])
                                        {
                                            return;
                                        }
                                        CheckSLALogCreation(userId, _iOrgService, _postImageEntity, tracingService);

                                    }
                                }
                            }
                        }
                    }
                    #endregion

                    #region Phone Call Activity Update
                    //Added a new step. Craeting or closing SLA logs when phone call Activity is uppdated. Added by v-sivide
                    // v-degort : Refactor code to execute a method for Outgoing scenarios and another method for incoming phone call activity scenarios
                    else if (_context.MessageName.ToUpperInvariant() == "UPDATE")
                    {
                        if (traceEnabled)
                        {
                            tracingService.Trace(string.Concat("Plugin_UpdateEmailPhonePlugIn", "Entered SetStateDynamicEntity Step ", DateTime.Now.ToString(), "Information"));

                            //LogEvent("CloudCRM_HRSupport_UpdateEmailPhonePlugInClass", "Entered SetStateDynamicEntity Step", System.Diagnostics.EventLogEntryType.Information);
                        }
                        if (_context.PrimaryEntityName.ToLower() == "phonecall")
                        {
                            //Check whether PostImage is null 
                            if (_context.PostEntityImages != null && _context.PostEntityImages.Contains("PostImagePhoneCallCreate") && _context.PostEntityImages["PostImagePhoneCallCreate"] is Entity)
                            {
                                Entity _postImageEntity = (Entity)_context.PostEntityImages["PostImagePhoneCallCreate"];
                                Entity retrievedPhoneEnt = null;

                                if (_postImageEntity.Id != Guid.Empty)
                                {
                                    retrievedPhoneEnt = _iOrgService.Retrieve("phonecall", _postImageEntity.Id, new ColumnSet("statecode"));
                                }


                                //check if the phonecall activity is not already closed before trying to update it
                                if (retrievedPhoneEnt != null && retrievedPhoneEnt.Attributes.Contains("statecode") && retrievedPhoneEnt["statecode"].Equals(new OptionSetValue(0)))
                                {
                                    //bool direction = (bool)_postImageEntity["directioncode"];                            
                                    //Check whether direction field is outgoing, if it true then update the update status field with yes value
                                    if (_postImageEntity.Contains("regardingobjectid") && _postImageEntity.Contains("directioncode") && (bool)_postImageEntity["directioncode"])
                                    {
                                        EntityReference regardobjofphoneforSave = (EntityReference)_postImageEntity["regardingobjectid"];

                                        if (regardobjofphoneforSave != null && regardobjofphoneforSave.LogicalName == "incident")
                                        {
                                            countOfRecord = GetRecordCount(((EntityReference)_postImageEntity.Attributes["regardingobjectid"]).Id, _iOrgService, tracingService);
                                            if (countOfRecord == 1)
                                            {
                                                //1 = First Response
                                                _postImageEntity["scrum4_response"] = new OptionSetValue(1);
                                                _iOrgService.Update(_postImageEntity);
                                                //1-Email, 2-Phone Call, 3-Owner Change, 4-Resolved Case, 5-No Action Required
                                                cmncode.CloseExistingSLALogs(regardobjofphoneforSave.Id, 2, userId, _iOrgService, tracingService, false);
                                            }
                                            else if (countOfRecord > 1)
                                            {
                                                //2 = SubSequent Response
                                                _postImageEntity["scrum4_response"] = new OptionSetValue(2);
                                                _iOrgService.Update(_postImageEntity);
                                                //1-Email, 2-Phone Call, 3-Owner Change, 4-Resolved Case, 5-No Action Required
                                                cmncode.CloseExistingSLALogs(regardobjofphoneforSave.Id, 2, userId, _iOrgService, tracingService, false);
                                            }

                                        }
                                    }
                                    else if (_postImageEntity.Contains("regardingobjectid") && _postImageEntity.Contains("directioncode") && !((bool)_postImageEntity["directioncode"]))
                                    {
                                        if (_postImageEntity.Contains("release8_iscloned") && (bool)_postImageEntity.Attributes["release8_iscloned"])
                                        {
                                            return;
                                        }

                                        CheckSLALogCreation(userId, _iOrgService, _postImageEntity, tracingService);
                                    }
                                }
                            }
                        }
                    }
                    #endregion

                }
                catch (FaultException<OrganizationServiceFault> ex)
                {
                    strMessage = "Error - Execute Method" + Environment.NewLine;
                    strMessage += "Message:  " + ex.Message.ToString() + Environment.NewLine;
                    strMessage += "Source:  " + ex.Source + Environment.NewLine;
                    strMessage += "Stack Trace:  " + ex.StackTrace + Environment.NewLine;
                    tracingService.Trace(string.Concat("Plugin_UpdateEmailPhonePlugIn", strMessage, DateTime.Now.ToString(), "Error"));

                    //LogEvent("CloudCRM_HRSupport_UpdateEmailPhonePlugInClass", strMessage, System.Diagnostics.EventLogEntryType.Error);
                }
                catch (SizeExceedException)
                {
                    throw;
                }
                catch (Exception ex)
                {
                    strMessage = "Error - Execute Method" + Environment.NewLine;
                    strMessage += "Message:  " + ex.Message.ToString() + Environment.NewLine;
                    strMessage += "Stack Trace:  " + ex.StackTrace + Environment.NewLine;
                    tracingService.Trace(string.Concat("Plugin_UpdateEmailPhonePlugIn", strMessage, DateTime.Now.ToString(), "Error"));
                    //LogEvent("CloudCRM_HRSupport_UpdateEmailPhonePlugInClass", strMessage, System.Diagnostics.EventLogEntryType.Error);
                }
                finally
                {
                    IncludesHoliday = false;
                    IncludesWeekEnd = false;
                }
            }
        }


        #endregion




        #region Update of FirstResponseSent field

        /// <summary>
        /// To Update Case with the KPI Details (Total business hours, Absolute Hours, KPI Met) for First Response Sent
        /// </summary>
        /// <param name="tracingService"></param>
        /// <param name="iOrgService"></param>
        /// <param name="context"></param>
        /// <param name="entity"></param>
        /// <param name="phoneCallResponsePost"></param>
        //updated by v-dimish 
        internal void OnUpdateFirstResponseSent(ITracingService tracingService, IOrganizationService iOrgService, IPluginExecutionContext context, Entity entity, Entity phoneCallResponsePost)
        {
            try
            {
                if (traceEnabled)
                    tracingService.Trace("OnUpdateFirstResponseSent");
                Double firstReplyTargetKPI = 0;
                Double firstReplyActualKPI = 0;
                Double firstReplyAbsoluteTime = 0;
                Guid slaId = Guid.Empty;
                DateTime createdOnTime = DateTime.MinValue;
                DateTime createdOnTimeUTC = DateTime.MinValue;
                DateTime ownerChangedDateTime = DateTime.MinValue;
                DateTime ownerChangedDateTimeUtc = DateTime.MinValue;

                // int ownerChangedDateTimeInMinutes = 0;
                //  int actualFirstResponseTimeInMinutes = 0;


                if (entity.Attributes.Contains("slaid"))
                    slaId = ((EntityReference)entity["slaid"]).Id;

                if (entity.Attributes.Contains("rel13_ownerchangedate"))
                {
                    ownerChangedDateTime = ((DateTime)entity["rel13_ownerchangedate"]);
                    ownerChangedDateTimeUtc = ownerChangedDateTime.ToUniversalTime();
                    // ownerChangedDateTimeInMinutes = ownerChangedDateTime.Hour * 60 + ownerChangedDateTime.Minute;
                    if (traceEnabled)
                        tracingService.Trace("ownerChangedDateTime: " + ownerChangedDateTime + " ownerChangedDateTimeUtc " + ownerChangedDateTimeUtc);
                }
                if (entity.Attributes.Contains("createdon"))
                {
                    createdOnTime = ((DateTime)entity["createdon"]);
                    createdOnTimeUTC = createdOnTime.ToUniversalTime();
                    //   ownerChangedDateTimeInMinutes = ownerChangedDateTime.Hour * 60 + ownerChangedDateTime.Minute;
                    if (traceEnabled)
                        tracingService.Trace("createdOnTime: " + createdOnTime + " createdOnTimeUTC " + createdOnTimeUTC);
                }

                DateTime actualFirstResponseTime = (DateTime)phoneCallResponsePost.Attributes["modifiedon"];
                DateTime actualFirstResponseTimeUtc = actualFirstResponseTime.ToUniversalTime();
                // actualFirstResponseTimeInMinutes = actualFirstResponseTime.Hour * 60 + actualFirstResponseTime.Minute;
                if (traceEnabled)
                    tracingService.Trace("modified on: " + actualFirstResponseTime + " actualFirstResponseTimeUtc " + actualFirstResponseTimeUtc);

                SLATimeInBusinessHours slaTime = new SLATimeInBusinessHours();
                if (slaId != Guid.Empty)
                {
                    if (traceEnabled)
                        tracingService.Trace("slaid: " + slaId + " CaseID: " + entity.Id);

                    Entity caseUpdated = new Entity("incident");
                    caseUpdated.Id = entity.Id;

                    caseUpdated["firstresponsesent"] = true;
                    caseUpdated["rel13_actualfirstresponsetime"] = (DateTime)phoneCallResponsePost.Attributes["modifiedon"];

                    if (entity.Attributes.Contains("new_currentqueue") && entity["new_currentqueue"] != null)
                    {
                        caseUpdated["rel13_firstreplyqueue"] = entity["new_currentqueue"];
                        if (traceEnabled)
                            tracingService.Trace("5");
                    }
                    if (traceEnabled)
                        tracingService.Trace("6");

                    //1. First Reply Absolute Time = Actual First Response Time – OwnerChangeTime. ( Case Created Time)                                        
                    firstReplyAbsoluteTime = ConvertToDouble((actualFirstResponseTimeUtc.Subtract(createdOnTimeUTC)).TotalMinutes, tracingService);
                    // firstReplyAbsoluteTime = ConvertToDouble(actualFirstResponseTimeInMinutes - ownerChangedDateTimeInMinutes, tracingService);
                    caseUpdated["rel13_firstreplyabsolutetime"] = firstReplyAbsoluteTime.ToString();
                    if (traceEnabled)
                        tracingService.Trace("11firstReplyAbsoluteTime " + firstReplyAbsoluteTime);

                    //2. First Reply Actual KPI = First Reply Absolute Time – Holidays/Weekends and business hours. 
                    firstReplyActualKPI = slaTime.RetrieveSLArecord(iOrgService, ownerChangedDateTimeUtc, actualFirstResponseTimeUtc, slaId);
                    caseUpdated["rel13_firstreplyactualkpi"] = firstReplyActualKPI.ToString();
                    if (traceEnabled)
                        tracingService.Trace("12firstReplyActualKPI " + firstReplyActualKPI);

                    //First Reply Target KPI = SLA Item failure where SLA KPI = First response KPI.
                    QueryExpression getSLAItem = new QueryExpression("slaitem");
                    getSLAItem.ColumnSet = new ColumnSet("failureafter");
                    getSLAItem.Criteria.AddCondition("slaid", ConditionOperator.Equal, slaId);
                    getSLAItem.Criteria.AddCondition("relatedfield", ConditionOperator.Equal, "firstresponsebykpiid");
                    EntityCollection slaItemFailureAfter = iOrgService.RetrieveMultiple(getSLAItem);
                    if (slaItemFailureAfter.Entities != null && slaItemFailureAfter.Entities.Count > 0)
                    {
                        Entity entSLAItem = slaItemFailureAfter.Entities[0];
                        if (entSLAItem != null & entSLAItem.Attributes.Contains("failureafter") && (entSLAItem["failureafter"] != null))
                        {
                            firstReplyTargetKPI = ConvertToDouble(entSLAItem.GetAttributeValue<int>("failureafter"), tracingService);
                            tracingService.Trace("12a GetAttributeValue<int>failureafter " + entSLAItem.GetAttributeValue<int>("failureafter"));
                            tracingService.Trace("12aconvert GetAttributeValue<int>failureafter " + firstReplyTargetKPI);
                        }
                    }
                    else if (slaItemFailureAfter.Entities != null && slaItemFailureAfter.Entities.Count == 0)// If SLA Item is not present for a SLA then First Reply KPI Met will be NA
                    {
                        firstReplyTargetKPI = 0;
                    }

                    caseUpdated["rel13_firstreplytargetkpi"] = firstReplyTargetKPI.ToString();
                    if (traceEnabled)
                        tracingService.Trace("12rel13_firstreplytargetkpi " + firstReplyTargetKPI.ToString());

                    //First Reply KPI Met = Yes( if First Reply Target KPI > First Reply Actual KPI)
                    //= No(if First Reply Target KPI < First Reply Actual KPI)
                    //= N / A if First Reply Target KPI is 0

                    if (firstReplyTargetKPI == 0 || firstReplyTargetKPI == firstReplyActualKPI)
                        caseUpdated["rel13_firstreplykpimet"] = new OptionSetValue(3);
                    else if (firstReplyTargetKPI > firstReplyActualKPI)
                        caseUpdated["rel13_firstreplykpimet"] = new OptionSetValue(1);
                    else if (firstReplyTargetKPI < firstReplyActualKPI)
                        caseUpdated["rel13_firstreplykpimet"] = new OptionSetValue(2);


                    //if (firstReplyTargetKPI == 0)
                    //        caseUpdated["rel13_firstreplykpimet"] = new OptionSetValue(3);
                    //    else
                    //        caseUpdated["rel13_firstreplykpimet"] = new OptionSetValue(firstReplyTargetKPI > firstReplyActualKPI ? 1 : (firstReplyTargetKPI < firstReplyActualKPI ? 2 : 3));


                    iOrgService.Update(caseUpdated);
                    if (traceEnabled)
                        tracingService.Trace("13Endof  onUpdateFirstResponseSent");

                }
            }
            catch (FaultException<OrganizationServiceFault> ex)
            {
                if (traceEnabled && tracingService != null)
                {
                    tracingService.Trace(string.Concat("Plugin_PhoneCallPlugin_onUpdateFirstResponseSent", " - ", ex.Message.ToString(), " - ", "Error"));
                }
            }
            catch (Exception ex)
            {
                if (traceEnabled && tracingService != null)
                {
                    tracingService.Trace(string.Concat("Plugin_PhoneCallPlugin_onUpdateFirstResponseSent", " - ", ex.Message.ToString(), " - ", "Error"));
                }
            }

        }


        public double ConvertToDouble(double mins, ITracingService tracingService)
        {
            try
            {
                int intHours = (int)(mins / 60);
                int intMinutes = (int)Math.Round(mins % 60);
                //int intMinutes = (int)(mins % 60);
                string strMinutes = intMinutes.ToString();
                strMinutes = (intMinutes * 10 / 6).ToString();
                if (int.Parse(strMinutes) < 10)
                {
                    strMinutes = string.Format("0{0}", strMinutes);
                }

                string strConvertedTime = string.Concat(intHours, ".", strMinutes);
                if (traceEnabled)
                    tracingService.Trace("intHours: " + intHours + " intMinutes: " + intMinutes + " strMinutes: " + strMinutes + " strConvertedTime: " + strConvertedTime);
                return Convert.ToDouble(strConvertedTime);
            }
            catch (Exception ex)
            {
                if (traceEnabled)
                    tracingService.Trace("Exception in ConvertToDouble: " + ex.Message);
                return 0;
            }
        }
        #endregion


        private void CheckSLALogCreation(Guid userId, IOrganizationService _iOrgService, Entity _EntityImage, ITracingService tracingService)
        {
            EntityReference regardobjofphoneforSave = (EntityReference)_EntityImage["regardingobjectid"];

            if (regardobjofphoneforSave != null && regardobjofphoneforSave.LogicalName == "incident")
            {
                Entity caseObject = null;

                caseObject = RetrieveEntityDetails(regardobjofphoneforSave.Id, "incident", new ColumnSet("release8_phonecallid", "ownerid", "new_currentqueue", "new_lob", "scrum4_caseorigin", "new_queuenameid"), _iOrgService);

                if (!caseObject.Attributes.Contains("release8_phonecallid"))
                    cmncode.CreateSLALogMain(_iOrgService, _EntityImage.Id, regardobjofphoneforSave.Id, DateTime.UtcNow, "Phone Call", userId, tracingService, true);
            }
        }



        #region GetPhoneCallActivityDirection
        /// <summary>
        /// Get DirectionCode
        /// </summary>
        /// <param name="activityId"></param>
        /// <returns></returns>
        private bool GetPhoneCallDirection(Guid activityId, IOrganizationService _iOrgServ)
        {
            try
            {
                bool directionCode = false;
                if (activityId != Guid.Empty && activityId != null)
                {
                    //Retrive the email records which is outgoing & directionCode hold the direction from the record & return it
                    QueryExpression phoneCallQuery = new QueryExpression();
                    phoneCallQuery.EntityName = "phonecall";
                    phoneCallQuery.ColumnSet = new ColumnSet();
                    phoneCallQuery.ColumnSet.Columns.Add("directioncode");
                    phoneCallQuery.Criteria.AddCondition("activityid", ConditionOperator.Equal, activityId);
                    EntityCollection phoneColl = (EntityCollection)_iOrgServ.RetrieveMultiple(phoneCallQuery);

                    if (phoneColl.Entities.Count > 0)
                    {
                        Entity entEmail = (Entity)phoneColl.Entities[0];
                        if (entEmail.Attributes.Contains("directioncode"))
                            directionCode = (bool)entEmail.Attributes["directioncode"];
                    }
                }
                return directionCode;
            }
            catch (FaultException<OrganizationServiceFault>)
            {
                throw;
            }
            catch (Exception)
            {
                throw;
            }
        }
        #endregion

        #region GetRecordCount
        /// <summary>
        /// Get Record Count
        /// </summary>
        /// <param name="activityId"></param>
        /// <returns></returns>
        private int GetRecordCount(Guid RegardingObject, IOrganizationService _orgService, ITracingService tracingService)
        {
            try
            {
                int activityCount = 0;
                QueryExpression Query = new QueryExpression();
                Query.EntityName = "activitypointer";
                Query.ColumnSet = new ColumnSet();
                Query.ColumnSet.Columns.Add("activityid");
                Query.ColumnSet.Columns.Add("activitytypecode");
                Query.Criteria.AddCondition("regardingobjectid", ConditionOperator.Equal, RegardingObject);
                Query.Criteria.AddCondition("isworkflowcreated", ConditionOperator.Equal, false);
                EntityCollection activityColl = (EntityCollection)_orgService.RetrieveMultiple(Query);

                if (activityColl.Entities.Count > 0)
                {
                    foreach (Entity act in activityColl.Entities)
                    {
                        if (act.Attributes.Contains("activityid") && (Guid)act.Attributes["activityid"] != Guid.Empty && act.Attributes.Contains("activitytypecode"))
                        {
                            bool direction = false;
                            if (((string)act.Attributes["activitytypecode"]) == "phonecall")
                            {
                                direction = GetPhoneCallDirection((Guid)act.Attributes["activityid"], _orgService);
                                if (direction == true)
                                {
                                    activityCount = activityCount + 1;
                                }

                            }
                        }
                    }
                }
                if (traceEnabled)
                {
                    tracingService.Trace(string.Concat("Plugin_UpdateEmailPhonePlugIn", "RecordCount = " + activityCount, DateTime.Now.ToString(), "Information"));

                    // LogEvent("CloudCRM_HRSupport_UpdateEmailPhonePlugInClass", "RecordCount = " + activityCount, System.Diagnostics.EventLogEntryType.Information);
                }
                return activityCount;
            }
            catch (FaultException<OrganizationServiceFault>)
            {
                throw;
            }
            catch (Exception)
            {
                throw;
            }
        }
        #endregion

        #region RetrieveEntityDetails
        ///<summary>
        ///This function retrieves the entity details based on unique id
        ///</summary>
        ///<param name="entityId"></param>
        ///<param name="entityName"></param>
        ///<param name="colmnSet"></param>
        ///<returns></returns>
        private Entity RetrieveEntityDetails(Guid entityId, string entityName, ColumnSet colmnSet, IOrganizationService _orgService)
        {
            try
            {
                Entity entityObj = null;
                entityObj = (Entity)_orgService.Retrieve(entityName, entityId, colmnSet);
                return entityObj;
            }
            catch (FaultException<OrganizationServiceFault>)
            {
                throw;
            }
            catch (Exception)
            {
                throw;
            }
        }
        #endregion

        #region Commented code -- SLA log creation is moved to Common code class file.
        //        private int CloseExistingSLALogs(Guid incidentGuid, int sourceOfClosingSLALog, Guid userId, IOrganizationService _orgService, ITracingService tracingService)
        //                {

        //                    try
        //                    {
        //                        EntityCollection result = null;
        //                        if (traceEnabled)
        //                        {
        //                            tracingService.Trace(string.Concat("Plugin_UpdateEmailPhonePlugIn", "Entered CloseExistingSLALogs Method ", DateTime.Now.ToString(), "Information"));
        //                            //LogEvent("CloudCRM_HRSupport_UpdateEmailPhonePlugInClass", "Entered CloseExistingSLALogs Method", System.Diagnostics.EventLogEntryType.Information);
        //                        }

        //                        int firstOrSubSequentResponse = 1; //1 = First Response ; 2 = SubSequent Response
        //                        string fetchXML = @"<fetch distinct='false' mapping='logical' output-format='xml-platform' version='1.0'>
        //                                        <entity name='new_slaactivity'> 
        //                                        <attribute name='new_slaactivityid'/>
        //                                        <attribute name='new_name'/>
        //                                        <attribute name='createdon'/> 
        //                                        <attribute name='new_slastartdate'/> 
        //                                        <attribute name='new_slaend'/> 
        //                                        <attribute name='scrum4_yellowtime'/>
        //                                        <attribute name='new_slaenddate'/>
        //                                        <attribute name='new_slastate'/>
        //                                        <attribute name='new_slastatus'/>
        //                                        <attribute name='scrum4_response'/>
        //                                         <order descending='false' attribute='createdon'/>
        //                                            <filter type='and'> 
        //                                                    <condition attribute='new_caseid' operator='in'> 
        //                                                         <value uitype='incident'>" + incidentGuid + @"</value> 
        //                                                    </condition>                                            
        //                                            </filter> 
        //                                         </entity>
        //                                         </fetch>";

        //                        result = _orgService.RetrieveMultiple(new FetchExpression(fetchXML.ToString()));

        //                        foreach (var existingSLALogVar in result.Entities)
        //                        {
        //                            if (existingSLALogVar.Attributes.Contains("scrum4_response") && ((OptionSetValue)existingSLALogVar.Attributes["scrum4_response"]).Value == 1)
        //                            {
        //                                //If there is any SLA Log whose response is first then all other SLA logs should be closed with subsequent response
        //                                firstOrSubSequentResponse = 2;
        //                            }
        //                        }

        //                        foreach (var retEnt in result.Entities)
        //                        {
        //                            int _slaState = 0;
        //                            if (retEnt.Attributes.Contains("new_slastate"))
        //                            {
        //                                OptionSetValue _os = (OptionSetValue)retEnt.Attributes["new_slastate"];
        //                                _slaState = _os.Value;
        //                            }
        //                            //Close only open SLA logs i.e., new_slastatus==1
        //                            if (retEnt.Attributes.Contains("new_slastatus") && ((OptionSetValue)retEnt.Attributes["new_slastatus"]).Value == 1)
        //                            {
        //                                if (retEnt.Attributes.Contains("new_slaactivityid") && retEnt.Attributes.Contains("new_slastartdate") && retEnt.Attributes.Contains("scrum4_yellowtime") && retEnt.Attributes.Contains("new_slaenddate") && retEnt.Attributes.Contains("new_slaend"))
        //                                {
        //                                    UpdateRespondedDateAndCloseRelatedSLALogs(new Guid(Convert.ToString(retEnt.Attributes["new_slaactivityid"])), DateTime.UtcNow, 2, Convert.ToDateTime(retEnt.Attributes["new_slastartdate"]).ToUniversalTime(), Convert.ToDateTime(retEnt.Attributes["scrum4_yellowtime"]).ToUniversalTime(), Convert.ToDateTime(retEnt.Attributes["new_slaenddate"]).ToUniversalTime(), Convert.ToDouble(retEnt.Attributes["new_slaend"]), _slaState, sourceOfClosingSLALog, firstOrSubSequentResponse, userId, _orgService, tracingService);
        //                                    firstOrSubSequentResponse = 2;
        //                                }
        //                            }
        //                        }

        //                        return result.Entities.Count;

        //                    }
        //                    catch (FaultException<OrganizationServiceFault>)
        //                    {
        //                        throw;
        //                    }
        //                    catch (Exception)
        //                    {
        //                        throw;
        //                    }
        //                }
        //        private void UpdateRespondedDateAndCloseRelatedSLALogs(Guid SLALogGuid, DateTime respondedDate, int status, DateTime _slaStartDate, DateTime _slaYellowDate, DateTime _slaRedDate, double _slaEnd, int _slaState, int sourceOfClosingSLALog, int firstOrSubSequentResponse, Guid userId, IOrganizationService _iOrgServ, ITracingService tracingService)
        //                {
        //                    try
        //                    {
        //                        if (traceEnabled)
        //                        {
        //                            tracingService.Trace(string.Concat("Plugin_UpdateEmailPhonePlugIn", "Entered UpdateRespondedDateAndCloseRelatedSLALogs Method ", DateTime.Now.ToString(), "Information"));

        //                            //LogEvent("CloudCRM_HRSupport_UpdateEmailPhonePlugInClass", "Entered UpdateRespondedDateAndCloseRelatedSLALogs Method", System.Diagnostics.EventLogEntryType.Information);
        //                        }
        //                        int _slaStateNew = 0;
        //                        Entity SLALogInstance = new Entity();
        //                        SLALogInstance.LogicalName = "new_slaactivity";
        //                        SLALogInstance.Id = SLALogGuid;
        //                        SLALogInstance["new_respondeddate"] = GetLoggedInUserLocalTimeFromUTCTime(_iOrgServ, respondedDate, userId);
        //                        //status - 1 - Open            
        //                        //status - 2 - Closed
        //                        SLALogInstance["new_slastatus"] = new OptionSetValue(status);
        //                        //Calculating SLA State                
        //                        _slaStateNew = CalculateSLAState(_slaYellowDate, _slaRedDate, tracingService);
        //                        if (_slaStateNew != 0 && _slaStateNew != _slaState)
        //                        {
        //                            OptionSetValue opsValue = new OptionSetValue(_slaStateNew);
        //                            SLALogInstance["new_slastate"] = opsValue;
        //                        }
        //                        //1-Email, 2-Phone Call, 3-Owner Change, 4-Resolved Case, 5-No Action Required
        //                        if (sourceOfClosingSLALog != 0)
        //                        {
        //                            OptionSetValue sourceOfSLALogOptionalValue = new OptionSetValue(sourceOfClosingSLALog);
        //                            SLALogInstance["scrum4_slastatusreason"] = sourceOfSLALogOptionalValue;
        //                        }
        //                        //1 = First Response ; 2 = SubSequent Response
        //                        SLALogInstance["scrum4_response"] = new OptionSetValue(firstOrSubSequentResponse);
        //                        _iOrgServ.Update(SLALogInstance);
        //                    }
        //                    catch (FaultException<OrganizationServiceFault>)
        //                    {
        //                        throw;
        //                    }
        //                    catch (Exception)
        //                    {
        //                        throw;
        //                    }
        //                }
        //        #region CalculateSLAState
        //        /// <summary>
        //        /// Determines the SLA State of a SLA Activity
        //        /// </summary>
        //        /// <param name="slaStartDate">SLA Start Date</param>
        //        /// <param name="slaEndTime">SLA End Time in Hours</param>
        //        /// <param name="slaYellowDate">Yellow Time retrieved from SLA Log record</param>
        //        /// <param name="_iOrgServ">Organization Service</param>
        //        /// <returns></returns>
        //        private int CalculateSLAState(DateTime slaYellowDate, DateTime SLARedDate, ITracingService tracingService)
        //        {
        //            int slaStateNew = 0;
        //            DateTime currentDate = DateTime.UtcNow;
        //            try
        //            {
        //                if (traceEnabled)
        //                {
        //                    tracingService.Trace(string.Concat("Plugin_UpdateEmailPhonePlugIn", "Entered CalculateSLAState ", DateTime.Now.ToString(), "Information"));

        //                    //LogEvent("CloudCRM_HRSupport_UpdateEmailPhonePlugInClass", "Entered CalculateSLAState " + DateTime.Now, System.Diagnostics.EventLogEntryType.Information);
        //                }
        //                if (SLARedDate != DateTime.MinValue && slaYellowDate != DateTime.MinValue)
        //                {
        //                    // (1-Red,2-Yellow,3-Green,535,720,000-No Action Required); Default Value - Green                   
        //                    if (currentDate > SLARedDate)
        //                        slaStateNew = 1;
        //                    else if ((currentDate <= SLARedDate) && (currentDate > slaYellowDate))
        //                        slaStateNew = 2;
        //                    else if ((currentDate <= SLARedDate) && (currentDate <= slaYellowDate))
        //                        slaStateNew = 3;
        //                }
        //            }
        //            catch (FaultException<OrganizationServiceFault>)
        //            {
        //                throw;
        //            }
        //            catch (Exception)
        //            {
        //                throw;
        //            }
        //            if (traceEnabled)
        //            {
        //                tracingService.Trace(string.Concat("Plugin_UpdateEmailPhonePlugIn", "Exited CalculateSLAState ", DateTime.Now.ToString(), "Information"));

        //               // LogEvent("CloudCRM_HRSupport_CasePlugin", "Exited CalculateSLAState " + DateTime.Now, System.Diagnostics.EventLogEntryType.Information);
        //            }
        //            return slaStateNew;
        //        }
        //#endregion
        //        # region CreateSLALogs
        //        /// <summary>
        //        /// Create SLA Logs
        //        /// </summary>
        //        /// <param name="ownerGuid">Owner</param>
        //        /// <param name="sourceOfCaseCreation">state</param>
        //        /// <param name="startTime">startTime</param>
        //        /// <param name="endTime">endTime</param>
        //        /// <param name="slaYellowDate">slaYellowDate</param>
        //        /// <param name="respondedDate">respondedDate</param>
        //        /// <param name="endHrs">endHrs</param>
        //        /// <param name="SLALOB">lob</param>
        //        /// <param name="service">status</param>
        //        /// <param name="service">slaState</param>
        //        /// <param name="service">caseId</param>
        //        /// <param name="service">queuename</param>
        //        /// <param name="service">emailGUID</param>
        //        /// <returns>void</returns>
        //        private void CreateSLALogs(Guid incidentGuid, string sourceOfCaseCreation, EntityReference currentQueueGuid, EntityReference ownerGuid, int SLALOB, int SLAHoursOfQueue, EntityReference originatingQueueName, Guid activityGuid, IOrganizationService _iOrgServ, ITracingService tracingService)
        //        {
        //            try
        //            {
        //                if (traceEnabled)
        //                {
        //                    //LogEvent("CloudCRM_HRSupport_UpdateEmailPhonePlugInClass", "Entered CreateSLALogs Method", System.Diagnostics.EventLogEntryType.Information);
        //                }

        //                DateTime dateTimeNow = cmncode.GetLoggedInUserLocalTimeFromUTCTime(_iOrgServ, DateTime.UtcNow, userId, tracingService);
        //                Entity SLALogDynamicEntity = new Entity("new_slaactivity");
        //                SLALogDynamicEntity["new_caseid"] = new EntityReference("incident", incidentGuid);

        //                if ((sourceOfCaseCreation.ToLower() == "outgoing") && (activityGuid != Guid.Empty))
        //                {
        //                    SLALogDynamicEntity["new_email"] = new EntityReference("email", activityGuid);
        //                }
        //                else if (sourceOfCaseCreation.ToLower() == "phone call" && (activityGuid != Guid.Empty))
        //                {
        //                    SLALogDynamicEntity["scrum4_phonecall"] = new EntityReference("phonecall", activityGuid);
        //                }

        //                SLALogDynamicEntity["new_name"] = sourceOfCaseCreation;
        //                SLALogDynamicEntity["new_slastartdate"] = dateTimeNow;
        //                SLALogDynamicEntity["new_slaenddate"] = dateTimeNow;
        //                SLALogDynamicEntity["new_slaend"] = Convert.ToDecimal(SLAHoursOfQueue);
        //                //Calculated Yellow Date passed to this function is put into the SLA Activity Entity
        //                SLALogDynamicEntity["scrum4_yellowtime"] = dateTimeNow;
        //                //new_slastate (1-Red,2-Yellow,3-Green,535,720,000-No Action Required); Default Value - Green                
        //                //SLALogDynamicEntity["new_slastate"] = new OptionSetValue(0);
        //                if (SLALOB != 0)
        //                    SLALogDynamicEntity["new_slalob"] = new OptionSetValue(SLALOB);
        //                //new_slastatus (1-Open,2-Closed)
        //                SLALogDynamicEntity["new_slastatus"] = new OptionSetValue(2);
        //                SLALogDynamicEntity["new_originatingqueue"] = new EntityReference("queue", originatingQueueName.Id);
        //                //As this log is for internal tracking purpuse make includes weekend and includes holiday false
        //                SLALogDynamicEntity["scrum4_includesweekend"] = false;
        //                SLALogDynamicEntity["scrum4_includesholiday"] = false;

        //                if (ownerGuid.LogicalName == "systemuser")
        //                {
        //                    SLALogDynamicEntity["ownerid"] = new EntityReference("systemuser", ownerGuid.Id);
        //                }
        //                else if (ownerGuid.LogicalName == "team")
        //                {
        //                    SLALogDynamicEntity["ownerid"] = new EntityReference("team", ownerGuid.Id);
        //                }
        //                SLALogDynamicEntity["scrum4_response"] = null;
        //                SLALogDynamicEntity["scrum4_queue"] = new EntityReference("queue", currentQueueGuid.Id);
        //                //1-Email, 2-Phone Call, 3-Owner Change, 4-Resolved Case, 5-No Action Required  
        //                OptionSetValue sourceOfClosingSLALog = new OptionSetValue();
        //                if (sourceOfCaseCreation.ToLower() == "outgoing")
        //                {
        //                    sourceOfClosingSLALog = new OptionSetValue(1);
        //                }
        //                else if (sourceOfCaseCreation.ToLower() == "phone call")
        //                {
        //                    sourceOfClosingSLALog = new OptionSetValue(2);
        //                }

        //                SLALogDynamicEntity["scrum4_slastatusreason"] = sourceOfClosingSLALog;
        //                SLALogDynamicEntity["new_respondeddate"] = dateTimeNow;
        //                _iOrgServ.Create(SLALogDynamicEntity);

        //            }
        //            catch (FaultException<OrganizationServiceFault>)
        //            {
        //                throw;
        //            }
        //            catch (Exception)
        //            {
        //                throw;
        //            }
        //        }
        //        # endregion
        //        #region CreateSLALogForPhoneCallActivity

        //                private void CreateSLALogForPhoneCallActivity(Guid phoneGuid, Guid incidentGuid, string sourceOfCaseCreation, Guid userId, IOrganizationService _orgService, ITracingService tracingService)
        //                {
        //                    try
        //                    {
        //                        string fetchXML = @"<fetch distinct='false' mapping='logical' output-format='xml-platform' version='1.0'>
        //                                        <entity name='new_slaactivity'> 
        //                                        <attribute name='new_slaactivityid'/>
        //                                        <attribute name='new_name'/>
        //                                        <attribute name='createdon'/> 
        //                                        <attribute name='new_slastartdate'/> 
        //                                        <attribute name='new_slaend'/> 
        //                                        <attribute name='scrum4_yellowtime'/>
        //                                        <attribute name='new_slaenddate'/>
        //                                        <attribute name='new_slastate'/>
        //                                        <attribute name='new_slastatus'/>
        //                                        <attribute name='scrum4_response'/>
        //                                         <order descending='false' attribute='createdon'/>
        //                                            <filter type='and'> 
        //                                                    <condition attribute='new_caseid' operator='in'> 
        //                                                         <value uitype='incident'>" + incidentGuid + @"</value> 
        //                                                    </condition>  
        //        			                      <condition attribute='scrum4_phonecall' operator='in' >
        //        							 <value uitype='phonecall'>" + phoneGuid + @"</value> 
        //                          				  </condition> 
        //                                            </filter> 
        //                                         </entity>
        //                                         </fetch>";

        //                        EntityCollection result = _orgService.RetrieveMultiple(new FetchExpression(fetchXML.ToString()));

        //                        if (result != null && result.Entities.Count > 0)
        //                        {
        //                            return;
        //                        }

        //                        //Declaration of Local Variables
        //                        EntityReference originatingQueueGuid = new EntityReference();
        //                        EntityReference currentQueueGuid = new EntityReference();
        //                        EntityReference ownerGuid = new EntityReference();
        //                        EntityReference countryGuid = new EntityReference();
        //                        //Initiation of Local Variables
        //                        originatingQueueGuid.Id = Guid.Empty;
        //                        currentQueueGuid.Id = Guid.Empty;
        //                        ownerGuid.Id = Guid.Empty;
        //                        countryGuid.Id = Guid.Empty;
        //                        //int SLAHoursForCorrespondingQueue = 0;
        //                        int casePriority = 0;
        //                        int SLALOB = 0;
        //                        //Guid phoneGuid = Guid.Empty;
        //                        Entity incidentDynamicEntity = null;

        //                        int caseType = 0;
        //                        int caseOrigin = 0;

        //                        incidentDynamicEntity = _orgService.Retrieve("incident", incidentGuid, new ColumnSet("ownerid", "new_currentqueue", "prioritycode", "scrum4_queuecountryid", "new_lob", "scrum4_caseorigin", "scrum9_casetype", "new_queuenameid"));

        //                        if (incidentDynamicEntity != null && incidentDynamicEntity.Id != Guid.Empty)
        //                        {
        //                            currentQueueGuid = (EntityReference)(incidentDynamicEntity.Attributes["new_currentqueue"]);
        //                            if (incidentDynamicEntity.Attributes.Contains("scrum4_queuecountryid"))
        //                            {
        //                                countryGuid = (EntityReference)(incidentDynamicEntity.Attributes["scrum4_queuecountryid"]);
        //                            }
        //                            casePriority = ((Microsoft.Xrm.Sdk.OptionSetValue)(incidentDynamicEntity.Attributes["prioritycode"])).Value;
        //                            ownerGuid = (EntityReference)(incidentDynamicEntity.Attributes["ownerid"]);

        //                            caseOrigin = ((Microsoft.Xrm.Sdk.OptionSetValue)(incidentDynamicEntity.Attributes["scrum4_caseorigin"])).Value;
        //                            caseType = incidentDynamicEntity.Attributes.Contains("scrum9_casetype") ? ((Microsoft.Xrm.Sdk.OptionSetValue)(incidentDynamicEntity.Attributes["scrum9_casetype"])).Value : 0;
        //                            //-----------------------------------------------------end--------------------------------
        //                            //Retrieve the SLA Hours from the SLA Configuration Entity based on Queue ID and Priority

        //                            //SLAHoursForCorrespondingQueue = GetSLAHoursForCorrespondingQueue(currentQueueGuid.Id, casePriority, _orgService);
        //                            originatingQueueGuid = (EntityReference)(incidentDynamicEntity.Attributes["new_queuenameid"]);
        //                            if (incidentDynamicEntity.Attributes.Contains("new_lob"))
        //                            {
        //                                SLALOB = ((Microsoft.Xrm.Sdk.OptionSetValue)(incidentDynamicEntity.Attributes["new_lob"])).Value;
        //                            }
        //                            //Create new SLA logs with 1-Open SLA Status and 3-Green SLA State 
        //                            //CreateSLALogs(incidentGuid, sourceOfCaseCreation, currentQueueGuid, casePriority, caseOrigin, caseType, ownerGuid, countryGuid, SLALOB, originatingQueueGuid, Guid.Empty, 1, 3, Guid.Empty, phoneGuid, userId, _orgService);
        //                        }
        //                    }
        //                    catch (FaultException<OrganizationServiceFault>)
        //                    {
        //                        throw;
        //                    }
        //                    catch (Exception)
        //                    {
        //                        throw;
        //                    }
        //                }

        //                #endregion
        //        # region CreateSLALogs
        //        /// <summary>
        //        /// Create SLA Logs after calculating the Red, Yellow and Green DateTimes according to the Current Queue configuration
        //        /// </summary>
        //        /// <param name="incidentGuid">Guid of the Case</param>
        //        /// <param name="sourceOfCaseCreation">Source of creation of the Case</param>
        //        /// <param name="currentQueueGuid">Guid of the Current Queue of the case</param>
        //        /// <param name="ownerGuid">Guid of the owner of the Case</param>
        //        /// <param name="countryGuid">Guid of the Country of the case</param>
        //        /// <param name="SLALOB">LOB of the case</param>
        //        /// <param name="SLAHoursOfQueue">SLA Hours of the Current Queue</param>
        //        /// <param name="priority">Priority of the Case</param>
        //        /// <param name="originatingQueue">Originating Queue of the Case</param>
        //        /// <param name="EmailGuid">Guid of the Email which created the case</param>
        //        /// <param name="SLAStatus">SLA Status</param>
        //        /// <param name="SLAState">SLA State</param>
        //        /// <param name="HRWebActivityGuid">Guid of the HRWebActivity which created the case</param>
        //        /// <returns>void</returns>
        //        //---Modified by Raghav--Scrum 9--VSTF ID #1096743--                                                
        //        private void CreateSLALogs(Guid incidentGuid, string sourceOfCaseCreation, EntityReference currentQueueGuid, EntityReference ownerGuid, EntityReference countryGuid, int SLALOB, int SLAHoursOfQueue, EntityReference originatingQueue, Guid EmailGuid, int SLAStatus, int SLAState, Guid HRWebActivityGuid, Guid userId, IOrganizationService _iOrgServ)
        //        private void CreateSLALogs(Guid incidentGuid, string sourceOfCaseCreation, EntityReference currentQueueGuid, int casePriority, int caseOrigin, int caseType, EntityReference ownerGuid, EntityReference countryGuid, int SLALOB, EntityReference originatingQueue, Guid EmailGuid, int SLAStatus, int SLAState, Guid HRWebActivityGuid, Guid PhoneActivityID, Guid userId, IOrganizationService _iOrgServ, ITracingService tracingService)
        //        {
        //            if (traceEnabled)
        //            {
        //                tracingService.Trace(string.Concat("Plugin_UpdateEmailPhonePlugIn", "Entered CreateSLALogs method ", DateTime.Now.ToString(), "Information"));

        //                //LogEvent("CloudCRM_HRSupport_CasePlugin", "Entered CreateSLALogs method " + DateTime.Now, System.Diagnostics.EventLogEntryType.Information);
        //            }
        //            try
        //            {
        //                //ITracingService tracingService = null;
        //                int SLAHoursOfQueue = 0;
        //                int SLAVariance = 0;
        //                double SLAHoursAfterVariance = 0;
        //                string SLAConfigurationID = string.Empty;
        //                DateTime[] arrayofCalculatedDates = new DateTime[4];
        //                DateTime startDate = DateTime.UtcNow;
        //                DateTime endDate = DateTime.Now;
        //                DateTime SLAYellowDate = DateTime.Now;
        //                int queueTimeZone = -1;
        //                Entity queueDynamicEntity = null;
        //                Entity userContext = null;
        //                int userContextTimeZoneCode = -1;
        //                bool queueWorkingSectionConfigured = true;
        //                Guid workedBy = Guid.Empty;
        //                //Get the SLA Variance from the Current Queue configuration
        //                //SLAVariance = GetSLAVariance(incidentGuid, _iOrgServ);
        //                //SLAHoursAfterVariance = ((double)(SLAHoursOfQueue * SLAVariance) / 100);

        //                //---Modified by Raghav--Scrum 9--VSTF ID #1096743--                                                
        //                //SLALogBAL slaLogBAL = new SLALogBAL();

        //                EntityCollection QueueSpecificSLARecords = slaLogBAL.FetchSLAConfigurations(currentQueueGuid.Id, casePriority, caseOrigin, caseType, _iOrgServ, tracingService, false);


        //                if (QueueSpecificSLARecords.Entities.Count > 0)
        //                {

        //                    slaLogBAL.SetSLAParameters(QueueSpecificSLARecords);
        //                }
        //                else
        //                {
        //                    EntityCollection UniversalSLARecords = slaLogBAL.FetchSLAConfigurations(casePriority, caseOrigin, caseType, _iOrgServ, tracingService,false);
        //                    if (UniversalSLARecords.Entities.Count > 0)
        //                    {

        //                        slaLogBAL.SetSLAParameters(UniversalSLARecords);
        //                    }
        //                    else
        //                    {

        //                        EntityCollection DefaultSLARecords = slaLogBAL.FetchSLAConfigurations(_iOrgServ, tracingService,false);
        //                        if (DefaultSLARecords.Entities.Count > 0)
        //                        {
        //                            slaLogBAL.SetSLAParameters(DefaultSLARecords);
        //                        }

        //                    }
        //                }

        //                SLAHoursOfQueue = slaLogBAL.SLAHours;
        //                SLAVariance = slaLogBAL.SLAVariance;
        //                SLAHoursAfterVariance = slaLogBAL.SLAAfterVariance;
        //                SLAConfigurationID = slaLogBAL.SLAConfigurationID;
        //                //-----------------------------------------END----------------------------------------

        //                //Create an SLA Log only if all required values for calculating SLA Hours after Variance are available
        //                if (SLAHoursOfQueue != -1 && SLAVariance != -1 && !Double.IsNaN(SLAHoursAfterVariance) && SLAConfigurationID != string.Empty)
        //                {
        //                    //Get the timezone of the current queue
        //                    queueDynamicEntity = RetrieveEntityDetails(currentQueueGuid.Id, "queue", new ColumnSet("scrum4_monday", "scrum4_tuesday", "scrum4_wednesday", "scrum4_thursday", "scrum4_friday", "scrum4_saturday", "scrum4_sunday", "scrum4_timezone"), _iOrgServ);

        //                    if (queueDynamicEntity != null)
        //                    {
        //                        //check if queue working section is configured or not.  If queue working section is not configured, then sla logs would not be created
        //                        //If all the working section fields are not null
        //                        if (queueDynamicEntity.Attributes.Contains("scrum4_monday") && queueDynamicEntity.Attributes.Contains("scrum4_tuesday") && queueDynamicEntity.Attributes.Contains("scrum4_wednesday") && queueDynamicEntity.Attributes.Contains("scrum4_thursday") && queueDynamicEntity.Attributes.Contains("scrum4_friday") && queueDynamicEntity.Attributes.Contains("scrum4_saturday") && queueDynamicEntity.Attributes.Contains("scrum4_sunday"))
        //                        {

        //                            //Only if not all the working section checkboxes are unchecked (all days are false), we would proceed with the logic
        //                            if ((!((bool)queueDynamicEntity.Attributes["scrum4_monday"])) && (!((bool)queueDynamicEntity.Attributes["scrum4_tuesday"])) && (!((bool)queueDynamicEntity.Attributes["scrum4_wednesday"])) && (!((bool)queueDynamicEntity.Attributes["scrum4_thursday"])) && (!((bool)queueDynamicEntity.Attributes["scrum4_friday"])) && (!((bool)queueDynamicEntity.Attributes["scrum4_saturday"])) && (!((bool)queueDynamicEntity.Attributes["scrum4_sunday"])))
        //                            {
        //                                queueWorkingSectionConfigured = false;
        //                            }
        //                        }
        //                        else
        //                        {
        //                            queueWorkingSectionConfigured = false;
        //                        }
        //                    }
        //                    if (queueWorkingSectionConfigured)
        //                    {

        //                        if (queueDynamicEntity.Attributes.Contains("scrum4_timezone"))
        //                        {
        //                            queueTimeZone = Convert.ToInt32(queueDynamicEntity.Attributes["scrum4_timezone"]);
        //                        }

        //                        //Get the timezone of the user under whom the plugin execution is taking place
        //                        userContext = GetUserTimeZone(_iOrgServ, userId);
        //                        if (userContext != null && userContext.Attributes.Contains("timezonecode"))
        //                        {
        //                            userContextTimeZoneCode = ((int)userContext.Attributes["timezonecode"]);
        //                        }

        //                        if ((queueTimeZone != -1) && (userContextTimeZoneCode != -1))
        //                        {
        //                            /**CalculateTargetDate returns a DateTime Array, where the first element contains the SLA Red Time, the
        //                            second element contains the SLA Yellow Time and the third element contains the SLA Green Time**/
        //                            arrayofCalculatedDates = CalculateTargetDate(SLAHoursOfQueue, SLAHoursAfterVariance, currentQueueGuid.Id, countryGuid.Id, queueTimeZone, _iOrgServ, tracingService);

        //                            endDate = arrayofCalculatedDates[0]; //SLA Red Time
        //                            SLAYellowDate = arrayofCalculatedDates[1]; //SLA Yellow Time
        //                            startDate = arrayofCalculatedDates[2];  //SLA Green Time                   

        //                            Entity SLALogDynamicEntity = new Entity("new_slaactivity");
        //                            SLALogDynamicEntity["new_caseid"] = new EntityReference("incident", incidentGuid);
        //                            if (EmailGuid != Guid.Empty)
        //                            {
        //                                SLALogDynamicEntity["new_email"] = new EntityReference("email", EmailGuid);
        //                            }
        //                            if (HRWebActivityGuid != Guid.Empty)
        //                            {
        //                                SLALogDynamicEntity["scrum4_hrwebactivity"] = new EntityReference("new_hrwebactivity", HRWebActivityGuid);
        //                            }
        //                            if (PhoneActivityID != Guid.Empty)
        //                            {
        //                                SLALogDynamicEntity["scrum4_phonecall"] = new EntityReference("phonecall", PhoneActivityID);
        //                            }
        //                            SLALogDynamicEntity["new_name"] = sourceOfCaseCreation;

        //                            //Convert the calculated datetime which is in queue timezone to the timezone of the user, so it will be displayed correctly to the users of the same timezone as the queue timezone
        //                            SLALogDynamicEntity["new_slastartdate"] = getUserSpecificTimeFromQueueSpecificTime(startDate, queueTimeZone, userContextTimeZoneCode, _iOrgServ);
        //                            SLALogDynamicEntity["scrum4_yellowtime"] = getUserSpecificTimeFromQueueSpecificTime(SLAYellowDate, queueTimeZone, userContextTimeZoneCode, _iOrgServ);
        //                            SLALogDynamicEntity["new_slaenddate"] = getUserSpecificTimeFromQueueSpecificTime(endDate, queueTimeZone, userContextTimeZoneCode, _iOrgServ);

        //                            SLALogDynamicEntity["new_slaend"] = Convert.ToDecimal(SLAHoursOfQueue);

        //                            //new_slastate (1-Red,2-Yellow,3-Green,535,720,000-No Action Required); Default Value - Green
        //                            if (SLAState != 0)
        //                                SLALogDynamicEntity["new_slastate"] = new OptionSetValue(SLAState);
        //                            if (SLALOB != 0)
        //                                SLALogDynamicEntity["new_slalob"] = new OptionSetValue(SLALOB);
        //                            //new_slastatus (1-Open,2-Closed)
        //                            SLALogDynamicEntity["new_slastatus"] = new OptionSetValue(SLAStatus);
        //                            SLALogDynamicEntity["new_originatingqueue"] = new EntityReference("queue", originatingQueue.Id);
        //                            //Scrum4 Includes Weekend and Includes Holiday fields added on March 14, 2012 by v-pabab
        //                            if (IncludesWeekEnd)
        //                            {
        //                                SLALogDynamicEntity["scrum4_includesweekend"] = true;
        //                            }
        //                            else
        //                            {
        //                                SLALogDynamicEntity["scrum4_includesweekend"] = false;
        //                            }
        //                            if (IncludesHoliday)
        //                            {
        //                                SLALogDynamicEntity["scrum4_includesholiday"] = true;
        //                            }
        //                            else
        //                            {
        //                                SLALogDynamicEntity["scrum4_includesholiday"] = false;
        //                            }
        //                            if (ownerGuid.LogicalName == "systemuser")
        //                            {
        //                                SLALogDynamicEntity["ownerid"] = new EntityReference("systemuser", ownerGuid.Id);
        //                            }
        //                            else if (ownerGuid.LogicalName == "team")
        //                            {
        //                                SLALogDynamicEntity["ownerid"] = new EntityReference("team", ownerGuid.Id);
        //                            }
        //                            SLALogDynamicEntity["scrum4_response"] = null;
        //                            SLALogDynamicEntity["scrum4_queue"] = new EntityReference("queue", currentQueueGuid.Id);

        //                            //---Added by Raghav--Scrum 9--VSTF ID #1096743-- 
        //                            SLALogDynamicEntity["scrum9_slaconfigurationid"] = SLAConfigurationID;

        //                            workedBy = GetWorkerId(incidentGuid, _iOrgServ, tracingService);
        //                            if (workedBy != Guid.Empty)
        //                                SLALogDynamicEntity["new_caseowner"] = new EntityReference("systemuser", workedBy);

        //                            _iOrgServ.Create(SLALogDynamicEntity);
        //                        }
        //                    }
        //                    else
        //                    {
        //                        tracingService.Trace(string.Concat("Plugin_UpdateEmailPhonePlugIn", "SLA Log was not created for the Case with GUID:  " + incidentGuid.ToString() + " because the working section for the queue is not configured properly.", DateTime.Now.ToString(), "Information"));

        //                       // LogEvent("CloudCRM_HRSupport_CasePlugin", "SLA Log was not created for the Case with GUID:  " + incidentGuid.ToString() + " because the working section for the queue is not configured properly." + DateTime.Now, System.Diagnostics.EventLogEntryType.Information);
        //                    }
        //                }
        //                else
        //                {
        //                    tracingService.Trace(string.Concat("Plugin_UpdateEmailPhonePlugIn", "SLA Log was not created for the Case with GUID:  " + incidentGuid.ToString() + " because one or more parameters for calculating SLA Hours after Variance was null/invalid.", DateTime.Now.ToString(), "Information"));

        //                    //LogEvent("CloudCRM_HRSupport_CasePlugin", "SLA Log was not created for the Case with GUID:  " + incidentGuid.ToString() + " because one or more parameters for calculating SLA Hours after Variance was null/invalid." + DateTime.Now, System.Diagnostics.EventLogEntryType.Information);
        //                }
        //            }
        //            catch (FaultException<OrganizationServiceFault>)
        //            {
        //                throw;
        //            }
        //            catch (Exception)
        //            {
        //                throw;
        //            }
        //            if (traceEnabled)
        //            {
        //                tracingService.Trace(string.Concat("Plugin_UpdateEmailPhonePlugIn", "Exiting CreateSLALogs method ", DateTime.Now.ToString(), "Information"));

        //               // LogEvent("CloudCRM_HRSupport_CasePlugin", "Exiting CreateSLALogs method " + DateTime.Now, System.Diagnostics.EventLogEntryType.Information);
        //            }
        //        }
        //        # endregion
        //        #region CalculateTargetDate or Calculate SLA EndTime and SLA Yellow Time

        //        /// <summary>
        //        /// This function will calculate the SLA Endtime and SLA Yellow Time and Return a DateTime Array with these dates
        //        /// </summary>
        //        /// <param name="SLA">SLA Hours of the queue which is taken from the SLA configuration</param>
        //        /// <param name="slaAfterVariance">SLA Hours calculated from the SLA Variance that is obtained from the SLA configuration</param>
        //        /// <param name="queueId">GUID of the Queue to which email arrived</param>
        //        /// <param name="countryId">GUID of the Country to which the Queue belongs</param>
        //        /// <param name="queueTimeZone">Timezone of the Queue using which SLA calculations are made</param>
        //        /// <param name="orgService">IOrganization Service</param>
        //        /// <returns>DateTime Array</returns>
        //        //4
        //        private DateTime[] CalculateTargetDate(int SLA, double slaAfterVariance, Guid queueId, Guid countryId, int queueTimeZone, IOrganizationService orgService, ITracingService tracingService)
        //        {
        //            DateTime startDate = new DateTime();
        //            DateTime targetDate = new DateTime();
        //            DateTime yellowDate = new DateTime();
        //            DateTime tempStartDate = new DateTime();
        //            DateTime[] arrayofCalculatedDates = new DateTime[3];
        //            bool yellowdateStatus = false;
        //            EntityCollection queueCollection = null;
        //            EntityCollection holidayCollection = null;
        //            IncludesHoliday = false;
        //            IncludesWeekEnd = false;

        //            //Get the current datetime, convert it to the Queue timezone and this will be the startdate for SLA calculations and also the Greentime
        //            LocalTimeFromUtcTimeRequest request = new LocalTimeFromUtcTimeRequest();
        //            request.UtcTime = DateTime.UtcNow;
        //            request.TimeZoneCode = queueTimeZone;
        //            LocalTimeFromUtcTimeResponse response = (LocalTimeFromUtcTimeResponse)orgService.Execute(request);
        //            startDate = response.LocalTime;

        //            //Returned to set the GreenTime
        //            arrayofCalculatedDates[2] = startDate;

        //            try
        //            {
        //                if (traceEnabled)
        //                {
        //                    tracingService.Trace(string.Concat("Plugin_UpdateEmailPhonePlugIn", "Entered CalculateTargetDate method ", DateTime.Now.ToString(), "Information"));
        //                    // LogEvent("CloudCRM_HRSupport_CasePlugin", "Entered CalculateTargetDate method " + DateTime.Now, System.Diagnostics.EventLogEntryType.Information);
        //                }

        //                //Retrieve the Holidays for this particular country
        //                if (countryId != Guid.Empty)
        //                {
        //                    QueryExpression holidayQuery = new QueryExpression();
        //                    holidayQuery.EntityName = "scrum4_slaholiday";
        //                    holidayQuery.ColumnSet = new ColumnSet("scrum4_holidaydate");
        //                    holidayQuery.Criteria.AddCondition("scrum4_countryid", ConditionOperator.Equal, countryId);
        //                    holidayQuery.Criteria.AddCondition("statecode", ConditionOperator.Equal, 0);
        //                    holidayCollection = (EntityCollection)orgService.RetrieveMultiple(holidayQuery);
        //                }

        //                //Retrieve the weekends for this particular queue
        //                if (queueId != Guid.Empty)
        //                {
        //                    QueryExpression queueQuery = new QueryExpression();
        //                    queueQuery.EntityName = "queue";
        //                    queueQuery.ColumnSet = new ColumnSet("scrum4_monday", "scrum4_tuesday", "scrum4_wednesday", "scrum4_thursday", "scrum4_friday", "scrum4_saturday", "scrum4_sunday");
        //                    queueQuery.Criteria.AddCondition("queueid", ConditionOperator.Equal, queueId);
        //                    queueCollection = (EntityCollection)orgService.RetrieveMultiple(queueQuery);
        //                }

        //                //Check if the current day is holiday/weekend and increment the starting date if it is holiday/weekend
        //                while (cmncode.CheckDeclaredHoliday(startDate, countryId, holidayCollection, queueCollection, orgService, tracingService))
        //                {
        //                    startDate = startDate.Date.AddDays(1);
        //                }

        //                //Set the initial targetDate and yellowDate by adding the SLA and SLAAfterVariance hours
        //                targetDate = startDate.AddHours(SLA);
        //                targetDate = targetDate.AddMilliseconds(-1);
        //                yellowDate = startDate.AddHours(slaAfterVariance);
        //                yellowDate = yellowDate.AddMilliseconds(-1);

        //                if (startDate.Date == yellowDate.Date)
        //                    yellowdateStatus = true;

        //                for (tempStartDate = startDate.AddDays(1); tempStartDate.Date <= targetDate.Date; tempStartDate = tempStartDate.AddDays(1))
        //                {
        //                    if (cmncode.CheckDeclaredHoliday(tempStartDate, countryId, holidayCollection, queueCollection, orgService, tracingService))
        //                    {
        //                        targetDate = targetDate.AddDays(1);
        //                        if (!yellowdateStatus)
        //                            yellowDate = yellowDate.AddDays(1);
        //                    }
        //                    else if (yellowDate.Date == tempStartDate.Date)
        //                    {
        //                        yellowdateStatus = true;
        //                    }
        //                }

        //            }
        //            catch (FaultException<OrganizationServiceFault>)
        //            {
        //                throw;
        //            }
        //            catch (Exception)
        //            {
        //                throw;
        //            }
        //            //targetDate is SLA End Date           
        //            arrayofCalculatedDates[0] = targetDate;
        //            //yellowDate is SLA Yellow Date
        //            arrayofCalculatedDates[1] = yellowDate;

        //            if (traceEnabled)
        //            {
        //                tracingService.Trace(string.Concat("Plugin_UpdateEmailPhonePlugIn", "Exited CalculateTargetDate method ", DateTime.Now.ToString(), "Information"));

        //                //LogEvent("CloudCRM_HRSupport_CasePlugin", "Exited CalculateTargetDate method " + DateTime.Now, System.Diagnostics.EventLogEntryType.Information);
        //            }
        //            return arrayofCalculatedDates;
        //        }
        //        #endregion
        //        # region "getUserSpecificTimeFromQueueSpecificTime"
        //        /// <summary>
        //        /// Converts Queue timezone datetime to user timezone datetime
        //        /// </summary>
        //        /// <param name="sourceDateTime"></param>
        //        /// <param name="sourceTimeZoneCode"></param>
        //        /// <param name="destinationTimeZoneCode"></param>
        //        /// <param name="organizationServ"></param>
        //        /// <returns></returns>
        //        private DateTime getUserSpecificTimeFromQueueSpecificTime(DateTime sourceDateTime, int sourceTimeZoneCode, int destinationTimeZoneCode, IOrganizationService organizationServ)
        //        {
        //            DateTime destinationDateTime = DateTime.UtcNow;
        //            try
        //            {

        //                //Convert Source DateTime to UTC
        //                UtcTimeFromLocalTimeRequest utcFromLocalRequest = new UtcTimeFromLocalTimeRequest();
        //                utcFromLocalRequest.LocalTime = sourceDateTime;
        //                utcFromLocalRequest.TimeZoneCode = sourceTimeZoneCode;
        //                UtcTimeFromLocalTimeResponse utcFromLocalResponse = (UtcTimeFromLocalTimeResponse)organizationServ.Execute(utcFromLocalRequest);

        //                //Convert UTC DateTime to Destination TimeZone
        //                LocalTimeFromUtcTimeRequest localFromUtcRequest = new LocalTimeFromUtcTimeRequest();
        //                localFromUtcRequest.UtcTime = utcFromLocalResponse.UtcTime;
        //                localFromUtcRequest.TimeZoneCode = destinationTimeZoneCode;
        //                LocalTimeFromUtcTimeResponse localFromUtcResponse = (LocalTimeFromUtcTimeResponse)organizationServ.Execute(localFromUtcRequest);

        //                destinationDateTime = localFromUtcResponse.LocalTime;

        //            }
        //            catch (FaultException<OrganizationServiceFault>)
        //            {
        //                throw;
        //            }
        //            catch (Exception)
        //            {
        //            }
        //            return destinationDateTime;
        //        }

        //        # endregion
        //        #region ConvertUTCtoAnyTimezone
        //        private DateTime ConvertUTCtoAnyTimezone(DateTime utcDateTime, int destinationTimeZoneCode, IOrganizationService organizationServ)
        //        {
        //            try
        //            {
        //                DateTime destinationDateTime = DateTime.UtcNow;
        //                LocalTimeFromUtcTimeRequest request = new LocalTimeFromUtcTimeRequest();
        //                request.UtcTime = utcDateTime;
        //                request.TimeZoneCode = destinationTimeZoneCode;
        //                LocalTimeFromUtcTimeResponse response = (LocalTimeFromUtcTimeResponse)organizationServ.Execute(request);
        //                destinationDateTime = response.LocalTime;
        //                return destinationDateTime;
        //            }
        //            catch (FaultException<OrganizationServiceFault>)
        //            {
        //                throw;
        //            }
        //            catch (Exception)
        //            {
        //                throw;
        //            }
        //        }
        //        #endregion
        //        #region Check Holiday in SLA Holiday Entity
        //        /// <summary>
        //        /// This Function will Return whether the given date is holiday in Holiday Entity
        //        /// </summary>
        //        /// <param name="currentDate">Date which needs to be checked for declared holiday</param>
        //        /// <param name="queueCountryId">Country of the Queue</param>
        //        /// <param name="holidayColl">Holiday entity collection for the particular country</param>
        //        /// <param name="queueEntCollection">Queue Entity collection to get the weekdays for the particular queue</param>
        //        /// <returns>true when the currentDate is declared holiday or false when the currentDate is not a declared holiday </returns>

        //        private bool CheckDeclaredHoliday(DateTime currentDate, Guid queueCountryId, EntityCollection holidayColl, EntityCollection queueEntCollection, IOrganizationService iOrgService, ITracingService tracingService)
        //        {
        //            try
        //            {
        //                if (traceEnabled)
        //                {
        //                    tracingService.Trace(string.Concat("Plugin_UpdateEmailPhonePlugIn", "Entered CheckDeclaredHoliday method ", DateTime.Now.ToString(), "Information"));

        //                    //LogEvent("CloudCRM_HRSupport_CasePlugin", "Entered CheckDeclaredHoliday method " + DateTime.Now, System.Diagnostics.EventLogEntryType.Information);
        //                }
        //                bool isHoliday = false;

        //                if (queueCountryId != Guid.Empty)
        //                {
        //                    if (holidayColl != null && holidayColl.Entities.Count > 0)
        //                    {
        //                        foreach (Entity entHol in holidayColl.Entities)
        //                        {
        //                            if (entHol.Attributes.Contains("scrum4_holidaydate"))
        //                            {
        //                                //On the right hand side, we are converting the retrieved holiday date to the PST timezone by passing timezonecode as 4 to the ConvertUTCtoAnyTimezone method,
        //                                //so that the retrieved date will be always according to the PST timzone (as we are creating holidays according to PST timezone)
        //                                if (currentDate.Date == (ConvertUTCtoAnyTimezone(((DateTime)entHol.Attributes["scrum4_holidaydate"]), 4, iOrgService).Date))
        //                                {
        //                                    isHoliday = true;
        //                                    IncludesHoliday = true;
        //                                    break;
        //                                }
        //                                else
        //                                    isHoliday = false;
        //                            }
        //                        }
        //                    }
        //                }

        //                if (!isHoliday)
        //                {
        //                    isHoliday = CheckWeekEnds(currentDate, queueEntCollection, tracingService);
        //                }

        //                if (traceEnabled)
        //                {
        //                    tracingService.Trace(string.Concat("Plugin_UpdateEmailPhonePlugIn", "Exited CheckDeclaredHoliday method ", DateTime.Now.ToString(), "Information"));

        //                    //LogEvent("CloudCRM_HRSupport_CasePlugin", "Exited CheckDeclaredHoliday method " + DateTime.Now, System.Diagnostics.EventLogEntryType.Information);
        //                }
        //                return isHoliday;

        //            }
        //            catch (FaultException<OrganizationServiceFault>)
        //            {
        //                throw;
        //            }
        //            catch (Exception)
        //            {
        //                throw;
        //            }
        //        }

        //        #endregion
        //        #region Check WeekEnd
        //        /// <summary>
        //        /// This Function will Return the given date is weekend or not
        //        /// </summary>
        //        /// <param name="presentDate">Date which should be checked for weekend or weekday</param>
        //        /// <param name="queueColl">Retrieved Queue entity collection to get the queue's weekdays</param>       
        //        /// <returns>true when the presentDate is a weekend and false when the presentDate is not a weekend</returns>
        //        private bool CheckWeekEnds(DateTime presentDate, EntityCollection queueColl, ITracingService tracingService)
        //        {
        //            try
        //            {

        //                if (traceEnabled)
        //                {
        //                    tracingService.Trace(string.Concat("Plugin_UpdateEmailPhonePlugIn", "Entered CheckWeekEnds method ", DateTime.Now.ToString(), "Information"));

        //                    // LogEvent("CloudCRM_HRSupport_CasePlugin", "Entered CheckWeekEnds method " + DateTime.Now, System.Diagnostics.EventLogEntryType.Information);
        //                }
        //                bool monday = false;
        //                bool tuesday = false;
        //                bool wednesday = false;
        //                bool thursday = false;
        //                bool friday = false;
        //                bool saturday = false;
        //                bool sunday = false;
        //                string weekday = string.Empty;
        //                weekday = presentDate.DayOfWeek.ToString().ToLower();
        //                bool isholiday = false;

        //                if (queueColl != null && queueColl.Entities.Count > 0 && !string.IsNullOrEmpty(weekday))
        //                {
        //                    Entity entQueue = (Entity)queueColl.Entities[0];

        //                    switch (weekday)
        //                    {
        //                        case "monday":
        //                            if (entQueue.Attributes.Contains("scrum4_monday"))
        //                                monday = ((bool)entQueue.Attributes["scrum4_monday"]);
        //                            if (!monday)
        //                                isholiday = true;
        //                            else
        //                                isholiday = false;
        //                            break;
        //                        case "tuesday":
        //                            if (entQueue.Attributes.Contains("scrum4_tuesday"))
        //                                tuesday = ((bool)entQueue.Attributes["scrum4_tuesday"]);
        //                            if (!tuesday)
        //                                isholiday = true;
        //                            else
        //                                isholiday = false;
        //                            break;
        //                        case "wednesday":
        //                            if (entQueue.Attributes.Contains("scrum4_wednesday"))
        //                                wednesday = ((bool)entQueue.Attributes["scrum4_wednesday"]);
        //                            if (!wednesday)
        //                                isholiday = true;
        //                            else
        //                                isholiday = false;
        //                            break;
        //                        case "thursday":
        //                            if (entQueue.Attributes.Contains("scrum4_thursday"))
        //                                thursday = ((bool)entQueue.Attributes["scrum4_thursday"]);
        //                            if (!thursday)
        //                                isholiday = true;
        //                            else
        //                                isholiday = false;
        //                            break;
        //                        case "friday":
        //                            if (entQueue.Attributes.Contains("scrum4_friday"))
        //                                friday = ((bool)entQueue.Attributes["scrum4_friday"]);
        //                            if (!friday)
        //                                isholiday = true;
        //                            else
        //                                isholiday = false;
        //                            break;
        //                        case "saturday":
        //                            if (entQueue.Attributes.Contains("scrum4_saturday"))
        //                                saturday = ((bool)entQueue.Attributes["scrum4_saturday"]);
        //                            if (!saturday)
        //                                isholiday = true;
        //                            else
        //                                isholiday = false;
        //                            break;
        //                        case "sunday":
        //                            if (entQueue.Attributes.Contains("scrum4_sunday"))
        //                                sunday = ((bool)entQueue.Attributes["scrum4_sunday"]);
        //                            if (!sunday)
        //                                isholiday = true;
        //                            else
        //                                isholiday = false;
        //                            break;
        //                    }
        //                }
        //                if (isholiday)
        //                {
        //                    IncludesWeekEnd = true;
        //                }
        //                if (traceEnabled)
        //                {
        //                    tracingService.Trace(string.Concat("Plugin_UpdateEmailPhonePlugIn", "Exited CheckWeekEnds method ", DateTime.Now.ToString(), "Information"));

        //                    //LogEvent("CloudCRM_HRSupport_CasePlugin", "Exited CheckWeekEnds method " + DateTime.Now, System.Diagnostics.EventLogEntryType.Information);
        //                }
        //                return isholiday;
        //            }
        //            catch (FaultException<OrganizationServiceFault>)
        //            {
        //                throw;
        //            }
        //            catch (Exception)
        //            {
        //                throw;
        //            }
        //        }
        //        #endregion
        //        # region Get Logged In User Local Time From UTC Time
        //        private DateTime GetLoggedInUserLocalTimeFromUTCTime(IOrganizationService _orgService, DateTime utcDate, Guid userId)
        //        {
        //            Entity loggedInUser = null;
        //            int timeZoneCode = 0;
        //            try
        //            {
        //                loggedInUser = GetUserTimeZone(_orgService, userId);
        //                if (loggedInUser != null && loggedInUser.Attributes.Contains("timezonecode"))
        //                {
        //                    timeZoneCode = ((int)loggedInUser.Attributes["timezonecode"]);
        //                }
        //                LocalTimeFromUtcTimeRequest request = new LocalTimeFromUtcTimeRequest();
        //                request.UtcTime = utcDate;
        //                request.TimeZoneCode = timeZoneCode;
        //                LocalTimeFromUtcTimeResponse response = (LocalTimeFromUtcTimeResponse)_orgService.Execute(request);
        //                return response.LocalTime;
        //            }
        //            catch (FaultException<OrganizationServiceFault>)
        //            {
        //                throw;
        //            }
        //            catch (Exception)
        //            {
        //                throw;
        //            }
        //        }
        //        # endregion
        //        # region GetUserTimeZone

        //        private Entity GetUserTimeZone(IOrganizationService service, Guid userId)
        //        {
        //            try
        //            {
        //                RetrieveUserSettingsSystemUserRequest request = new RetrieveUserSettingsSystemUserRequest();
        //                request.ColumnSet = new ColumnSet("timezonecode");
        //                request.EntityId = userId;
        //                RetrieveUserSettingsSystemUserResponse response = (RetrieveUserSettingsSystemUserResponse)service.Execute(request);
        //                return response.Entity;
        //            }
        //            catch (FaultException<OrganizationServiceFault>)
        //            {
        //                throw;
        //            }
        //            catch (Exception)
        //            {
        //                throw;
        //            }
        //        }
        //        # endregion
        //        #region GetWorkerId
        //        /// <summary>
        //        /// This function get the Workedby value of the Queue Item for a Case
        //        /// </summary>
        //        /// <param name="caseId">Case guid from which the Workedby value of its Queueitem should be retrieved</param>
        //        /// <param name="iOrgServ">IOrganizationService</param>
        //        /// <returns></returns>
        //        private Guid GetWorkerId(Guid caseId, IOrganizationService iOrgServ, ITracingService tracingService)
        //        {
        //            try
        //            {
        //                // tracingService.Trace("Entered GetWorkerId method.");
        //                Guid workerId = Guid.Empty;

        //                QueryExpression queueItemQuery = new QueryExpression();
        //                queueItemQuery.EntityName = "queueitem";
        //                queueItemQuery.ColumnSet = new ColumnSet("workerid");
        //                queueItemQuery.Criteria.AddCondition("objectid", ConditionOperator.Equal, caseId);
        //                EntityCollection queueItemColl = (EntityCollection)iOrgServ.RetrieveMultiple(queueItemQuery);

        //                if (queueItemColl.Entities.Count > 0)
        //                {
        //                    Entity entQueueItem = (Entity)queueItemColl.Entities[0];
        //                    if (entQueueItem.Attributes.Contains("workerid"))
        //                        workerId = ((EntityReference)entQueueItem.Attributes["workerid"]).Id;
        //                }
        //                return workerId;
        //            }
        //            catch (FaultException<OrganizationServiceFault>)
        //            {
        //                throw;
        //            }
        //            catch (Exception)
        //            {
        //                throw;
        //            }
        //        }
        //        #endregion
        //        #region LogEvent
        //        /// <summary>
        //        /// Used to log errors to Event viewer
        //        /// </summary>
        //        /// <param name="strSource"></param>
        //        /// <param name="strMessage"></param>
        //        /// <param name="eventLogType"></param>
        //        private static void LogEvent(string strSource, string strMessage, System.Diagnostics.EventLogEntryType eventLogType)
        //        {
        //            if (System.Diagnostics.EventLog.SourceExists(strSource) == false)
        //            {
        //                System.Diagnostics.EventLog.CreateEventSource(strSource, "HRSupport");
        //            }
        //            else if (eventLogType.ToString().ToLower() == "error" || eventLogType.ToString().ToLower() == "information")
        //            {
        //                System.Diagnostics.EventLog.WriteEntry(strSource, strMessage, eventLogType);
        //            }
        //        }
        //        #endregion
        #endregion
    }

    //Plug In Configuration class to retrieve corresponding values for the passed in keys from an unsecured configuration
    public static class PluginConfiguration
    {
        private static string GetValueNode(XmlDocument doc, string key)
        {
            XmlNode node = doc.SelectSingleNode(String.Format("Settings/setting[@name='{0}']", key));
            if (node != null)
            {
                return node.SelectSingleNode("value").InnerText;
            }
            return string.Empty;
        }
        public static Guid GetConfigDataGuid(XmlDocument doc, string label)
        {
            string tempString = GetValueNode(doc, label);
            if (tempString != string.Empty)
            {
                return new Guid(tempString);
            }
            return Guid.Empty;
        }
        public static bool GetConfigDataBool(XmlDocument doc, string label)
        {
            bool retVar;
            if (bool.TryParse(GetValueNode(doc, label), out retVar))
            {
                return retVar;
            }
            else
            {
                return false;
            }
        }
        public static int GetConfigDataInt(XmlDocument doc, string label)
        {
            int retVar;
            if (int.TryParse(GetValueNode(doc, label), out retVar))
            {
                return retVar;
            }
            else
            {
                return -1;
            }
        }
        public static string GetConfigDataString(XmlDocument doc, string label)
        {
            return GetValueNode(doc, label);
        }
    }

    public class SizeExceedException : Exception
    {
        public SizeExceedException(string message) : base(message) { }
    }
}