﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using Microsoft.Crm;
using Microsoft.Crm.Sdk.Messages;
using Microsoft.Xrm;
//using Microsoft.Xrm.Client;
using Microsoft.Xrm.Sdk;
using Microsoft.Xrm.Sdk.Query;
using System.ServiceModel;

namespace CommonCode
{
    public class CommonCodeDraft
    {
        //IOrganizationService _iOrgService = null;
        Entity entIncident = null;
        // bool emailDirection;
        bool traceEnabled = false;
        bool IncludesHoliday = false;
        bool IncludesWeekEnd = false;
        string strMessage = string.Empty;

        public enum EntityTypeValues : int { Contact = 1, EDMActivity = 2, HRWebActivity = 3 } ;
        public enum EntityStateValues { Active, Inactive };
        public enum CasePriorityValues { Critical = 1, High, Medium, Low };
        public enum CaseTierValues { Tier1 = 1, Tier2, Tier3 };
        public enum CustomerSource { External = 1, Internal };

        public enum CaseOrigins
        {
            Phone = 1,
            Email,
            Web,
            Chat = 5,
            Walkin,
            Post,
            EDMTool
        }

        public enum CaseState
        {
            InProgress = 100000000,
            Validate,
            Researching,
            New,
            Misrouted,
            PendingClosure,
            IncorrectInput = 873470001,
            FutureTask = 590450000,
            FailedQC = 873470000,
            AwaitingCustomerResponse = 100000011
        }

        #region Create SLA Logs
        public void CreateSLALogMain(IOrganizationService _iOrgService, Guid activityID, Guid incidentID, DateTime createdOn, string sourceOfSLALogCreation, Guid userId, ITracingService tracingService, bool traceEnabled)
        {
            if (traceEnabled)
            {
                tracingService.Trace(string.Concat("CommomCode_CreateSLALogMain", DateTime.Now.ToString()));
            }

            string typeofActivity = string.Empty;

            FunctionArguments funcArgs = new FunctionArguments();

            funcArgs = SetSLALogData(_iOrgService, incidentID, createdOn, userId, tracingService, traceEnabled);
            CreateSLALogs(sourceOfSLALogCreation, activityID, 1, 3, funcArgs, tracingService, traceEnabled);



            //if (!isManual && !ownerChange)
            //{
            //    if (sourceOfSLALogCreation == "Incoming")
            //    {
            //        emailDirection = GetEmailDirection(activityID);
            //        if (!emailDirection)
            //        {
            //            //funcArgs = SetSLALogData(_iOrgService, activityID, incidentID, sourceOfSLALogCreation);
            //           // CreateSLALogs("Incoming", activityID, 1, 0, funcArgs);
            //        }
            //    }
            //    else if (sourceOfSLALogCreation == "EDM Activity")
            //    {
            //       // funcArgs = SetSLALogData(_iOrgService,incidentID);
            //        CreateSLALogs(typeofActivity, activityID, 1, 3, funcArgs);
            //    }
            //    else if (sourceOfSLALogCreation == "HR Web Activity")
            //    {
            //        //funcArgs = SetSLALogData(_iOrgService, activityID, incidentID, sourceOfSLALogCreation);
            //        CreateSLALogs(typeofActivity, activityID, 1, 3, funcArgs);
            //    }
            //    else if (sourceOfSLALogCreation == "Phone Call")
            //    {
            //        //funcArgs = SetSLALogData(_iOrgService, activityID, incidentID, sourceOfSLALogCreation);
            //        CreateSLALogs(typeofActivity, activityID, 1, 3, funcArgs);
            //    }
            //    else if (sourceOfSLALogCreation == "RM Activity")
            //    {
            //        //funcArgs = SetSLALogData(_iOrgService, activityID, incidentID, sourceOfSLALogCreation);
            //        CreateSLALogs(typeofActivity, activityID, 1, 3, funcArgs);
            //    }
            //}
            //else if (isManual)
            //{
            //    funcArgs = SetSLALogData(_iOrgService, Guid.Empty, incidentID, "Manual");
            //    CreateSLALogs("Manual", Guid.Empty, 1, 3, funcArgs);
            //}
            //else if (ownerChange)
            //{
            //    funcArgs = SetSLALogData(_iOrgService, Guid.Empty, incidentID, "Owner Change");
            //    CreateSLALogs("Owner Change", Guid.Empty, 1, 3, funcArgs);
            //}
        }

        private FunctionArguments SetSLALogData(IOrganizationService _iOrgService, Guid incidentID, DateTime createdOn, Guid _userID, ITracingService tracingService, bool traceEnabled)
        {
            if (traceEnabled)
            {
                tracingService.Trace(string.Concat("CommomCode_SetSLALogData", DateTime.Now.ToString()));
            }

            Guid queueId = Guid.Empty;
            Guid countryId = Guid.Empty;
            // int priority = 0;
            int LOB = 0;
            EntityReference _originatingQueue = null;
            EntityReference _caseOwner = null;
            Entity queueEntityObject = null;
            bool queueWorkingSectionConfigured = true;
            int queueTimeZoneCode = -1;
            int userTimeZoneCode = -1;
            Entity userSettingsEnt = null;
            int caseOrigin = 0;
            int casePriority = 0;
            int caseType = 0;
            DateTime slaEndDate = new DateTime();
            DateTime slaYellowDate = new DateTime();
            FunctionArguments funcArgs = new FunctionArguments();

            try
            {
                //updated type and origin -- v-degort
                entIncident = (Entity)_iOrgService.Retrieve("incident", incidentID, new ColumnSet(new string[] { "new_currentqueue", "scrum4_queuecountryid", "prioritycode", "new_lob", "new_queuenameid", "ownerid", "scrum4_caseorigin", "scrum9_casetype" }));

                if (entIncident != null)
                {
                    if (entIncident.Attributes.Contains("new_currentqueue") && entIncident.Attributes.Contains("prioritycode"))
                    {
                        queueId = ((EntityReference)entIncident.Attributes["new_currentqueue"]).Id;

                        if (entIncident.Attributes.Contains("scrum4_queuecountryid"))
                            countryId = ((EntityReference)entIncident.Attributes["scrum4_queuecountryid"]).Id;

                        if (entIncident.Attributes.Contains("prioritycode"))
                            casePriority = ((OptionSetValue)entIncident.Attributes["prioritycode"]).Value;

                        if (entIncident.Attributes.Contains("new_lob"))
                            LOB = ((OptionSetValue)entIncident.Attributes["new_lob"]).Value;

                        if (entIncident.Attributes.Contains("new_queuenameid"))
                            _originatingQueue = (EntityReference)entIncident["new_queuenameid"];


                        if (entIncident.Attributes.Contains("ownerid"))
                            _caseOwner = (EntityReference)entIncident["ownerid"];

                        if (entIncident.Attributes.Contains("scrum4_caseorigin"))
                            caseOrigin = ((OptionSetValue)entIncident.Attributes["scrum4_caseorigin"]).Value;

                        if (entIncident.Attributes.Contains("scrum9_casetype"))
                            caseType = ((OptionSetValue)entIncident.Attributes["scrum9_casetype"]).Value;

                        //if unable to retrieve the current queue or country of the case, do not create SLA Log
                        if ((queueId != Guid.Empty) && (countryId != Guid.Empty))
                        {

                            //Retrieve the working section and timezone from the current queue
                            queueEntityObject = (Entity)_iOrgService.Retrieve("queue", queueId, new ColumnSet("scrum4_monday", "scrum4_tuesday", "scrum4_wednesday", "scrum4_thursday", "scrum4_friday", "scrum4_saturday", "scrum4_sunday", "scrum4_timezone"));

                            if (queueEntityObject != null)
                            {
                                //check if queue working section is configured or not.  If queue working section is not configured, then sla logs would not be created
                                //If all the working section fields are not null
                                if (queueEntityObject.Attributes.Contains("scrum4_monday") && queueEntityObject.Attributes.Contains("scrum4_tuesday") && queueEntityObject.Attributes.Contains("scrum4_wednesday") && queueEntityObject.Attributes.Contains("scrum4_thursday") && queueEntityObject.Attributes.Contains("scrum4_friday") && queueEntityObject.Attributes.Contains("scrum4_saturday") && queueEntityObject.Attributes.Contains("scrum4_sunday"))
                                {

                                    //Only if not all the working section checkboxes are unchecked (all days are false), we would proceed with the logic
                                    if ((!((bool)queueEntityObject.Attributes["scrum4_monday"])) && (!((bool)queueEntityObject.Attributes["scrum4_tuesday"])) && (!((bool)queueEntityObject.Attributes["scrum4_wednesday"])) && (!((bool)queueEntityObject.Attributes["scrum4_thursday"])) && (!((bool)queueEntityObject.Attributes["scrum4_friday"])) && (!((bool)queueEntityObject.Attributes["scrum4_saturday"])) && (!((bool)queueEntityObject.Attributes["scrum4_sunday"])))
                                    {
                                        queueWorkingSectionConfigured = false;
                                    }
                                }
                                else
                                {
                                    queueWorkingSectionConfigured = false;
                                }
                            }
                            else
                            {
                                //LogEvent("CloudCRM_HRSupport_CreateSLALog", "Unable to retrieve Queue details, so SLA Log was not created for the Case with GUID:  " + entIncident.Id.ToString(), System.Diagnostics.EventLogEntryType.Error);
                                throw new InvalidPluginExecutionException("Unable to retrieve Queue details, so SLA Log was not created for the Case with GUID:  " + entIncident.Id.ToString());
                            }

                            if (queueWorkingSectionConfigured)
                            {
                                if (queueEntityObject.Attributes.Contains("scrum4_timezone"))
                                {
                                    queueTimeZoneCode = Convert.ToInt32(queueEntityObject.Attributes["scrum4_timezone"]);
                                }

                                //Retrieve the plugin context user's timezonecode 
                                userSettingsEnt = GetUserTimeZone(_iOrgService, _userID, tracingService);

                                if (userSettingsEnt != null && userSettingsEnt.Attributes.Contains("timezonecode"))
                                {
                                    userTimeZoneCode = ((int)userSettingsEnt.Attributes["timezonecode"]);
                                }

                                //if unable to retrieve the timezonecode of either queue or user, do not create SLA Log
                                if ((queueTimeZoneCode != -1) && (userTimeZoneCode != -1))
                                {

                                    SLALogBAL slaLogBAL = new SLALogBAL();
                                    EntityCollection queueSpecificSLARecords = slaLogBAL.FetchSLAConfigurations(queueId, casePriority, caseOrigin, caseType, _iOrgService, tracingService, traceEnabled);
                                    if (queueSpecificSLARecords.Entities.Count > 0)
                                    {
                                        slaLogBAL.SetSLAParameters(queueSpecificSLARecords);
                                    }
                                    else
                                    {
                                        EntityCollection universalSLARecords = slaLogBAL.FetchSLAConfigurations(casePriority, caseOrigin, caseType, _iOrgService, tracingService, traceEnabled);
                                        if (universalSLARecords.Entities.Count > 0)
                                        {
                                            slaLogBAL.SetSLAParameters(universalSLARecords);
                                        }
                                        else
                                        {
                                            EntityCollection defaultSLARecords = slaLogBAL.FetchSLAConfigurations(_iOrgService, tracingService, traceEnabled);
                                            if (defaultSLARecords.Entities.Count > 0)
                                            {
                                                slaLogBAL.SetSLAParameters(defaultSLARecords);
                                            }
                                        }
                                    }

                                    //We are checking if the necessary parameters are retrieved from the SLA Configuration record
                                    //If the necessary parameters are not there then exit the function and no SLA Logs will be created for the activity
                                    if (slaLogBAL.SLAHours == -1 || slaLogBAL.SLAAfterVariance == double.NaN || slaLogBAL.SLAConfigurationID == string.Empty || _caseOwner.Id == Guid.Empty || countryId == Guid.Empty || LOB == -1)
                                    {
                                        //LogEvent("HRSupport", "No valid SLA configurations found for case id- " + incidentID.ToString(), System.Diagnostics.EventLogEntryType.Error);
                                        // return;
                                    }

                                    //Create a object of the FunctionArguments class to pass parameters from and to each methods

                                    //v-degort 
                                    //if (typeofActivity == "email")
                                    //{ funcArgs.emailCreatedDate = emailCreatedOn; }
                                    //if (typeofActivity == "edm")
                                    //{ funcArgs.edmCreatedDate = edmCreatedDate; }
                                    //if (typeofActivity == "hrweb")
                                    //{ funcArgs.hrWebCreatedDate = hrWebCreatedDate; }
                                    //if (typeofActivity == "phone")
                                    //{ funcArgs.emailCreatedDate = emailCreatedOn; }

                                    funcArgs.CreatedDate = createdOn;
                                    //funcArgs.slaHours = slaHours;
                                    //funcArgs.slaAfterVariance = slaAfterVariance;
                                    funcArgs.slaHours = slaLogBAL.SLAHours;
                                    funcArgs.slaAfterVariance = slaLogBAL.SLAAfterVariance;
                                    funcArgs.SLAConfigurationId = slaLogBAL.SLAConfigurationID;
                                    funcArgs.LOB = LOB;
                                    funcArgs.queueId = queueId;
                                    funcArgs.caseGuid = entIncident.Id;
                                    funcArgs.queueEntityObj = queueEntityObject;

                                    funcArgs.queueCountryId = countryId;
                                    funcArgs.queueTimeZone = queueTimeZoneCode;
                                    funcArgs.userTimeZone = userTimeZoneCode;
                                    funcArgs.organizationService = _iOrgService;
                                    funcArgs.tracingService = tracingService;

                                    if (_originatingQueue != null)
                                    {
                                        funcArgs.caseOriginatingQueue = _originatingQueue;
                                    }

                                    if (_caseOwner != null)
                                    {
                                        funcArgs.caseOwner = _caseOwner;
                                    }


                                    /**CalculateTargetDate returns a DateTime Array, where the first element contains the SLA End Date and the
                                    second element contains the SLA Yellow Date, the third element contains the Green Time according to Queue Time Zone**/

                                    funcArgs = CalculateTargetDate(funcArgs);

                                    slaEndDate = funcArgs.slaEndDate;

                                    slaYellowDate = funcArgs.slaYellowDate;
                                }
                            }
                        }
                    }
                }
            }
            catch (FaultException<OrganizationServiceFault> ex)
            {
                strMessage = "FaultException - " + Environment.NewLine;
                strMessage += "Message:  " + ex.Message + Environment.NewLine;
                strMessage += "Source:  " + ex.Source + Environment.NewLine;
                strMessage += "Stack Trace:  " + ex.StackTrace + Environment.NewLine;
                strMessage += "Time Stamp: " + ex.Detail.Timestamp + Environment.NewLine;
                strMessage += "Code: " + ex.Detail.ErrorCode + Environment.NewLine;
                strMessage += "Message: " + ex.Detail.Message + Environment.NewLine;
                strMessage += "Trace: " + ex.Detail.TraceText + Environment.NewLine;
                if (ex.InnerException != null)
                {
                    strMessage += "InnerException: " + ex.InnerException.Message + Environment.NewLine;
                }
                tracingService.Trace(string.Concat("CommonCode_SetSLALogData", strMessage, DateTime.Now.ToString()));
            }
            catch (System.TimeoutException ex)
            {
                strMessage = "TimeoutException - " + Environment.NewLine;
                strMessage += "Message:  " + ex.Message + Environment.NewLine;
                strMessage += "Stack Trace:  " + ex.StackTrace + Environment.NewLine;
                if (ex.InnerException != null)
                {
                    strMessage += "InnerException: " + ex.InnerException.Message + Environment.NewLine;
                }
                tracingService.Trace(string.Concat("CommonCode_SetSLALogData", strMessage, DateTime.Now.ToString()));
            }
            catch (Exception ex)
            {
                strMessage = "Exception - " + Environment.NewLine;
                strMessage += "Message:  " + ex.Message + Environment.NewLine;
                strMessage += "Stack Trace:  " + ex.StackTrace + Environment.NewLine;
                if (ex.InnerException != null)
                {
                    strMessage += "InnerException: " + ex.InnerException.Message + Environment.NewLine;
                }
                tracingService.Trace(string.Concat("CommonCode_SetSLALogData", strMessage, DateTime.Now.ToString()));
            }
            return funcArgs;
        }

        private string GetActivityType(Guid activityID)
        {
            string activityType = string.Empty;
            return activityType;
        }

        private bool GetEmailDirection(Guid activityID)
        {
            bool isIncoming = false;

            return isIncoming;

        }

        private void CreateSLALogs(string sourceOfSLALogCreation, Guid ActivityGuid, int status, int slaState, FunctionArguments funcArgs, ITracingService tracingService, bool traceEnabled)
        {
            if (traceEnabled)
            {
                tracingService.Trace(string.Concat("CommomCode_CreateSLALogs", DateTime.Now.ToString()));
            }
            try
            {
                funcArgs.tracingService.Trace("Entered CreateSLAActivities method.  Time:  " + DateTime.Now.ToString());
                Guid workedBy = Guid.Empty;


                if (funcArgs.caseGuid != Guid.Empty)
                {
                    Entity entCreateSLAActivity = new Entity("new_slaactivity");
                    entCreateSLAActivity["new_caseid"] = new EntityReference("incident", funcArgs.caseGuid);
                    if (sourceOfSLALogCreation == "Incoming")
                    {
                        entCreateSLAActivity["new_email"] = new EntityReference("email", ActivityGuid);
                    }
                    if (sourceOfSLALogCreation == "EDM Activity")
                    {
                        entCreateSLAActivity["scrum8_edmactivity"] = new EntityReference("scrum8_edmactivity", ActivityGuid);
                    }
                    if (sourceOfSLALogCreation == "HR Web Activity")
                    {
                        entCreateSLAActivity["scrum4_hrwebactivity"] = new EntityReference("new_hrwebactivity", ActivityGuid);
                    }
                    if (sourceOfSLALogCreation == "Phone Call")
                    {
                        entCreateSLAActivity["scrum4_phonecall"] = new EntityReference("phonecall", ActivityGuid);
                    }
                    if (sourceOfSLALogCreation == "RM Activity")
                    {
                        entCreateSLAActivity["release9_reqactivityid"] = new EntityReference("release9_staffingrequisition", ActivityGuid);
                    }

                    entCreateSLAActivity["new_respondeddate"] = null;
                    entCreateSLAActivity["new_name"] = sourceOfSLALogCreation;
                    entCreateSLAActivity["new_slastartdate"] = funcArgs.CreatedDateinUserTimeZone;
                    entCreateSLAActivity["new_slaenddate"] = funcArgs.slaEndDate;
                    entCreateSLAActivity["new_slaend"] = (decimal)funcArgs.slaHours;

                    //Calculated Yellow Date passed to this function is put into the SLA Log Entity
                    entCreateSLAActivity["scrum4_yellowtime"] = funcArgs.slaYellowDate;

                    if (slaState != 0)
                        entCreateSLAActivity["new_slastate"] = new OptionSetValue(slaState);

                    if (funcArgs.LOB != 0)
                        entCreateSLAActivity["new_slalob"] = new OptionSetValue(funcArgs.LOB);

                    entCreateSLAActivity["new_slastatus"] = new OptionSetValue(status);

                    if (funcArgs.caseOriginatingQueue != null)
                        entCreateSLAActivity["new_originatingqueue"] = funcArgs.caseOriginatingQueue;

                    if (funcArgs.includesWeekendAttribute)
                    {
                        entCreateSLAActivity["scrum4_includesweekend"] = true;
                    }
                    else
                    {
                        entCreateSLAActivity["scrum4_includesweekend"] = false;
                    }

                    if (funcArgs.includesHolidayAttribute)
                    {
                        entCreateSLAActivity["scrum4_includesholiday"] = true;
                    }
                    else
                    {
                        entCreateSLAActivity["scrum4_includesholiday"] = false;
                    }

                    entCreateSLAActivity["scrum4_response"] = null;

                    entCreateSLAActivity["scrum4_queue"] = new EntityReference("queue", funcArgs.queueId);

                    if (funcArgs.caseOwner != null)
                    {
                        if (funcArgs.caseOwner.LogicalName == "systemuser")
                        {
                            entCreateSLAActivity["ownerid"] = new EntityReference("systemuser", funcArgs.caseOwner.Id);
                        }
                        else if (funcArgs.caseOwner.LogicalName == "team")
                        {
                            entCreateSLAActivity["ownerid"] = new EntityReference("team", funcArgs.caseOwner.Id);
                        }
                    }

                    // Unit Test and check
                    //if (activityType == "edm" || activityType == "hrweb" || activityType == "phonecall")
                    //{ 
                    entCreateSLAActivity["scrum9_slaconfigurationid"] = funcArgs.SLAConfigurationId;
                    //}

                    //if (sourceOfSLALogCreation == "EDM Activity")
                    //{
                        //Updatin SLA workedby for all case origins.
                        workedBy = GetWorkerId(funcArgs.caseGuid, funcArgs.organizationService, funcArgs.tracingService);
                        if (workedBy != Guid.Empty)
                            entCreateSLAActivity["new_caseowner"] = new EntityReference("systemuser", workedBy);
                    //}

                    funcArgs.organizationService.Create(entCreateSLAActivity);
                }
            }
            catch (FaultException<OrganizationServiceFault> ex)
            {
                strMessage = "FaultException - " + Environment.NewLine;
                strMessage += "Message:  " + ex.Message + Environment.NewLine;
                strMessage += "Source:  " + ex.Source + Environment.NewLine;
                strMessage += "Stack Trace:  " + ex.StackTrace + Environment.NewLine;
                strMessage += "Time Stamp: " + ex.Detail.Timestamp + Environment.NewLine;
                strMessage += "Code: " + ex.Detail.ErrorCode + Environment.NewLine;
                strMessage += "Message: " + ex.Detail.Message + Environment.NewLine;
                strMessage += "Trace: " + ex.Detail.TraceText + Environment.NewLine;
                if (ex.InnerException != null)
                {
                    strMessage += "InnerException: " + ex.InnerException.Message + Environment.NewLine;
                }
                tracingService.Trace(string.Concat("CommonCode_CreateSLALogs", strMessage, DateTime.Now.ToString()));
            }
            catch (System.TimeoutException ex)
            {
                strMessage = "TimeoutException - " + Environment.NewLine;
                strMessage += "Message:  " + ex.Message + Environment.NewLine;
                strMessage += "Stack Trace:  " + ex.StackTrace + Environment.NewLine;
                if (ex.InnerException != null)
                {
                    strMessage += "InnerException: " + ex.InnerException.Message + Environment.NewLine;
                }
                tracingService.Trace(string.Concat("CommonCode_CreateSLALogs", strMessage, DateTime.Now.ToString()));
            }
            catch (Exception ex)
            {
                strMessage = "Exception - " + Environment.NewLine;
                strMessage += "Message:  " + ex.Message + Environment.NewLine;
                strMessage += "Stack Trace:  " + ex.StackTrace + Environment.NewLine;
                if (ex.InnerException != null)
                {
                    strMessage += "InnerException: " + ex.InnerException.Message + Environment.NewLine;
                }
                tracingService.Trace(string.Concat("CommonCode_CreateSLALogs", strMessage, DateTime.Now.ToString()));
            }
        }
        #endregion

        #region Close SLA Logs

        public void CloseExistingSLALogs(Guid incidentGuid, int sourceOfClosingSLALog, Guid userId, IOrganizationService _iOrgServ, ITracingService tracingService, bool traceEnabled)
        {
            if (traceEnabled)
            {
                tracingService.Trace(string.Concat("CommomCode_CloseExistingSLALogs", DateTime.Now.ToString()));
            }

            try
            {
                int firstOrSubSequentResponse = 1;
                //When Case is resolved, we need to update the No Action Required fields of all SLA Logs in order for the No Action Required
                //functionality to work properly.  This needs to be redesigned as it is impacting the performance during case resolution
                //This was removed from FetchXML condition - <condition attribute='new_slastatus' operator='eq' value='1'/>
                string fetchXML = @"<fetch distinct='false' mapping='logical' output-format='xml-platform' version='1.0'>
                                <entity name='new_slaactivity'> 
                                <attribute name='new_slaactivityid'/>
                                <attribute name='new_name'/>
                                <attribute name='createdon'/> 
                                <attribute name='new_slastartdate'/> 
                                <attribute name='new_slaend'/> 
                                <attribute name='scrum4_yellowtime'/>
                                <attribute name='new_slaenddate'/>
                                <attribute name='new_slastate'/>
                                <attribute name='new_slastatus'/> 
                                <attribute name='scrum4_response'/>
                                    <order descending='false' attribute='new_name'/> 
                                        <filter type='and'> 
                                            <condition attribute='new_caseid' value='" + incidentGuid + @"' uitype='incident' operator='eq'/>                                                                                    
                                        </filter> 
                                 </entity>
                                 </fetch>";
                EntityCollection retrievedSLALogs = _iOrgServ.RetrieveMultiple(new FetchExpression(fetchXML.ToString()));

                if (sourceOfClosingSLALog == 1 || sourceOfClosingSLALog == 2)
                {
                    foreach (var existingSLALogVar in retrievedSLALogs.Entities)
                    {
                        if (existingSLALogVar.Attributes.Contains("scrum4_response") && ((OptionSetValue)existingSLALogVar.Attributes["scrum4_response"]).Value == 1)
                        {
                            //If there is any SLA Log whose response is first then all other SLA logs should be closed with subsequent response
                            firstOrSubSequentResponse = 2;
                        }
                    }
                }

                if (retrievedSLALogs.Entities.Count > 0)
                {
                    DateTime caseCloseDateInUserTimeZone = GetLoggedInUserLocalTimeFromUTCTime(_iOrgServ, DateTime.UtcNow, userId, tracingService);

                    foreach (var slaEnt in retrievedSLALogs.Entities)
                    {
                        int _slaState = 0;

                        if (slaEnt.Attributes.Contains("new_slastate"))
                        {
                            OptionSetValue _os = (OptionSetValue)slaEnt.Attributes["new_slastate"];
                            _slaState = _os.Value;
                        }

                        if (sourceOfClosingSLALog == 1 || sourceOfClosingSLALog == 2)
                        {
                            if (slaEnt.Attributes.Contains("new_slastatus") && ((OptionSetValue)slaEnt.Attributes["new_slastatus"]).Value == 1)
                            {
                                if (slaEnt.Attributes.Contains("new_slaactivityid") && slaEnt.Attributes.Contains("new_slastartdate") && slaEnt.Attributes.Contains("scrum4_yellowtime") && slaEnt.Attributes.Contains("new_slaenddate") && slaEnt.Attributes.Contains("new_slaend"))
                                {
                                    UpdateRespondedDateAndCloseRelatedSLALogs(new Guid(Convert.ToString(slaEnt.Attributes["new_slaactivityid"])), DateTime.UtcNow, 2, Convert.ToDateTime(slaEnt.Attributes["new_slastartdate"]).ToUniversalTime(), Convert.ToDateTime(slaEnt.Attributes["scrum4_yellowtime"]).ToUniversalTime(), Convert.ToDateTime(slaEnt.Attributes["new_slaenddate"]).ToUniversalTime(), Convert.ToDouble(slaEnt.Attributes["new_slaend"]), _slaState, sourceOfClosingSLALog, firstOrSubSequentResponse, userId, _iOrgServ, tracingService, traceEnabled);
                                    firstOrSubSequentResponse = 2;
                                }
                            }
                        }
                        else
                        {
                            if (((Guid)slaEnt.Id) != Guid.Empty && slaEnt.Attributes.Contains("new_slastatus") && slaEnt.Attributes.Contains("new_slastartdate") && slaEnt.Attributes.Contains("scrum4_yellowtime") && slaEnt.Attributes.Contains("new_slaenddate") && slaEnt.Attributes.Contains("new_slaend"))
                            {
                                //Source of Closing SLA Log:  1-Email, 2-Phone Call, 3-Owner Change, 4-Resolved Case, 5-No Action Required
                                UpdateRespondedDateAndCloseRelatedSLALogs(((Guid)slaEnt.Id), caseCloseDateInUserTimeZone, 2, Convert.ToDateTime(slaEnt.Attributes["scrum4_yellowtime"]).ToUniversalTime(), Convert.ToDateTime(slaEnt.Attributes["new_slaenddate"]).ToUniversalTime(), _slaState, sourceOfClosingSLALog, ((OptionSetValue)slaEnt["new_slastatus"]), _iOrgServ, tracingService, traceEnabled);
                            }
                        }
                    }
                }
            }
            catch (FaultException<OrganizationServiceFault> ex)
            {
                strMessage = "FaultException - " + Environment.NewLine;
                strMessage += "Message:  " + ex.Message + Environment.NewLine;
                strMessage += "Source:  " + ex.Source + Environment.NewLine;
                strMessage += "Stack Trace:  " + ex.StackTrace + Environment.NewLine;
                strMessage += "Time Stamp: " + ex.Detail.Timestamp + Environment.NewLine;
                strMessage += "Code: " + ex.Detail.ErrorCode + Environment.NewLine;
                strMessage += "Message: " + ex.Detail.Message + Environment.NewLine;
                strMessage += "Trace: " + ex.Detail.TraceText + Environment.NewLine;
                if (ex.InnerException != null)
                {
                    strMessage += "InnerException: " + ex.InnerException.Message + Environment.NewLine;
                }
                tracingService.Trace(string.Concat("CommonCode_CloseExistingSLALogs", strMessage, DateTime.Now.ToString()));
            }
            catch (System.TimeoutException ex)
            {
                strMessage = "TimeoutException - " + Environment.NewLine;
                strMessage += "Message:  " + ex.Message + Environment.NewLine;
                strMessage += "Stack Trace:  " + ex.StackTrace + Environment.NewLine;
                if (ex.InnerException != null)
                {
                    strMessage += "InnerException: " + ex.InnerException.Message + Environment.NewLine;
                }
                tracingService.Trace(string.Concat("CommonCode_CloseExistingSLALogs", strMessage, DateTime.Now.ToString()));
            }
            catch (Exception ex)
            {
                strMessage = "Exception - " + Environment.NewLine;
                strMessage += "Message:  " + ex.Message + Environment.NewLine;
                strMessage += "Stack Trace:  " + ex.StackTrace + Environment.NewLine;
                if (ex.InnerException != null)
                {
                    strMessage += "InnerException: " + ex.InnerException.Message + Environment.NewLine;
                }
                tracingService.Trace(string.Concat("CommonCode_CloseExistingSLALogs", strMessage, DateTime.Now.ToString()));
            }
        }

        private void UpdateRespondedDateAndCloseRelatedSLALogs(Guid SLALogGuid, DateTime respondedDateInUserTimeZone, int statusToUpdate, DateTime _slaYellowDate, DateTime _slaRedDate, int _slaState, int sourceOfClosingSLALog, OptionSetValue _slaStatus, IOrganizationService _service, ITracingService tracingService, bool traceEnabled)
        {
            if (traceEnabled)
            {
                tracingService.Trace(string.Concat("CommomCode_UpdateRespondedDateAndCloseRelatedSLALogs", DateTime.Now.ToString()));
            }
            try
            {
                Entity SLALogInstance = new Entity();
                SLALogInstance.LogicalName = "new_slaactivity";
                SLALogInstance.Id = SLALogGuid;

                //_slaStatus value 1 is Open and 2 is Closed
                if (_slaStatus.Equals(new OptionSetValue(1)))
                {

                    //Source of Closing SLA Log:  1-Email, 2-Phone Call, 3-Owner Change, 4-Resolved Case, 5-No Action Required

                    int _slaStateNew = 0;

                    SLALogInstance["new_respondeddate"] = respondedDateInUserTimeZone;
                    //status - 1 - Open            
                    //status - 2 - Closed
                    SLALogInstance["new_slastatus"] = new OptionSetValue(statusToUpdate);
                    //Calculating SLA State                
                    _slaStateNew = CalculateSLAState(_slaYellowDate, _slaRedDate);

                    if (_slaStateNew != 0 && _slaStateNew != _slaState)
                    {
                        OptionSetValue SLAStateOptionalValue = new OptionSetValue(_slaStateNew);
                        SLALogInstance["new_slastate"] = SLAStateOptionalValue;
                    }

                    //1-Email, 2-Phone Call, 3-Owner Change, 4-Resolved Case, 5-No Action Required
                    if (sourceOfClosingSLALog != 0)
                    {
                        OptionSetValue sourceOfSLALogOptionalValue = new OptionSetValue(sourceOfClosingSLALog);
                        SLALogInstance["scrum4_slastatusreason"] = sourceOfSLALogOptionalValue;
                    }

                    //Only for case resolve, update the No Action Required field of SLA Log in order to avoid removal of email queueitem after case is resolved
                    if (sourceOfClosingSLALog == 4)
                    {
                        //This field is set to make the No Action Required field to have value of No Action Required and this is done to fix the bug #
                        //1049979 - No Action Required: Inappropriate message is displayed when user perform No Action Required from email form.
                        //5 is the OptionSetValue of No Action Required option
                        SLALogInstance["scrum5_noactionrequiredfield"] = new OptionSetValue(5);
                    }

                    _service.Update(SLALogInstance);
                }
                else
                {
                    //Only for case resolve, update the No Action Required field of SLA Log in order to avoid removal of email queueitem after case is resolved
                    if (sourceOfClosingSLALog == 4)
                    {
                        //This field is set to make the No Action Required field to have value of No Action Required and this is done to fix the bug #
                        //1049979 - No Action Required: Inappropriate message is displayed when user perform No Action Required from email form.
                        //5 is the OptionSetValue of No Action Required option
                        SLALogInstance["scrum5_noactionrequiredfield"] = new OptionSetValue(5);
                        _service.Update(SLALogInstance);
                    }
                }
            }
            catch (FaultException<OrganizationServiceFault> ex)
            {
                strMessage = "FaultException - " + Environment.NewLine;
                strMessage += "Message:  " + ex.Message + Environment.NewLine;
                strMessage += "Source:  " + ex.Source + Environment.NewLine;
                strMessage += "Stack Trace:  " + ex.StackTrace + Environment.NewLine;
                strMessage += "Time Stamp: " + ex.Detail.Timestamp + Environment.NewLine;
                strMessage += "Code: " + ex.Detail.ErrorCode + Environment.NewLine;
                strMessage += "Message: " + ex.Detail.Message + Environment.NewLine;
                strMessage += "Trace: " + ex.Detail.TraceText + Environment.NewLine;
                if (ex.InnerException != null)
                {
                    strMessage += "InnerException: " + ex.InnerException.Message + Environment.NewLine;
                }
                tracingService.Trace(string.Concat("CommomCode_UpdateRespondedDateAndCloseRelatedSLALogs", strMessage, DateTime.Now.ToString()));
            }
            catch (System.TimeoutException ex)
            {
                strMessage = "TimeoutException - " + Environment.NewLine;
                strMessage += "Message:  " + ex.Message + Environment.NewLine;
                strMessage += "Stack Trace:  " + ex.StackTrace + Environment.NewLine;
                if (ex.InnerException != null)
                {
                    strMessage += "InnerException: " + ex.InnerException.Message + Environment.NewLine;
                }
                tracingService.Trace(string.Concat("CommomCode_UpdateRespondedDateAndCloseRelatedSLALogs", strMessage, DateTime.Now.ToString()));
            }
            catch (Exception ex)
            {
                strMessage = "Exception - " + Environment.NewLine;
                strMessage += "Message:  " + ex.Message + Environment.NewLine;
                strMessage += "Stack Trace:  " + ex.StackTrace + Environment.NewLine;
                if (ex.InnerException != null)
                {
                    strMessage += "InnerException: " + ex.InnerException.Message + Environment.NewLine;
                }
                tracingService.Trace(string.Concat("CommomCode_UpdateRespondedDateAndCloseRelatedSLALogs", strMessage, DateTime.Now.ToString()));
            }
        }

        private void UpdateRespondedDateAndCloseRelatedSLALogs(Guid SLALogGuid, DateTime respondedDate, int status, DateTime _slaStartDate, DateTime _slaYellowDate, DateTime _slaRedDate, double _slaEnd, int _slaState, int sourceOfClosingSLALog, int firstOrSubSequentResponse, Guid userId, IOrganizationService _iOrgServ, ITracingService tracingService, bool traceEnabled)
        {
            try
            {
                if (traceEnabled)
                {
                    tracingService.Trace(string.Concat("CommomCode_UpdateRespondedDateAndCloseRelatedSLALogs", DateTime.Now.ToString()));
                }
                int _slaStateNew = 0;
                Entity SLALogInstance = new Entity();
                SLALogInstance.LogicalName = "new_slaactivity";
                SLALogInstance.Id = SLALogGuid;
                SLALogInstance["new_respondeddate"] = GetLoggedInUserLocalTimeFromUTCTime(_iOrgServ, respondedDate, userId, tracingService);
                //status - 1 - Open            
                //status - 2 - Closed
                SLALogInstance["new_slastatus"] = new OptionSetValue(status);
                //Calculating SLA State                
                _slaStateNew = CalculateSLAState(_slaYellowDate, _slaRedDate);
                if (_slaStateNew != 0 && _slaStateNew != _slaState)
                {
                    OptionSetValue opsValue = new OptionSetValue(_slaStateNew);
                    SLALogInstance["new_slastate"] = opsValue;
                }
                //1-Email, 2-Phone Call, 3-Owner Change, 4-Resolved Case, 5-No Action Required
                if (sourceOfClosingSLALog != 0)
                {
                    OptionSetValue sourceOfSLALogOptionalValue = new OptionSetValue(sourceOfClosingSLALog);
                    SLALogInstance["scrum4_slastatusreason"] = sourceOfSLALogOptionalValue;
                }
                //1 = First Response ; 2 = SubSequent Response
                SLALogInstance["scrum4_response"] = new OptionSetValue(firstOrSubSequentResponse);
                _iOrgServ.Update(SLALogInstance);
            }
            catch (FaultException<OrganizationServiceFault> ex)
            {
                strMessage = "FaultException - " + Environment.NewLine;
                strMessage += "Message:  " + ex.Message + Environment.NewLine;
                strMessage += "Source:  " + ex.Source + Environment.NewLine;
                strMessage += "Stack Trace:  " + ex.StackTrace + Environment.NewLine;
                strMessage += "Time Stamp: " + ex.Detail.Timestamp + Environment.NewLine;
                strMessage += "Code: " + ex.Detail.ErrorCode + Environment.NewLine;
                strMessage += "Message: " + ex.Detail.Message + Environment.NewLine;
                strMessage += "Trace: " + ex.Detail.TraceText + Environment.NewLine;
                if (ex.InnerException != null)
                {
                    strMessage += "InnerException: " + ex.InnerException.Message + Environment.NewLine;
                }
                tracingService.Trace(string.Concat("CommomCode_UpdateRespondedDateAndCloseRelatedSLALogs", strMessage, DateTime.Now.ToString()));
            }
            catch (System.TimeoutException ex)
            {
                strMessage = "TimeoutException - " + Environment.NewLine;
                strMessage += "Message:  " + ex.Message + Environment.NewLine;
                strMessage += "Stack Trace:  " + ex.StackTrace + Environment.NewLine;
                if (ex.InnerException != null)
                {
                    strMessage += "InnerException: " + ex.InnerException.Message + Environment.NewLine;
                }
                tracingService.Trace(string.Concat("CommomCode_UpdateRespondedDateAndCloseRelatedSLALogs", strMessage, DateTime.Now.ToString()));
            }
            catch (Exception ex)
            {
                strMessage = "Exception - " + Environment.NewLine;
                strMessage += "Message:  " + ex.Message + Environment.NewLine;
                strMessage += "Stack Trace:  " + ex.StackTrace + Environment.NewLine;
                if (ex.InnerException != null)
                {
                    strMessage += "InnerException: " + ex.InnerException.Message + Environment.NewLine;
                }
                tracingService.Trace(string.Concat("CommomCode_UpdateRespondedDateAndCloseRelatedSLALogs", strMessage, DateTime.Now.ToString()));
            }
        }


        #endregion

        #region Create Owner Logs

        public void CreateNewOwnerLog(Guid incidentGuid, string sourceOfOwnerLog, IOrganizationService orgService, ITracingService tracingService, bool traceEnabled)
        {
            if (traceEnabled)
            {
                tracingService.Trace(string.Concat("CommomCode_CreateNewOwnerLog", DateTime.Now.ToString()));
            }

            try
            {
                EntityReference currentQueue = new EntityReference();
                EntityReference currentOwner = new EntityReference();
                Entity incidentDynamicEntity = null;


                //Retrieve incident information
                incidentDynamicEntity = orgService.Retrieve("incident", incidentGuid, new ColumnSet("new_currentqueue", "ownerid"));
                if (incidentDynamicEntity.Attributes.Contains("new_currentqueue") && incidentDynamicEntity.Attributes.Contains("ownerid"))
                {
                    currentQueue = (EntityReference)incidentDynamicEntity.Attributes["new_currentqueue"];
                    currentOwner = (EntityReference)incidentDynamicEntity.Attributes["ownerid"];
                }

                Entity OwnerLogDynamicEntity = new Entity("scrum8_ownerlog");
                OwnerLogDynamicEntity["scrum8_regardingcaseid"] = new EntityReference("incident", incidentGuid);
                OwnerLogDynamicEntity["scrum8_queueid"] = new EntityReference("queue", currentQueue.Id);

                if (currentOwner.LogicalName == "systemuser")
                {
                    OwnerLogDynamicEntity["ownerid"] = new EntityReference("systemuser", currentOwner.Id);
                }
                else if (currentOwner.LogicalName == "team")
                {
                    OwnerLogDynamicEntity["ownerid"] = new EntityReference("team", currentOwner.Id);
                }
                OwnerLogDynamicEntity["scrum8_name"] = sourceOfOwnerLog;
                orgService.Create(OwnerLogDynamicEntity);

            }
            catch (FaultException<OrganizationServiceFault> ex)
            {
                strMessage = "FaultException - " + Environment.NewLine;
                strMessage += "Message:  " + ex.Message + Environment.NewLine;
                strMessage += "Source:  " + ex.Source + Environment.NewLine;
                strMessage += "Stack Trace:  " + ex.StackTrace + Environment.NewLine;
                strMessage += "Time Stamp: " + ex.Detail.Timestamp + Environment.NewLine;
                strMessage += "Code: " + ex.Detail.ErrorCode + Environment.NewLine;
                strMessage += "Message: " + ex.Detail.Message + Environment.NewLine;
                strMessage += "Trace: " + ex.Detail.TraceText + Environment.NewLine;
                if (ex.InnerException != null)
                {
                    strMessage += "InnerException: " + ex.InnerException.Message + Environment.NewLine;
                }
                tracingService.Trace(string.Concat("CommomCode_CreateNewOwnerLog", strMessage, DateTime.Now.ToString()));
            }
            catch (System.TimeoutException ex)
            {
                strMessage = "TimeoutException - " + Environment.NewLine;
                strMessage += "Message:  " + ex.Message + Environment.NewLine;
                strMessage += "Stack Trace:  " + ex.StackTrace + Environment.NewLine;
                if (ex.InnerException != null)
                {
                    strMessage += "InnerException: " + ex.InnerException.Message + Environment.NewLine;
                }
                tracingService.Trace(string.Concat("CommomCode_CreateNewOwnerLog", strMessage, DateTime.Now.ToString()));
            }
            catch (Exception ex)
            {
                strMessage = "Exception - " + Environment.NewLine;
                strMessage += "Message:  " + ex.Message + Environment.NewLine;
                strMessage += "Stack Trace:  " + ex.StackTrace + Environment.NewLine;
                if (ex.InnerException != null)
                {
                    strMessage += "InnerException: " + ex.InnerException.Message + Environment.NewLine;
                }
                tracingService.Trace(string.Concat("CommomCode_CreateNewOwnerLog", strMessage, DateTime.Now.ToString()));
            }
        }

        #endregion

        #region Close Owner Logs

        public void CloseExistingOpenOwnerLog(Guid incidentGuid, IOrganizationService orgService, ITracingService tracingService, bool traceEnabled)
        {
            if (traceEnabled)
            {
                tracingService.Trace(string.Concat("CommomCode_CloseExistingOpenOwnerLog", DateTime.Now.ToString()));
            }
            try
            {

                # region Declaration of Local Variables

                //Declaration of Local Variables
                EntityReference openLogCurrentQueue = new EntityReference(); // Previous Current Queue                
                EntityReference openLogCountry = new EntityReference();      // Previous Country 

                Entity openOwnerLogEntity = null;

                EntityCollection weekConfigCollection = null;
                EntityCollection holidayConfigCollection = null;

                DateTime ownerLogCreatedDate = new DateTime();
                DateTime ownerLogClosedDate = new DateTime(); // Time to track when owner got changed (For example from Owner 1 - Owner 2)
                DateTime ownerLogTempDate = new DateTime();
                DateTime ownerLogCreatedDateinUTC = new DateTime();
                DateTime ownerLogClosedDateinUTC = new DateTime();


                TimeSpan TimeWithOwner = new TimeSpan(); // Time With Owner in minutes

                bool queueWorkingSectionConfigured = true;
                int queueTimeZone = -1;
                Entity queueDynamicEntity = null;

                # endregion

                //Retrieve open owner logs
                string retrieveOpenOwnerLogs = @"<?xml version='1.0'?>
                                                   <fetch distinct='false' mapping='logical' output-format='xml-platform' version='1.0'>
                                                       <entity name='scrum8_ownerlog'>
                                                           <attribute name='scrum8_ownerlogid'/>                                                           
                                                           <attribute name='createdon'/>                                                                                                                    
                                                           <attribute name='scrum8_queueid'/>
                                                           <attribute name='ownerid'/>                                                           
                                                           <filter type='and'>
                                                                <condition attribute='scrum8_regardingcaseid' value='" + incidentGuid + @"' uitype='incident' operator='eq'/>
                                                                <condition attribute='scrum8_status' value='0' operator='eq'/>
                                                           </filter>
                                                            <link-entity name='queue' alias='alias_ownerLog_Queue' link-type='outer' visible='false' to='scrum8_queueid' from='queueid'>
                                                            <attribute name='scrum4_queuecountryid'/></link-entity>
                                                       </entity>
                                                   </fetch>";

                EntityCollection OpenOwnerLogsCollection = orgService.RetrieveMultiple(new FetchExpression(retrieveOpenOwnerLogs.ToString()));

                if (OpenOwnerLogsCollection.Entities.Count > 1)
                {
                    throw new InvalidPluginExecutionException("Found more than one open Owner Logs for incident - " + incidentGuid);
                }
                else if (OpenOwnerLogsCollection.Entities.Count == 1)
                {
                    tracingService.Trace(string.Concat("CommomCode_CloseExistingOpenOwnerLog :: One open owner logs", DateTime.Now.ToString()));
                    #region Close Existing Open Owner Log

                    //Existing Open Owner Log
                    openOwnerLogEntity = OpenOwnerLogsCollection.Entities[0];

                    if (openOwnerLogEntity.Attributes.Contains("scrum8_queueid"))
                    {
                        openLogCurrentQueue = (EntityReference)(openOwnerLogEntity.Attributes["scrum8_queueid"]);
                        //Get the timezone of the current queue
                        queueDynamicEntity = RetrieveEntityDetails(openLogCurrentQueue.Id, "queue", new ColumnSet("scrum4_monday", "scrum4_tuesday", "scrum4_wednesday", "scrum4_thursday", "scrum4_friday", "scrum4_saturday", "scrum4_sunday", "scrum4_timezone"), orgService);

                    }
                    if (openOwnerLogEntity.Attributes.Contains("alias_ownerLog_Queue.scrum4_queuecountryid"))
                    {
                        openLogCountry = (EntityReference)((Microsoft.Xrm.Sdk.AliasedValue)(openOwnerLogEntity.Attributes["alias_ownerLog_Queue.scrum4_queuecountryid"])).Value;
                    }


                    if (queueDynamicEntity != null)
                    {
                        //check if queue working section is configured or not.  If queue working section is not configured, then sla logs would not be created
                        //If all the working section fields are not null
                        if (queueDynamicEntity.Attributes.Contains("scrum4_monday") && queueDynamicEntity.Attributes.Contains("scrum4_tuesday") && queueDynamicEntity.Attributes.Contains("scrum4_wednesday") && queueDynamicEntity.Attributes.Contains("scrum4_thursday") && queueDynamicEntity.Attributes.Contains("scrum4_friday") && queueDynamicEntity.Attributes.Contains("scrum4_saturday") && queueDynamicEntity.Attributes.Contains("scrum4_sunday"))
                        {

                            //Only if not all the working section checkboxes are unchecked (all days are false), we would proceed with the logic
                            if ((!((bool)queueDynamicEntity.Attributes["scrum4_monday"])) && (!((bool)queueDynamicEntity.Attributes["scrum4_tuesday"])) && (!((bool)queueDynamicEntity.Attributes["scrum4_wednesday"])) && (!((bool)queueDynamicEntity.Attributes["scrum4_thursday"])) && (!((bool)queueDynamicEntity.Attributes["scrum4_friday"])) && (!((bool)queueDynamicEntity.Attributes["scrum4_saturday"])) && (!((bool)queueDynamicEntity.Attributes["scrum4_sunday"])))
                            {
                                queueWorkingSectionConfigured = false;
                            }
                        }
                        else
                        {
                            queueWorkingSectionConfigured = false;
                        }
                    }
                    if (queueWorkingSectionConfigured)
                    {

                        if (queueDynamicEntity.Attributes.Contains("scrum4_timezone"))
                        {
                            queueTimeZone = Convert.ToInt32(queueDynamicEntity.Attributes["scrum4_timezone"]);
                        }

                        if ((queueTimeZone != -1))
                        {

                            //Retrieve the Holidays for this particular country
                            if (openLogCountry.Id != Guid.Empty)
                            {
                                QueryExpression holidayQuery = new QueryExpression();
                                holidayQuery.EntityName = "scrum4_slaholiday";
                                holidayQuery.ColumnSet = new ColumnSet("scrum4_holidaydate");
                                holidayQuery.Criteria.AddCondition("scrum4_countryid", ConditionOperator.Equal, openLogCountry.Id);
                                holidayQuery.Criteria.AddCondition("statecode", ConditionOperator.Equal, 0);
                                holidayConfigCollection = (EntityCollection)orgService.RetrieveMultiple(holidayQuery);
                            }

                            //Retrieve the weekends for this particular queue
                            if (openLogCurrentQueue.Id != Guid.Empty)
                            {
                                QueryExpression queueQuery = new QueryExpression();
                                queueQuery.EntityName = "queue";
                                queueQuery.ColumnSet = new ColumnSet("scrum4_monday", "scrum4_tuesday", "scrum4_wednesday", "scrum4_thursday", "scrum4_friday", "scrum4_saturday", "scrum4_sunday");
                                queueQuery.Criteria.AddCondition("queueid", ConditionOperator.Equal, openLogCurrentQueue.Id);
                                weekConfigCollection = (EntityCollection)orgService.RetrieveMultiple(queueQuery);
                            }
                        }
                    }

                    ownerLogCreatedDateinUTC = Convert.ToDateTime(openOwnerLogEntity.Attributes["createdon"]).ToUniversalTime();
                    ownerLogClosedDateinUTC = DateTime.UtcNow; //Assigning UTC now time 

                    ownerLogCreatedDate = ConvertUTCtoAnyTimezone(ownerLogCreatedDateinUTC, queueTimeZone, orgService, tracingService);
                    ownerLogClosedDate = ConvertUTCtoAnyTimezone(ownerLogClosedDateinUTC, queueTimeZone, orgService, tracingService);
                    TimeWithOwner = ownerLogClosedDate - ownerLogCreatedDate;


                    //Check if the case is resolved on the same day, if not check for holidays in between "Owner Log" created date and "Owner Log" closed date
                    if (ownerLogCreatedDate.Date != ownerLogClosedDate.Date)
                    {

                        //Check if Owner Log created date is a holiday, If yes subtract hours calculated on that day                                        
                        if (CheckDeclaredHoliday(ownerLogCreatedDate, openLogCountry.Id, holidayConfigCollection, weekConfigCollection, orgService, tracingService))
                        {
                            TimeWithOwner = TimeWithOwner.Subtract(TimeSpan.FromHours(24).Subtract(ownerLogCreatedDate.TimeOfDay));
                        }

                        //Check if Owner Log closed date is a holiday, If yes subtract hours calculated on that day
                        if (CheckDeclaredHoliday(ownerLogClosedDate, openLogCountry.Id, holidayConfigCollection, weekConfigCollection, orgService, tracingService))
                        {
                            TimeWithOwner = TimeWithOwner.Subtract(ownerLogClosedDate.TimeOfDay);
                        }

                        //Check if any of the day in between Owner Log created date and closed date is a holiday, If yes subtract that day
                        for (ownerLogTempDate = ownerLogCreatedDate.AddDays(1); ownerLogTempDate.Date < ownerLogClosedDate.Date; ownerLogTempDate = ownerLogTempDate.AddDays(1))
                        {
                            if (CheckDeclaredHoliday(ownerLogTempDate, openLogCountry.Id, holidayConfigCollection, weekConfigCollection, orgService, tracingService))
                            {
                                TimeSpan oneDay = TimeSpan.FromDays(1);
                                TimeWithOwner = TimeWithOwner.Subtract(oneDay);
                            }
                        }
                    }
                    else if ((ownerLogCreatedDate.Date == ownerLogClosedDate.Date))
                    {
                        if (CheckDeclaredHoliday(ownerLogCreatedDate, openLogCountry.Id, holidayConfigCollection, weekConfigCollection, orgService, tracingService))
                        {
                            //If case is resolved on same day, then TimeWithOwner will be Zero.
                            TimeWithOwner = TimeSpan.Zero;
                        }
                    }


                    Entity closeOwnerLog = new Entity("scrum8_ownerlog");
                    closeOwnerLog.Id = (Guid)openOwnerLogEntity.Attributes["scrum8_ownerlogid"];
                    closeOwnerLog.Attributes["scrum8_timewithowner_actual"] = Convert.ToString(TimeWithOwner.TotalMinutes);
                    closeOwnerLog.Attributes["scrum8_timewithowner"] = Convert.ToString(Convert.ToInt32(Math.Ceiling(TimeWithOwner.TotalMinutes)));
                    //Close the Owner Log with status of "Closed"
                    OptionSetValue ownerLogOptionalValue = new OptionSetValue();
                    ownerLogOptionalValue.Value = 1; // 1 - Closed
                    closeOwnerLog["scrum8_status"] = ownerLogOptionalValue;
                    tracingService.Trace(string.Concat("CommomCode_CloseExistingOpenOwnerLog :: Before owner logs", DateTime.Now.ToString()));
                    orgService.Update(closeOwnerLog);
                    tracingService.Trace(string.Concat("CommomCode_CloseExistingOpenOwnerLog :: After owner logs Inside method", DateTime.Now.ToString()));

                    #endregion

                }
                else if (OpenOwnerLogsCollection.Entities.Count == 0)
                {

                    tracingService.Trace(string.Concat("CommomCode_CloseExistingOpenOwnerLog :: No open owner logs", DateTime.Now.ToString()));

                    //LogEvent("Plugin_CasePlugin_CasePlugin", "Close Existing Open Owner Log method - Couldn't find Open Owner Logs for incident " + incidentGuid + " @ " + DateTime.Now, System.Diagnostics.EventLogEntryType.Information);
                }
            }
            catch (FaultException<OrganizationServiceFault> ex)
            {
                strMessage = "FaultException - " + Environment.NewLine;
                strMessage += "Message:  " + ex.Message + Environment.NewLine;
                strMessage += "Source:  " + ex.Source + Environment.NewLine;
                strMessage += "Stack Trace:  " + ex.StackTrace + Environment.NewLine;
                strMessage += "Time Stamp: " + ex.Detail.Timestamp + Environment.NewLine;
                strMessage += "Code: " + ex.Detail.ErrorCode + Environment.NewLine;
                strMessage += "Message: " + ex.Detail.Message + Environment.NewLine;
                strMessage += "Trace: " + ex.Detail.TraceText + Environment.NewLine;
                if (ex.InnerException != null)
                {
                    strMessage += "InnerException: " + ex.InnerException.Message + Environment.NewLine;
                }
                tracingService.Trace(string.Concat("CommomCode_CloseExistingOpenOwnerLog", strMessage, DateTime.Now.ToString()));
            }
            catch (System.TimeoutException ex)
            {
                strMessage = "TimeoutException - " + Environment.NewLine;
                strMessage += "Message:  " + ex.Message + Environment.NewLine;
                strMessage += "Stack Trace:  " + ex.StackTrace + Environment.NewLine;
                if (ex.InnerException != null)
                {
                    strMessage += "InnerException: " + ex.InnerException.Message + Environment.NewLine;
                }
                tracingService.Trace(string.Concat("CommomCode_CloseExistingOpenOwnerLog", strMessage, DateTime.Now.ToString()));
            }
            catch (Exception ex)
            {
                strMessage = "Exception - " + Environment.NewLine;
                strMessage += "Message:  " + ex.Message + Environment.NewLine;
                strMessage += "Stack Trace:  " + ex.StackTrace + Environment.NewLine;
                if (ex.InnerException != null)
                {
                    strMessage += "InnerException: " + ex.InnerException.Message + Environment.NewLine;
                }
                tracingService.Trace(string.Concat("CommomCode_CloseExistingOpenOwnerLog", strMessage, DateTime.Now.ToString()));
            }
        }

        #endregion

        #region SLA and Owner Log Private Methods


        public Guid GetWorkerId(Guid caseId, IOrganizationService iOrgServ, ITracingService tracingService)
        {
            try
            {
                tracingService.Trace("Entered GetWorkerId method.");
                Guid workerId = Guid.Empty;

                QueryExpression queueItemQuery = new QueryExpression();
                queueItemQuery.EntityName = "queueitem";
                queueItemQuery.ColumnSet = new ColumnSet("workerid");
                queueItemQuery.Criteria.AddCondition("objectid", ConditionOperator.Equal, caseId);
                EntityCollection queueItemColl = (EntityCollection)iOrgServ.RetrieveMultiple(queueItemQuery);

                if (queueItemColl.Entities.Count > 0)
                {
                    Entity entQueueItem = (Entity)queueItemColl.Entities[0];
                    if (entQueueItem.Attributes.Contains("workerid"))
                        workerId = ((EntityReference)entQueueItem.Attributes["workerid"]).Id;
                }
                return workerId;
            }
            catch (FaultException<OrganizationServiceFault>)
            {
                throw;
            }
            catch (Exception)
            {
                throw;
            }
        }

        private FunctionArguments CalculateTargetDate(FunctionArguments funcArgs)
        {
            DateTime startDate = new DateTime();
            DateTime targetDate = new DateTime();
            DateTime yellowDate = new DateTime();
            DateTime tempStartDate = new DateTime();

            bool yellowdateStatus = false;
            EntityCollection holidayCollection = null;
            funcArgs.includesHolidayAttribute = false;
            funcArgs.includesWeekendAttribute = false;

            try
            {
                funcArgs.tracingService.Trace("Entered CalculateTargetDate method.");

                //Retrieve the Holidays for this particular country
                if (funcArgs.queueCountryId != Guid.Empty)
                {
                    QueryExpression holidayQuery = new QueryExpression();
                    holidayQuery.EntityName = "scrum4_slaholiday";
                    holidayQuery.ColumnSet = new ColumnSet("scrum4_holidaydate");
                    holidayQuery.Criteria.AddCondition("scrum4_countryid", ConditionOperator.Equal, funcArgs.queueCountryId);
                    //holidayQuery.Criteria.AddCondition("scrum4_holidaydate", ConditionOperator.OnOrAfter, emailCreatedDate);
                    holidayQuery.Criteria.AddCondition("statecode", ConditionOperator.Equal, 0);
                    holidayCollection = (EntityCollection)funcArgs.organizationService.RetrieveMultiple(holidayQuery);
                }

                funcArgs.holidayColl = holidayCollection;

                //Convert the start date to the queue timezone so that SLA calculations takes place in queue timezone
                LocalTimeFromUtcTimeRequest request = new LocalTimeFromUtcTimeRequest();
                request.UtcTime = funcArgs.CreatedDate;
                request.TimeZoneCode = funcArgs.queueTimeZone;
                LocalTimeFromUtcTimeResponse response = (LocalTimeFromUtcTimeResponse)funcArgs.organizationService.Execute(request);
                startDate = response.LocalTime;

                //v-degort : 
                funcArgs.tracingService.Trace("Entered CalculateTargetDate method." + funcArgs.queueTimeZone.ToString());

                //startDate is SLA Green Time.  Convert this startdate from queue timezone to user timezone for the purpose of saving
                funcArgs.CreatedDateinUserTimeZone = getUserSpecificTimeFromQueueSpecificTime(startDate, funcArgs.queueTimeZone, funcArgs.userTimeZone, funcArgs.organizationService, funcArgs.tracingService);


                //v-degort : 
                funcArgs.tracingService.Trace("Entered CalculateTargetDate method. created timezone" + funcArgs.CreatedDateinUserTimeZone.ToString());


                //Check if the current day is holiday/weekend and increment the starting date if it is holiday/weekend
                while ((funcArgs = CheckDeclaredHoliday(startDate, funcArgs)).isholiday)
                {
                    startDate = startDate.Date.AddDays(1);
                }
                //Set the initial targetDate and yellowDate by adding the SLA and SLAAfterVariance hours
                targetDate = startDate.AddHours(funcArgs.slaHours);
                targetDate = targetDate.AddMilliseconds(-1);
                yellowDate = startDate.AddHours(funcArgs.slaAfterVariance);
                yellowDate = yellowDate.AddMilliseconds(-1);

                if (startDate.Date == yellowDate.Date)
                    yellowdateStatus = true;

                for (tempStartDate = startDate.AddDays(1); tempStartDate.Date <= targetDate.Date; tempStartDate = tempStartDate.AddDays(1))
                {
                    if ((funcArgs = CheckDeclaredHoliday(tempStartDate, funcArgs)).isholiday)
                    {
                        targetDate = targetDate.AddDays(1);
                        if (!yellowdateStatus)
                            yellowDate = yellowDate.AddDays(1);
                    }
                    else if (yellowDate.Date == tempStartDate.Date)
                    {
                        yellowdateStatus = true;
                    }
                }
                //targetDate is SLA End Date           
                funcArgs.slaEndDate = getUserSpecificTimeFromQueueSpecificTime(targetDate, funcArgs.queueTimeZone, funcArgs.userTimeZone, funcArgs.organizationService, funcArgs.tracingService);
                //yellowDate is SLA Yellow Date
                funcArgs.slaYellowDate = getUserSpecificTimeFromQueueSpecificTime(yellowDate, funcArgs.queueTimeZone, funcArgs.userTimeZone, funcArgs.organizationService, funcArgs.tracingService);

                return funcArgs;
            }
            catch (FaultException<OrganizationServiceFault>)
            {
                throw;
            }
            catch (Exception)
            {
                throw;
            }
        }


        private int CalculateSLAState(DateTime slaYellowDate, DateTime SLARedDate)
        {
            int slaStateNew = 0;
            DateTime currentDate = DateTime.UtcNow;
            try
            {
                if (traceEnabled)
                {
                    //LogEvent("Plugin_CasePlugin_CasePlugin", "Entered CalculateSLAState " + DateTime.Now, System.Diagnostics.EventLogEntryType.Information);
                }
                if (SLARedDate != DateTime.MinValue && slaYellowDate != DateTime.MinValue)
                {
                    // (1-Red,2-Yellow,3-Green,535,720,000-No Action Required); Default Value - Green                   
                    if (currentDate > SLARedDate)
                        slaStateNew = 1;
                    else if ((currentDate <= SLARedDate) && (currentDate > slaYellowDate))
                        slaStateNew = 2;
                    else if ((currentDate <= SLARedDate) && (currentDate <= slaYellowDate))
                        slaStateNew = 3;
                }
            }
            catch (FaultException<OrganizationServiceFault>)
            {
                throw;
            }
            catch (Exception)
            {
                throw;
            }
            if (traceEnabled)
            {
                //LogEvent("Plugin_CasePlugin_CasePlugin", "Exited CalculateSLAState " + DateTime.Now, System.Diagnostics.EventLogEntryType.Information);
            }
            return slaStateNew;
        }

        private Entity GetUserTimeZone(IOrganizationService orgService, Guid userId, ITracingService tracingService)
        {
            try
            {
                tracingService.Trace("Entered GetUserTimeZone method.  Time:  " + DateTime.Now.ToString());
                RetrieveUserSettingsSystemUserRequest request = new RetrieveUserSettingsSystemUserRequest();
                request.ColumnSet = new ColumnSet("timezonecode");
                request.EntityId = userId;
                RetrieveUserSettingsSystemUserResponse response = (RetrieveUserSettingsSystemUserResponse)orgService.Execute(request);
                return response.Entity;
            }
            catch (FaultException<OrganizationServiceFault>)
            {
                throw;
            }
            catch (Exception)
            {
                throw;
            }
        }

        public DateTime getUserSpecificTimeFromQueueSpecificTime(DateTime sourceDateTime, int sourceTimeZoneCode, int destinationTimeZoneCode, IOrganizationService organizationServ, ITracingService tracingService)
        {
            DateTime destinationDateTime = DateTime.UtcNow;
            try
            {
                tracingService.Trace("Entered getUserSpecificTimeFromQueueSpecificTime method");
                //Convert Source DateTime to UTC
                UtcTimeFromLocalTimeRequest utcFromLocalRequest = new UtcTimeFromLocalTimeRequest();
                utcFromLocalRequest.LocalTime = sourceDateTime;
                utcFromLocalRequest.TimeZoneCode = sourceTimeZoneCode;
                UtcTimeFromLocalTimeResponse utcFromLocalResponse = (UtcTimeFromLocalTimeResponse)organizationServ.Execute(utcFromLocalRequest);

                //Convert UTC DateTime to Destination TimeZone
                LocalTimeFromUtcTimeRequest localFromUtcRequest = new LocalTimeFromUtcTimeRequest();
                localFromUtcRequest.UtcTime = utcFromLocalResponse.UtcTime;
                localFromUtcRequest.TimeZoneCode = destinationTimeZoneCode;
                LocalTimeFromUtcTimeResponse localFromUtcResponse = (LocalTimeFromUtcTimeResponse)organizationServ.Execute(localFromUtcRequest);

                destinationDateTime = localFromUtcResponse.LocalTime;

            }
            catch (FaultException<OrganizationServiceFault>)
            {
                throw;
            }
            catch (Exception)
            {
                throw;
            }
            return destinationDateTime;
        }

        private DateTime ConvertUTCtoAnyTimezone(DateTime utcDateTime, int destinationTimeZoneCode, IOrganizationService organizationServ, ITracingService tracingService)
        {
            try
            {
                tracingService.Trace("Entered ConvertUTCtoAnyTimezone method. Time:  " + DateTime.Now.ToString());
                DateTime destinationDateTime = DateTime.UtcNow;
                LocalTimeFromUtcTimeRequest request = new LocalTimeFromUtcTimeRequest();
                request.UtcTime = utcDateTime;
                request.TimeZoneCode = destinationTimeZoneCode;
                LocalTimeFromUtcTimeResponse response = (LocalTimeFromUtcTimeResponse)organizationServ.Execute(request);
                destinationDateTime = response.LocalTime;
                return destinationDateTime;
            }
            catch (FaultException<OrganizationServiceFault>)
            {
                throw;
            }
            catch (Exception)
            {

                throw;
            }
        }

        private DateTime GetLoggedInUserLocalTimeFromUTCTime(IOrganizationService service, DateTime utcDate, Guid userId, ITracingService tracingService)
        {
            Entity loggedInUser = null;
            int timeZoneCode = 0;
            DateTime returnDateTime = DateTime.UtcNow;
            try
            {
                loggedInUser = GetUserTimeZone(service, userId, tracingService);
                if (loggedInUser != null && loggedInUser.Attributes.Contains("timezonecode"))
                {
                    timeZoneCode = ((int)loggedInUser.Attributes["timezonecode"]);
                }
                LocalTimeFromUtcTimeRequest request = new LocalTimeFromUtcTimeRequest();
                request.UtcTime = utcDate;
                request.TimeZoneCode = timeZoneCode;
                LocalTimeFromUtcTimeResponse response = (LocalTimeFromUtcTimeResponse)service.Execute(request);
                returnDateTime = response.LocalTime;
                return returnDateTime;
            }
            catch (FaultException<OrganizationServiceFault>)
            {
                //return UtcNow when the corresponding userId doesn't have any local time zone settings (for example "Network Service")
                //throw;
                return returnDateTime;
            }
            catch (Exception)
            {
                //return UtcNow when the corresponding userId doesn't have any local time zone settings (for example "Network Service")
                //throw;
                return returnDateTime;
            }
        }

        private FunctionArguments CheckDeclaredHoliday(DateTime currentDate, FunctionArguments funcArgs)
        {
            try
            {
                funcArgs.tracingService.Trace("Entered CheckDeclaredHoliday method.");

                bool isholiday = false;

                if (funcArgs.queueCountryId != Guid.Empty)
                {
                    if (funcArgs.holidayColl != null && funcArgs.holidayColl.Entities.Count > 0)
                    {
                        foreach (Entity entHol in funcArgs.holidayColl.Entities)
                        {
                            if (entHol.Attributes.Contains("scrum4_holidaydate"))
                            {

                                if (currentDate.Date == (ConvertUTCtoAnyTimezone(((DateTime)entHol.Attributes["scrum4_holidaydate"]), 4, funcArgs.organizationService, funcArgs.tracingService).Date))
                                {
                                    isholiday = true;
                                    //the includesHolidayAttribute variable is used for Setting the Includes Holiday attribute on SLA Log Entity, added by v-pabab
                                    funcArgs.includesHolidayAttribute = true;
                                    break;
                                }
                                else
                                    isholiday = false;
                            }
                        }
                    }
                }


                if (!isholiday)
                {
                    funcArgs = CheckWeekends(currentDate, funcArgs);
                    isholiday = funcArgs.isholiday;
                }

                funcArgs.isholiday = isholiday;
                return funcArgs;
            }
            catch (FaultException<OrganizationServiceFault>)
            {
                throw;
            }
            catch (Exception)
            {
                throw;
            }
        }

        private bool CheckDeclaredHoliday(DateTime currentDate, Guid queueCountryId, EntityCollection holidayColl, EntityCollection queueEntCollection, IOrganizationService iOrgService, ITracingService tracingService)
        {
            try
            {
                if (traceEnabled)
                {
                    //LogEvent("Plugin_CasePlugin_CasePlugin", "Entered CheckDeclaredHoliday method " + DateTime.Now, System.Diagnostics.EventLogEntryType.Information);
                }
                bool isHoliday = false;

                if (queueCountryId != Guid.Empty)
                {
                    if (holidayColl != null && holidayColl.Entities.Count > 0)
                    {
                        foreach (Entity entHol in holidayColl.Entities)
                        {
                            if (entHol.Attributes.Contains("scrum4_holidaydate"))
                            {
                                //On the right hand side, we are converting the retrieved holiday date to the PST timezone by passing timezonecode as 4 to the ConvertUTCtoAnyTimezone method,
                                //so that the retrieved date will be always according to the PST timzone (as we are creating holidays according to PST timezone)
                                if (currentDate.Date == (ConvertUTCtoAnyTimezone(((DateTime)entHol.Attributes["scrum4_holidaydate"]), 4, iOrgService, tracingService).Date))
                                {
                                    isHoliday = true;
                                    IncludesHoliday = true;
                                    break;
                                }
                                else
                                    isHoliday = false;
                            }
                        }
                    }
                }

                if (!isHoliday)
                {
                    isHoliday = CheckWeekEnds(currentDate, queueEntCollection);
                }

                if (traceEnabled)
                {
                    //LogEvent("Plugin_CasePlugin_CasePlugin", "Exited CheckDeclaredHoliday method " + DateTime.Now, System.Diagnostics.EventLogEntryType.Information);
                }
                return isHoliday;

            }
            catch (FaultException<OrganizationServiceFault>)
            {
                throw;
            }
            catch (Exception)
            {
                throw;
            }
        }

        private FunctionArguments CheckWeekends(DateTime presentDate, FunctionArguments funcArgs)
        {
            try
            {
                funcArgs.tracingService.Trace("Entered CheckWeekEnds method.");
                bool isholiday = false;
                bool monday = false;
                bool tuesday = false;
                bool wednesday = false;
                bool thursday = false;
                bool friday = false;
                bool saturday = false;
                bool sunday = false;
                string weekday = string.Empty;
                weekday = presentDate.DayOfWeek.ToString().ToLowerInvariant();

                if (funcArgs.queueEntityObj != null && !string.IsNullOrEmpty(weekday))
                {

                    switch (weekday)
                    {
                        case "monday":
                            if (funcArgs.queueEntityObj.Attributes.Contains("scrum4_monday"))
                                monday = ((bool)funcArgs.queueEntityObj.Attributes["scrum4_monday"]);
                            if (!monday)
                                isholiday = true;
                            else
                                isholiday = false;
                            break;

                        case "tuesday":
                            if (funcArgs.queueEntityObj.Attributes.Contains("scrum4_tuesday"))
                                tuesday = ((bool)funcArgs.queueEntityObj.Attributes["scrum4_tuesday"]);
                            if (!tuesday)
                                isholiday = true;
                            else
                                isholiday = false;
                            break;

                        case "wednesday":
                            if (funcArgs.queueEntityObj.Attributes.Contains("scrum4_wednesday"))
                                wednesday = ((bool)funcArgs.queueEntityObj.Attributes["scrum4_wednesday"]);
                            if (!wednesday)
                                isholiday = true;
                            else
                                isholiday = false;
                            break;

                        case "thursday":
                            if (funcArgs.queueEntityObj.Attributes.Contains("scrum4_thursday"))
                                thursday = ((bool)funcArgs.queueEntityObj.Attributes["scrum4_thursday"]);
                            if (!thursday)
                                isholiday = true;
                            else
                                isholiday = false;
                            break;

                        case "friday":
                            if (funcArgs.queueEntityObj.Attributes.Contains("scrum4_friday"))
                                friday = ((bool)funcArgs.queueEntityObj.Attributes["scrum4_friday"]);
                            if (!friday)
                                isholiday = true;
                            else
                                isholiday = false;
                            break;

                        case "saturday":
                            if (funcArgs.queueEntityObj.Attributes.Contains("scrum4_saturday"))
                                saturday = ((bool)funcArgs.queueEntityObj.Attributes["scrum4_saturday"]);
                            if (!saturday)
                                isholiday = true;
                            else
                                isholiday = false;
                            break;

                        case "sunday":
                            if (funcArgs.queueEntityObj.Attributes.Contains("scrum4_sunday"))
                                sunday = ((bool)funcArgs.queueEntityObj.Attributes["scrum4_sunday"]);
                            if (!sunday)
                                isholiday = true;
                            else
                                isholiday = false;
                            break;
                    }
                }
                //the includesWeekendAttribute variable is used for Setting the Includes Weekend attribute on SLA Log Entity, added by v-pabab
                if (isholiday)
                {
                    funcArgs.includesWeekendAttribute = true;
                }

                funcArgs.isholiday = isholiday;

                return funcArgs;
            }
            catch (FaultException<OrganizationServiceFault>)
            {
                throw;
            }
            catch (Exception)
            {
                throw;
            }

        }

        private bool CheckWeekEnds(DateTime presentDate, EntityCollection queueColl)
        {
            try
            {

                if (traceEnabled)
                {
                    //LogEvent("Plugin_CasePlugin_CasePlugin", "Entered CheckWeekEnds method " + DateTime.Now, System.Diagnostics.EventLogEntryType.Information);
                }
                bool monday = false;
                bool tuesday = false;
                bool wednesday = false;
                bool thursday = false;
                bool friday = false;
                bool saturday = false;
                bool sunday = false;
                string weekday = string.Empty;
                weekday = presentDate.DayOfWeek.ToString().ToLower();
                bool isholiday = false;

                if (queueColl != null && queueColl.Entities.Count > 0 && !string.IsNullOrEmpty(weekday))
                {
                    Entity entQueue = (Entity)queueColl.Entities[0];

                    switch (weekday)
                    {
                        case "monday":
                            if (entQueue.Attributes.Contains("scrum4_monday"))
                                monday = ((bool)entQueue.Attributes["scrum4_monday"]);
                            if (!monday)
                                isholiday = true;
                            else
                                isholiday = false;
                            break;
                        case "tuesday":
                            if (entQueue.Attributes.Contains("scrum4_tuesday"))
                                tuesday = ((bool)entQueue.Attributes["scrum4_tuesday"]);
                            if (!tuesday)
                                isholiday = true;
                            else
                                isholiday = false;
                            break;
                        case "wednesday":
                            if (entQueue.Attributes.Contains("scrum4_wednesday"))
                                wednesday = ((bool)entQueue.Attributes["scrum4_wednesday"]);
                            if (!wednesday)
                                isholiday = true;
                            else
                                isholiday = false;
                            break;
                        case "thursday":
                            if (entQueue.Attributes.Contains("scrum4_thursday"))
                                thursday = ((bool)entQueue.Attributes["scrum4_thursday"]);
                            if (!thursday)
                                isholiday = true;
                            else
                                isholiday = false;
                            break;
                        case "friday":
                            if (entQueue.Attributes.Contains("scrum4_friday"))
                                friday = ((bool)entQueue.Attributes["scrum4_friday"]);
                            if (!friday)
                                isholiday = true;
                            else
                                isholiday = false;
                            break;
                        case "saturday":
                            if (entQueue.Attributes.Contains("scrum4_saturday"))
                                saturday = ((bool)entQueue.Attributes["scrum4_saturday"]);
                            if (!saturday)
                                isholiday = true;
                            else
                                isholiday = false;
                            break;
                        case "sunday":
                            if (entQueue.Attributes.Contains("scrum4_sunday"))
                                sunday = ((bool)entQueue.Attributes["scrum4_sunday"]);
                            if (!sunday)
                                isholiday = true;
                            else
                                isholiday = false;
                            break;
                    }
                }
                if (isholiday)
                {
                    IncludesWeekEnd = true;
                }
                if (traceEnabled)
                {
                    //LogEvent("Plugin_CasePlugin_CasePlugin", "Exited CheckWeekEnds method " + DateTime.Now, System.Diagnostics.EventLogEntryType.Information);
                }
                return isholiday;
            }
            catch (FaultException<OrganizationServiceFault>)
            {
                throw;
            }
            catch (Exception)
            {
                throw;
            }
        }

        private void GetSLAHours()
        {
        }

        private void GetSLAVariance()
        {
        }

        private void GetUserTimeZone()
        {
        }


        private Entity RetrieveEntityDetails(Guid entityId, string entityName, ColumnSet colmnSet, IOrganizationService _iOrgServ)
        {
            try
            {
                Entity entityObj = null;
                entityObj = (Entity)_iOrgServ.Retrieve(entityName, entityId, colmnSet);
                return entityObj;
            }
            catch (FaultException<OrganizationServiceFault>)
            {
                throw;
            }
            catch (Exception)
            {
                throw;
            }
        }

        #endregion

        #region FindDestinationQueue
        /// <summary>
        /// Get the destination queue based on customer field values and the advanced routing rules
        /// </summary>
        /// <param name="contactEntity">Contact entity object</param>
        /// <param name="edmActivityEntity">EDMActivity entity object. This will be null for HRWebActivity</param>
        /// <param name="_defaultDestinationQueue">The queue object of the default destination queue</param>
        /// <param name="_defaultRoutingRuleName">The default routing rule id name</param>
        /// <param name="_siteUrl">Site URL from HRWeb Activity</param>
        /// <param name="orgService">IOrganizationService object</param>
        /// <param name="tracingService">ITracingservice object</param>        
        /// <returns>Initial destination queue as entity reference</returns>
        [System.Diagnostics.CodeAnalysis.SuppressMessage("Microsoft.Design", "CA1062:Validate arguments of public methods", MessageId = "1")]
        public ARRFunctionArguments FindDestinationQueue(Entity contactEntity, Entity edmActivityEntity, EntityReference _defaultDestinationQueue, string _defaultRoutingRuleName, string _siteUrl, IOrganizationService orgService, ITracingService tracingService)
        {
            try
            {
                tracingService.Trace("Entered FindDestinationQueue method. " + DateTime.Now.ToString());

                ARRFunctionArguments objectToReturn = new ARRFunctionArguments();

                //Create a SortableQueueCollection list object to store the Queues of all the rules that matched
                List<SortableQueueCollection> sortableQueueList = new List<SortableQueueCollection>();

                if (contactEntity != null)
                {
                    EntityCollection fieldMaps = null;
                    EntityCollection routingConfigurationCollection = null;


                    //Get the mapping between advanced routing rules and Customer entity fields
                    QueryExpression fieldMapQuery = new QueryExpression("scrum5_routingfieldmapping");
                    fieldMapQuery.ColumnSet = new ColumnSet(true);
                    fieldMapQuery.Criteria.AddCondition("statecode", ConditionOperator.Equal, (int)EntityStateValues.Active);

                    //Collection of all the field mapping records
                    fieldMaps = (EntityCollection)orgService.RetrieveMultiple(fieldMapQuery);

                    //Get all the advanced routing rule records
                    QueryExpression routingConfigQuery = new QueryExpression("scrum5_advancedroutingrules");
                    routingConfigQuery.ColumnSet = new ColumnSet(true);
                    //Retrieve only active Advanced Routing Rule records
                    routingConfigQuery.Criteria.AddCondition("statecode", ConditionOperator.Equal, (int)EntityStateValues.Active);

                    //routingConfigurationCollection contains all the routing rule records
                    routingConfigurationCollection = (EntityCollection)orgService.RetrieveMultiple(routingConfigQuery);

                    if (routingConfigurationCollection != null && routingConfigurationCollection.Entities.Count > 0)
                    {
                        string advancedRoutingField, mappedEntityField = string.Empty;
                        int entityType;

                        //Find which routing configuration matches the customer details and obtain the queue
                        foreach (Entity routingConfig in routingConfigurationCollection.Entities)
                        {
                            bool configurationMatched = true;

                            //Foreach routing rule record, loop through all the fields of routing entity and verify if they exist and match their corresponding mapped entity field 
                            //For looping through advanced routing rule fields, we loop through the entity values of the fieldMap entity collection
                            foreach (Entity fieldMap in fieldMaps.Entities)
                            {
                                advancedRoutingField = fieldMap["scrum5_advancedroutingfield"].ToString();

                                if (!routingConfig.Attributes.Contains(advancedRoutingField))
                                {
                                    //If a field does not contain any value in advanced routing rule entity, continue to next field
                                    continue;
                                }
                                else
                                {
                                    if (!fieldMap.Attributes.Contains("scrum9_entitytype"))
                                    {
                                        continue;
                                    }
                                    else
                                    {

                                        //if entity type field contains value, then check if corresponding entity field contains value
                                        entityType = Convert.ToInt32(((OptionSetValue)fieldMap["scrum9_entitytype"]).Value);
                                        mappedEntityField = fieldMap["scrum5_customerfield"].ToString();  // This field contains the schema name of the mapped customer/edmactivity field

                                        switch (entityType)
                                        {
                                            // 1 is for contact entity type
                                            case (int)EntityTypeValues.Contact:
                                                {
                                                    if (contactEntity.Attributes.Contains(mappedEntityField))
                                                    {
                                                        //Get the datatype of the customer entity field
                                                        String dataTypeofCustomerField = contactEntity[mappedEntityField].GetType().FullName.ToString().ToLowerInvariant();
                                                        ////Get the datatype of the routing rule entity field
                                                        String dataTypeofRoutingField = routingConfig[advancedRoutingField].GetType().FullName.ToString().ToLowerInvariant();

                                                        switch (dataTypeofCustomerField)
                                                        {
                                                            //If datatype is string, then convert them to lower case and trim and compare the customer field and routing rule field
                                                            case "system.string":
                                                                //Since SteveB fields were made as lookup on routing rule entity, we need to convert it to text and compare with the text steveB fields on Customer entity
                                                                if (dataTypeofRoutingField == "microsoft.xrm.sdk.entityreference")
                                                                {
                                                                    string displayNameofEntRef = ((EntityReference)routingConfig[advancedRoutingField]).Name.ToString().Trim().ToLower();

                                                                    if (!(displayNameofEntRef == contactEntity[mappedEntityField].ToString().Trim().ToLower()))
                                                                    {
                                                                        //If the routing field value does not match customer field value, we just skip this record and move to the next record
                                                                        configurationMatched = false;
                                                                        break;
                                                                    }

                                                                }
                                                                else
                                                                {
                                                                    //String field of routing rule entity compared with string field of customer entity
                                                                    if (!(routingConfig[advancedRoutingField].ToString().Trim().ToLower() == contactEntity[mappedEntityField].ToString().Trim().ToLower()))
                                                                    {
                                                                        //If the routing field value does not match customer field value, we just skip this record and move to the next record
                                                                        configurationMatched = false;
                                                                        break;
                                                                    }
                                                                }
                                                                break;
                                                            //If datatype is boolean, then convert the customer field to type OptionSetValue and do the comparison with Routing Rule field because in routing rule entity, these fields are specified as OptionSets
                                                            case "system.boolean":
                                                                if (dataTypeofRoutingField == "microsoft.xrm.sdk.optionsetvalue")
                                                                {
                                                                    //optionsetvalue of routingrule entity compared with bool of customer entity
                                                                    if (!(routingConfig[advancedRoutingField].Equals(new OptionSetValue(Convert.ToInt32(contactEntity[mappedEntityField])))))
                                                                    {
                                                                        //If the routing field value does not match customer field value, we just skip this record and move to the next record
                                                                        configurationMatched = false;
                                                                        break;
                                                                    }
                                                                    break;
                                                                }
                                                                else
                                                                {
                                                                    //Boolean field of Customer entity compared with boolean field of Advanced Routing entity
                                                                    if (!(routingConfig[advancedRoutingField].Equals(contactEntity[mappedEntityField])))
                                                                    {
                                                                        //If the routing field value does not match customer field value, we just skip this record and move to the next record
                                                                        configurationMatched = false;
                                                                        break;
                                                                    }
                                                                    break;
                                                                }

                                                            //By default just compare the routing rule field with customer field for all other datatypes
                                                            default:
                                                                if (!(routingConfig[advancedRoutingField].Equals(contactEntity[mappedEntityField])))
                                                                {
                                                                    //If the routing field value does not match customer field value, we just skip this record and move to the next record
                                                                    configurationMatched = false;
                                                                    break;
                                                                }
                                                                break;
                                                        }
                                                    }
                                                    //If the corresponding customer field value does not contain value, we just skip this record and move to the next record
                                                    else
                                                    {
                                                        configurationMatched = false;
                                                        break;
                                                    }

                                                    break;
                                                }

                                            //2 is for EDMActivity entity type
                                            case (int)EntityTypeValues.EDMActivity:
                                                {
                                                    if (edmActivityEntity == null && routingConfig.Attributes.Contains(advancedRoutingField))
                                                    {
                                                        configurationMatched = false;
                                                        break;
                                                    }
                                                    else
                                                    {
                                                        if (edmActivityEntity.Attributes.Contains(mappedEntityField))
                                                        {
                                                            //Get the datatype of the edmactivity entity field
                                                            String dataTypeofEDMActivityField = edmActivityEntity[mappedEntityField].GetType().FullName.ToString().ToLowerInvariant();
                                                            ////Get the datatype of the advanced routing entity field
                                                            String dataTypeofRoutingField = routingConfig[advancedRoutingField].GetType().FullName.ToString().ToLowerInvariant();

                                                            switch (dataTypeofEDMActivityField)
                                                            {
                                                                //If datatype is string, then convert them to lower case and trim and compare the edmactivity field and routing rule field
                                                                case "system.string":                                                                                                                                    //String field of routing rule entity compared with string field of customer entity
                                                                    if (!(routingConfig[advancedRoutingField].ToString().Trim().ToLower() == edmActivityEntity[mappedEntityField].ToString().Trim().ToLowerInvariant()))
                                                                    {
                                                                        //If the routing field value does not match edmactivity field value, we just skip this record and move to the next record
                                                                        configurationMatched = false;
                                                                        break;
                                                                    }
                                                                    break;
                                                                //If datatype is boolean, then convert the EDMActivity field to type OptionSetValue and do the comparison with Routing Rule field because in routing rule entity, these fields are specified as OptionSets
                                                                case "system.boolean":
                                                                    //optionsetvalue of routingrule entity compared with bool of edmactivity entity
                                                                    if (dataTypeofRoutingField == "microsoft.xrm.sdk.optionsetvalue")
                                                                    {
                                                                        if (!(routingConfig[advancedRoutingField].Equals(new OptionSetValue(Convert.ToInt32(edmActivityEntity[mappedEntityField])))))
                                                                        {
                                                                            //If the routing field value does not match edmactivity field value, we just skip this record and move to the next record
                                                                            configurationMatched = false;
                                                                            break;
                                                                        }
                                                                        break;
                                                                    }
                                                                    else
                                                                    {
                                                                        //Boolean field of EDMActivity entity compared with boolean field of Advanced Routing entity
                                                                        if (!(routingConfig[advancedRoutingField].Equals(edmActivityEntity[mappedEntityField])))
                                                                        {
                                                                            //If the routing field value does not match edmactivity field value, we just skip this record and move to the next record
                                                                            configurationMatched = false;
                                                                            break;
                                                                        }
                                                                        break;
                                                                    }
                                                                //By default just compare the routing rule field with edmactivity field for all other datatypes
                                                                default:
                                                                    if (!(routingConfig[advancedRoutingField].Equals(edmActivityEntity[mappedEntityField])))
                                                                    {
                                                                        //If the routing field value does not match customer field value, we just skip this record and move to the next record
                                                                        configurationMatched = false;
                                                                        break;
                                                                    }
                                                                    break;
                                                            }
                                                        }
                                                        //If the corresponding edmactivity field value does not contain value, we just skip this record and move to the next record
                                                        else
                                                        {
                                                            configurationMatched = false;
                                                            break;
                                                        }

                                                        break;
                                                    }
                                                }
                                            //Added as a part of HRSupport Release 6.3 for considering Site URL in ARR logic//

                                            //3 for HRWebActivity entity type
                                            case (int)EntityTypeValues.HRWebActivity:
                                                {
                                                    if (_siteUrl.Trim() == string.Empty || routingConfig.Attributes[advancedRoutingField] == null || routingConfig.Attributes[advancedRoutingField].ToString().Trim() == string.Empty)
                                                    {
                                                        configurationMatched = false;
                                                        break;
                                                    }
                                                    else
                                                    {
                                                        int siteURLMatchFlag = -1;              //flag for validating if any of the ; separated values matches the Site URL
                                                        string[] siteURLMatchArray = null;
                                                        siteURLMatchArray = routingConfig.Attributes[advancedRoutingField].ToString().Trim().ToLower().Split(';');
                                                        foreach (string match in siteURLMatchArray)
                                                        {
                                                            if (match != string.Empty)
                                                            {
                                                                if (!(_siteUrl.Trim().ToLower().Contains(match)))
                                                                {
                                                                    siteURLMatchFlag = 0;
                                                                }
                                                                else
                                                                {
                                                                    siteURLMatchFlag = 1;
                                                                    break;
                                                                }
                                                            }
                                                        }
                                                        if (siteURLMatchFlag != 1)
                                                        {
                                                            configurationMatched = false;
                                                        }
                                                        break;
                                                    }
                                                }
                                            //End-Added as a part of HRSupport Release 6.3 for considering Site URL in ARR logic//
                                            default:
                                                {
                                                    tracingService.Trace("Unable to determine the entity type value of the Field Mapping record.");
                                                    break;
                                                }
                                        }
                                    }
                                }
                            }

                            if (configurationMatched)
                            {
                                //If this flag is true, then the customer or edmactivity record matched this routing rule record 
                                //Get the queue name, processing order and rule it from this rule record and add it to the sortableQueueList list 
                                sortableQueueList.Add(new SortableQueueCollection()
                                {
                                    ProcessingOrder = Convert.ToInt32(routingConfig["scrum5_processingorder"].ToString()),
                                    QueueReference = ((EntityReference)routingConfig["scrum5_queue"]),
                                    RoutingRuleId = routingConfig["scrum5_routingruleid"].ToString()
                                });
                            }

                        }
                        //Once all the routing rule records are compared, if there is any matching record, then sortableQueueList will contain at least one queue
                        if (sortableQueueList.Count > 0)
                        {
                            //sort this list based on processing order, so that the first record will be the least processing order rule record, processing order 001 being least
                            sortableQueueList.Sort();
                            //get queue name from the first element of the list, this is the least processing order
                            objectToReturn.DestinationQueue = (sortableQueueList.First()).QueueReference;

                            //get the corresponding rule id of the first element of the list, this is the rule id of the least processing order rule
                            objectToReturn.RoutingRuleId = (sortableQueueList.First()).RoutingRuleId.ToString();
                        }
                        //If none of the routing rules match, then the destination queue is the default queue
                        else
                        {
                            //This is the default queue value and default routing rule name from the workflow input parameter
                            if (_defaultDestinationQueue != null && _defaultDestinationQueue.Id != Guid.Empty)
                            {
                                objectToReturn.DestinationQueue = _defaultDestinationQueue;

                                if (_defaultRoutingRuleName != string.Empty)
                                {
                                    objectToReturn.RoutingRuleId = _defaultRoutingRuleName;
                                }
                            }
                        }
                    }

                    else
                    {
                        //If no routing rule records exist, then also the case is routed to default qeuue.  This is the default queue value and default routing rule name from the workflow input parameter
                        if (_defaultDestinationQueue != null && _defaultDestinationQueue.Id != Guid.Empty)
                        {
                            objectToReturn.DestinationQueue = _defaultDestinationQueue;

                            if (_defaultRoutingRuleName != string.Empty)
                            {
                                objectToReturn.RoutingRuleId = _defaultRoutingRuleName;
                            }
                        }
                    }
                }

                tracingService.Trace("FindDestinationQueue method returned the value {0} " + DateTime.Now.ToString(), (objectToReturn.DestinationQueue != null) ? objectToReturn.DestinationQueue.Name : "Null");
                return objectToReturn;
            }

            catch (FaultException<OrganizationServiceFault>)
            {
                throw;
            }
            catch (Exception)
            {
                throw;
            }
        }
        #endregion
    }

    public class SLALogBAL
    {
        //string caseoriginschemaname = string.Empty;
        //string casetypeschemaname = string.Empty;
        //string priorityschemaname = string.Empty;

        int slahours = -1;
        int slavariance = -1;
        double slaaftervariance = double.NaN;
        string slaconfigurationid = string.Empty;
        bool traceEnabled = false;
        string strMessage = string.Empty;

        public EntityCollection FetchSLAConfigurations(Guid queueId, int priority, int caseorigin, int casetype, IOrganizationService orgService, ITracingService tracingService, bool traceEnabled)
        {
            //v-degort : removed global and declared at the time of config
            if (traceEnabled)
            {
                tracingService.Trace(string.Concat("CommomCode_FetchSLAConfigurations", DateTime.Now.ToString()));
            }
            string SLAConfigurationCategory = string.Empty;
            EntityCollection queueSpecificSLARecords = new EntityCollection();
            try
            {
                string caseoriginschemaname = FetchAttributeSchema_CaseOrigin(caseorigin);

                string casetypeschemaname = FetchAttributeSchema_CaseType(casetype);

                string priorityschemaname = FetchAttributeSchema_Priority(priority);


                QueryExpression query = new QueryExpression("new_slaentityforfirstresponseonly");
                query.ColumnSet = new ColumnSet(new string[] { "new_name", "scrum9_processingorder", "new_slainhrs", "new_slavariance", "statecode" });

                //This query will retrieve all SLA records falling under Queue Specific SLA configuration
                query.Criteria.AddCondition("scrum9_processingorder", ConditionOperator.NotNull);
                query.Criteria.AddCondition("scrum9_processingorder", ConditionOperator.NotEqual, "Default");
                query.Criteria.AddCondition("new_queuenameid", ConditionOperator.Equal, queueId);
                query.Criteria.AddCondition(caseoriginschemaname, ConditionOperator.Equal, true);
                query.Criteria.AddCondition(casetypeschemaname, ConditionOperator.Equal, true);
                query.Criteria.AddCondition(priorityschemaname, ConditionOperator.Equal, true);
                query.Criteria.AddCondition("statecode", ConditionOperator.Equal, 0);

                //Sorting the records in ASCENDING order of processing order
                OrderExpression poOrderExpression = new OrderExpression();
                poOrderExpression.AttributeName = "scrum9_processingorder";
                poOrderExpression.OrderType = OrderType.Ascending;

                //Sorting the records in DESCENDING order of created on
                OrderExpression crOrderExpression = new OrderExpression();
                crOrderExpression.AttributeName = "createdon";
                crOrderExpression.OrderType = OrderType.Descending;

                query.Orders.Add(poOrderExpression);
                query.Orders.Add(crOrderExpression);

                //Execute the retrieval
                queueSpecificSLARecords = orgService.RetrieveMultiple(query);

            }
            catch (FaultException<OrganizationServiceFault> ex)
            {
                strMessage = "FaultException - " + Environment.NewLine;
                strMessage += "Message:  " + ex.Message + Environment.NewLine;
                strMessage += "Source:  " + ex.Source + Environment.NewLine;
                strMessage += "Stack Trace:  " + ex.StackTrace + Environment.NewLine;
                strMessage += "Time Stamp: " + ex.Detail.Timestamp + Environment.NewLine;
                strMessage += "Code: " + ex.Detail.ErrorCode + Environment.NewLine;
                strMessage += "Message: " + ex.Detail.Message + Environment.NewLine;
                strMessage += "Trace: " + ex.Detail.TraceText + Environment.NewLine;
                if (ex.InnerException != null)
                {
                    strMessage += "InnerException: " + ex.InnerException.Message + Environment.NewLine;
                }
                tracingService.Trace(string.Concat("CommomCode_FetchSLAConfigurations", strMessage, DateTime.Now.ToString()));
            }
            catch (System.TimeoutException ex)
            {
                strMessage = "TimeoutException - " + Environment.NewLine;
                strMessage += "Message:  " + ex.Message + Environment.NewLine;
                strMessage += "Stack Trace:  " + ex.StackTrace + Environment.NewLine;
                if (ex.InnerException != null)
                {
                    strMessage += "InnerException: " + ex.InnerException.Message + Environment.NewLine;
                }
                tracingService.Trace(string.Concat("CommomCode_FetchSLAConfigurations", strMessage, DateTime.Now.ToString()));
            }
            catch (Exception ex)
            {
                throw new InvalidPluginExecutionException();
                strMessage = "Exception - " + Environment.NewLine;
                strMessage += "Message:  " + ex.Message + Environment.NewLine;
                strMessage += "Stack Trace:  " + ex.StackTrace + Environment.NewLine;
                //if (ex.InnerException != null)
                //{
                //    strMessage += "InnerException: " + ex.InnerException.Message + Environment.NewLine;
                //}
                //tracingService.Trace(string.Concat("CommomCode_FetchSLAConfigurations", strMessage, DateTime.Now.ToString()));
            }

            return queueSpecificSLARecords;
        }

        //---Modified by Raghav--Scrum 9--VSTF ID #1096743--  
        public EntityCollection FetchSLAConfigurations(int priority, int caseorigin, int casetype, IOrganizationService orgService, ITracingService tracingService, bool traceEnabled)
        {
            EntityCollection universalSLARecords = new EntityCollection();
            if (traceEnabled)
            {
                tracingService.Trace(string.Concat("CommomCode_FetchSLAConfigurations", DateTime.Now.ToString()));
            }
            string SLAConfigurationCategory = string.Empty;
            try
            {
                string caseoriginschemaname = FetchAttributeSchema_CaseOrigin(caseorigin);
                string casetypeschemaname = FetchAttributeSchema_CaseType(casetype);
                string priorityschemaname = FetchAttributeSchema_Priority(priority);

                QueryExpression query = new QueryExpression("new_slaentityforfirstresponseonly");
                query.ColumnSet = new ColumnSet(new string[] { "new_name", "scrum9_processingorder", "new_slainhrs", "new_slavariance", "statecode" });

                //This query will retrieve all SLA records falling under Universal Specific SLA configuration
                query.Criteria.AddCondition("new_queuenameid", ConditionOperator.Null);
                query.Criteria.AddCondition("scrum9_processingorder", ConditionOperator.NotNull);
                query.Criteria.AddCondition("scrum9_processingorder", ConditionOperator.NotEqual, "Default");
                query.Criteria.AddCondition(caseoriginschemaname, ConditionOperator.Equal, true);
                query.Criteria.AddCondition(casetypeschemaname, ConditionOperator.Equal, true);
                query.Criteria.AddCondition(priorityschemaname, ConditionOperator.Equal, true);
                query.Criteria.AddCondition("statecode", ConditionOperator.Equal, 0);

                //Sorting the records in ASCENDING order of processing order
                OrderExpression poOrderExpression = new OrderExpression();
                poOrderExpression.AttributeName = "scrum9_processingorder";
                poOrderExpression.OrderType = OrderType.Ascending;

                //Sorting the records in DESCENDING order of created on
                OrderExpression crOrderExpression = new OrderExpression();
                crOrderExpression.AttributeName = "createdon";
                crOrderExpression.OrderType = OrderType.Descending;

                query.Orders.Add(poOrderExpression);
                query.Orders.Add(crOrderExpression);

                //Execute the retrieval
                universalSLARecords = orgService.RetrieveMultiple(query);

            }
            catch (FaultException<OrganizationServiceFault> ex)
            {
                strMessage = "FaultException - " + Environment.NewLine;
                strMessage += "Message:  " + ex.Message + Environment.NewLine;
                strMessage += "Source:  " + ex.Source + Environment.NewLine;
                strMessage += "Stack Trace:  " + ex.StackTrace + Environment.NewLine;
                strMessage += "Time Stamp: " + ex.Detail.Timestamp + Environment.NewLine;
                strMessage += "Code: " + ex.Detail.ErrorCode + Environment.NewLine;
                strMessage += "Message: " + ex.Detail.Message + Environment.NewLine;
                strMessage += "Trace: " + ex.Detail.TraceText + Environment.NewLine;
                if (ex.InnerException != null)
                {
                    strMessage += "InnerException: " + ex.InnerException.Message + Environment.NewLine;
                }
                tracingService.Trace(string.Concat("CommomCode_FetchSLAConfigurations", strMessage, DateTime.Now.ToString()));
            }
            catch (System.TimeoutException ex)
            {
                strMessage = "TimeoutException - " + Environment.NewLine;
                strMessage += "Message:  " + ex.Message + Environment.NewLine;
                strMessage += "Stack Trace:  " + ex.StackTrace + Environment.NewLine;
                if (ex.InnerException != null)
                {
                    strMessage += "InnerException: " + ex.InnerException.Message + Environment.NewLine;
                }
                tracingService.Trace(string.Concat("CommomCode_FetchSLAConfigurations", strMessage, DateTime.Now.ToString()));
            }
            catch (Exception ex)
            {
                strMessage = "Exception - " + Environment.NewLine;
                strMessage += "Message:  " + ex.Message + Environment.NewLine;
                strMessage += "Stack Trace:  " + ex.StackTrace + Environment.NewLine;
                if (ex.InnerException != null)
                {
                    strMessage += "InnerException: " + ex.InnerException.Message + Environment.NewLine;
                }
                tracingService.Trace(string.Concat("CommomCode_FetchSLAConfigurations", strMessage, DateTime.Now.ToString()));
            }

            return universalSLARecords;
        }

        //---Modified by Raghav--Scrum 9--VSTF ID #1096743--  
        public EntityCollection FetchSLAConfigurations(IOrganizationService orgService, ITracingService tracingService, bool traceEnabled)
        {
            EntityCollection defaultSLARecord = new EntityCollection();
            string SLAConfigurationCategory = string.Empty;
            if (traceEnabled)
            {
                tracingService.Trace(string.Concat("CommomCode_FetchSLAConfigurations", DateTime.Now.ToString()));
            }
            try
            {
                QueryExpression query = new QueryExpression("new_slaentityforfirstresponseonly");
                query.ColumnSet = new ColumnSet(new string[] { "new_name", "new_slainhrs", "new_slavariance", "statecode" });

                //This query will retrieve the Default SLA configuration record
                query.Criteria.AddCondition("scrum9_processingorder", ConditionOperator.NotNull);
                query.Criteria.AddCondition("scrum9_processingorder", ConditionOperator.Equal, "Default");
                query.Criteria.AddCondition("statecode", ConditionOperator.Equal, 0);

                //Sorting the records in DESCENDING order of created on
                OrderExpression crOrderExpression = new OrderExpression();
                crOrderExpression.AttributeName = "createdon";
                crOrderExpression.OrderType = OrderType.Descending;
                query.Orders.Add(crOrderExpression);

                //Execute the retrieval
                defaultSLARecord = orgService.RetrieveMultiple(query);

            }
            catch (FaultException<OrganizationServiceFault> ex)
            {
                strMessage = "FaultException - " + Environment.NewLine;
                strMessage += "Message:  " + ex.Message + Environment.NewLine;
                strMessage += "Source:  " + ex.Source + Environment.NewLine;
                strMessage += "Stack Trace:  " + ex.StackTrace + Environment.NewLine;
                strMessage += "Time Stamp: " + ex.Detail.Timestamp + Environment.NewLine;
                strMessage += "Code: " + ex.Detail.ErrorCode + Environment.NewLine;
                strMessage += "Message: " + ex.Detail.Message + Environment.NewLine;
                strMessage += "Trace: " + ex.Detail.TraceText + Environment.NewLine;
                if (ex.InnerException != null)
                {
                    strMessage += "InnerException: " + ex.InnerException.Message + Environment.NewLine;
                }
                tracingService.Trace(string.Concat("CommomCode_FetchSLAConfigurations", strMessage, DateTime.Now.ToString()));
            }
            catch (System.TimeoutException ex)
            {
                strMessage = "TimeoutException - " + Environment.NewLine;
                strMessage += "Message:  " + ex.Message + Environment.NewLine;
                strMessage += "Stack Trace:  " + ex.StackTrace + Environment.NewLine;
                if (ex.InnerException != null)
                {
                    strMessage += "InnerException: " + ex.InnerException.Message + Environment.NewLine;
                }
                tracingService.Trace(string.Concat("CommomCode_FetchSLAConfigurations", strMessage, DateTime.Now.ToString()));
            }
            catch (Exception ex)
            {
                strMessage = "Exception - " + Environment.NewLine;
                strMessage += "Message:  " + ex.Message + Environment.NewLine;
                strMessage += "Stack Trace:  " + ex.StackTrace + Environment.NewLine;
                if (ex.InnerException != null)
                {
                    strMessage += "InnerException: " + ex.InnerException.Message + Environment.NewLine;
                }
                tracingService.Trace(string.Concat("CommomCode_FetchSLAConfigurations", strMessage, DateTime.Now.ToString()));
            }
            return defaultSLARecord;
        }

        public void SetSLAParameters(EntityCollection slaConfiguration)
        {
            if (slaConfiguration.Entities[0] is Entity && slaConfiguration.Entities[0].Attributes.Contains("new_slainhrs") && slaConfiguration.Entities[0].Attributes.Contains("new_slavariance") && slaConfiguration.Entities[0].Attributes.Contains("new_name"))
            {
                slahours = Convert.ToInt32(slaConfiguration.Entities[0]["new_slainhrs"].ToString().Trim());
                OptionSetValue slaVarianceOptionSet = (OptionSetValue)slaConfiguration.Entities[0]["new_slavariance"];
                slavariance = slaVarianceOptionSet.Value;
                slaconfigurationid = slaConfiguration.Entities[0]["new_name"].ToString().Trim();
                slaaftervariance = ((double)(slahours * slavariance) / 100);
            }

        }

        private string FetchAttributeSchema_CaseOrigin(int caseorigindatavalue)
        {
            string caseoriginschemaname = string.Empty;
            switch (caseorigindatavalue)
            {
                case (int)CaseOrigins.Phone:
                    caseoriginschemaname = "scrum9_phone";
                    break;
                case (int)CaseOrigins.Email:
                    caseoriginschemaname = "scrum9_email";
                    break;
                case (int)CaseOrigins.Web:
                    caseoriginschemaname = "scrum9_web";
                    break;
                case (int)CaseOrigins.Chat:
                    caseoriginschemaname = "scrum9_chat";
                    break;
                case (int)CaseOrigins.Walkin:
                    caseoriginschemaname = "scrum9_walkin";
                    break;
                case (int)CaseOrigins.Post:
                    caseoriginschemaname = "scrum9_post";
                    break;
                case (int)CaseOrigins.EDMTool:
                    caseoriginschemaname = "scrum9_edmtool";
                    break;
            }
            return caseoriginschemaname;
        }

        //---Modified by Raghav--Scrum 9--VSTF ID #1096743--  
        private string FetchAttributeSchema_CaseType(int casetypedatavalue)
        {
            string casetypeschemaname = string.Empty;
            switch (casetypedatavalue)
            {
                case (int)CaseTypes.Blank:
                    casetypeschemaname = "scrum9_casetypeblank";
                    break;
                case (int)CaseTypes.Inquiry:
                    casetypeschemaname = "scrum9_inquiry";
                    break;
                case (int)CaseTypes.Task:
                    casetypeschemaname = "scrum9_task";
                    break;
            }
            return casetypeschemaname;
        }

        //---Modified by Raghav--Scrum 9--VSTF ID #1096743--  
        private string FetchAttributeSchema_Priority(int prioritydatavalue)
        {
            string priorityschemaname = string.Empty;
            switch (prioritydatavalue)
            {
                case (int)Priorities.Critical:
                    priorityschemaname = "scrum9_critical";
                    break;
                case (int)Priorities.High:
                    priorityschemaname = "scrum9_high";
                    break;
                case (int)Priorities.Medium:
                    priorityschemaname = "scrum9_medium";
                    break;
                case (int)Priorities.Low:
                    priorityschemaname = "scrum9_low";
                    break;
            }
            return priorityschemaname;
        }

        //---Modified by Raghav--Scrum 9--VSTF ID #1096743--  
        public enum CaseOrigins
        {
            Phone = 1,
            Email,
            Web,
            Chat = 5,
            Walkin,
            Post,
            EDMTool
        }

        //---Modified by Raghav--Scrum 9--VSTF ID #1096743--  
        public enum CaseTypes
        {
            Blank = 0,
            Inquiry,
            Task
        }

        //---Modified by Raghav--Scrum 9--VSTF ID #1096743--  
        public enum Priorities
        {
            Critical = 1,
            High,
            Medium,
            Low
        }

        public int SLAHours
        {
            get { return slahours; }
            set { slahours = value; }
        }

        public int SLAVariance
        {
            get { return slavariance; }
            set { slavariance = value; }
        }

        public double SLAAfterVariance
        {
            get { return slaaftervariance; }
            set { slaaftervariance = value; }
        }

        public string SLAConfigurationID
        {
            get { return slaconfigurationid; }
            set { slaconfigurationid = value; }
        }
    }

    public class FunctionArguments
    {

        public bool isholiday
        {
            get;
            set;
        }

        //public DateTime emailCreatedDate
        //{
        //    get;
        //    set;
        //}

        public int slaHours
        {
            get;
            set;
        }

        public double slaAfterVariance
        {
            get;
            set;
        }

        public int LOB
        {
            get;
            set;
        }

        public Guid queueId
        {
            get;
            set;
        }

        public Guid caseGuid
        {
            get;
            set;
        }

        public Entity queueEntityObj
        {
            get;
            set;
        }


        public int queueTimeZone
        {
            get;
            set;
        }

        public int userTimeZone
        {
            get;
            set;
        }

        public Guid queueCountryId
        {
            get;
            set;
        }

        public EntityCollection holidayColl
        {
            get;
            set;
        }

        public DateTime slaEndDate
        {
            get;
            set;
        }

        public DateTime slaYellowDate
        {
            get;
            set;
        }

        //public DateTime emailCreatedDateinUserTimeZone
        //{
        //    get;
        //    set;
        //}

        public DateTime CreatedDateinUserTimeZone
        {
            get;
            set;
        }

        public bool includesHolidayAttribute
        {
            get;
            set;
        }

        public bool includesWeekendAttribute
        {
            get;
            set;
        }

        public EntityReference caseOriginatingQueue
        {
            get;
            set;
        }

        public EntityReference caseOwner
        {
            get;
            set;
        }

        public IOrganizationService organizationService
        {
            get;
            set;
        }
        public ITracingService tracingService
        {
            get;
            set;
        }

        public string SLAConfigurationId
        {
            get;
            set;
        }

        //public DateTime edmCreatedDate
        //{
        //    get;
        //    set;
        //}

        //public DateTime edmCreatedDateinUserTimeZone
        //{
        //    get;
        //    set;
        //}

        //public DateTime hrWebCreatedDate
        //{
        //    get;
        //    set;
        //}

        public DateTime CreatedDate
        {
            get;
            set;
        }

    }

    public class ARRFunctionArguments
    {
        public EntityReference DestinationQueue
        {
            get;
            set;
        }

        public string RoutingRuleId
        {
            get;
            set;
        }
    }

    #region SortableQueueCollection
    /// <summary>
    /// This class is used to create a list for storing the list of matching routing rule record fields
    /// </summary>

    public class SortableQueueCollection : IComparable<SortableQueueCollection>
    {
        public int ProcessingOrder
        {
            get;
            set;
        }
        public EntityReference QueueReference
        {
            get;
            set;
        }
        public String RoutingRuleId
        {
            get;
            set;
        }

        public int CompareTo(SortableQueueCollection other)
        {
            return this.ProcessingOrder.CompareTo(other.ProcessingOrder);
        }
    }
    #endregion

    #region AutoNotifications
    public class AutomatedCommunications
    {
        #region Determine Action for Triggering Communication

        public int DetermineNotificationAction(int caseOriginValue, int caseTypeValue, int caseResolutionType, int interactionRequiredValue, IOrganizationService _iOrgServiceAdminContext, string contextMessage)
        {
            string caseOriginSchema = string.Empty;
            string caseTypeSchema = string.Empty;
            string interactionRequiredSchema = string.Empty;
            List<int> TriggerCommList = new List<int>();

            caseOriginSchema = FetchAttributeSchema_CaseOrigin(caseOriginValue);
            caseTypeSchema = FetchAttributeSchema_CaseType(caseTypeValue);
            interactionRequiredSchema = FetchAttributeSchema_InteractionRequired(interactionRequiredValue);

            QueryExpression determineTriggerAction = new QueryExpression("scrum9_triggercommunications");

            if (contextMessage.ToUpperInvariant() == "CLOSE")
            {
                determineTriggerAction.ColumnSet = new ColumnSet("scrum9_actiontype", "scrum9_action");
                LinkEntity _TriggerCommElement = new LinkEntity("scrum9_triggercommunications", "scrum9_scrum9_triggercommunications_scrum9_res", "scrum9_triggercommunicationsid", "scrum9_triggercommunicationsid", JoinOperator.Inner);
                LinkEntity _ResolutionTypesElement = new LinkEntity("scrum9_scrum9_triggercommunications_scrum9_res", "scrum9_resolutiontype", "scrum9_resolutiontypeid", "scrum9_resolutiontypeid", JoinOperator.Inner);
                _ResolutionTypesElement.Columns.AddColumns("scrum9_resolutiontypename", "scrum9_resolutiontypevalue", "scrum9_displayonresolutionform");
                _ResolutionTypesElement.EntityAlias = "_ResolutionTypeDetaild";
                _ResolutionTypesElement.LinkCriteria.AddCondition("scrum9_resolutiontypevalue", ConditionOperator.Equal, caseResolutionType);
                _ResolutionTypesElement.LinkCriteria.AddCondition("statecode", ConditionOperator.Equal, 0); //Considering only active Resolution Type records.
                _TriggerCommElement.LinkEntities.Add(_ResolutionTypesElement);
                determineTriggerAction.LinkEntities.Add(_TriggerCommElement);
                determineTriggerAction.Criteria.AddCondition("statecode", ConditionOperator.Equal, 0); //Retrieving only active Trigger Communications Record.
                determineTriggerAction.Criteria.AddCondition("scrum9_actiontype", ConditionOperator.Equal, (int)ActionTypeValues.CaseResolution);
                determineTriggerAction.Criteria.AddCondition(caseOriginSchema, ConditionOperator.Equal, true);
                determineTriggerAction.Criteria.AddCondition(caseTypeSchema, ConditionOperator.Equal, true);
                determineTriggerAction.Criteria.AddCondition(interactionRequiredSchema, ConditionOperator.Equal, true);
            }
            else if (contextMessage.ToUpperInvariant() == "CREATE")
            {
                determineTriggerAction.ColumnSet = new ColumnSet("scrum9_actiontype", "scrum9_action");
                determineTriggerAction.Criteria.AddCondition("statecode", ConditionOperator.Equal, 0); //Retrieving only active Trigger Communications Record.
                determineTriggerAction.Criteria.AddCondition("scrum9_actiontype", ConditionOperator.Equal, (int)ActionTypeValues.CaseCreation);
                determineTriggerAction.Criteria.AddCondition(caseOriginSchema, ConditionOperator.Equal, true);
                determineTriggerAction.Criteria.AddCondition(caseTypeSchema, ConditionOperator.Equal, true);
            }

            EntityCollection triggerCommCollection = (EntityCollection)_iOrgServiceAdminContext.RetrieveMultiple(determineTriggerAction);

            if (triggerCommCollection != null && triggerCommCollection.Entities.Count > 0)
            {
                //Adding the action values to a list and sorting them in Ascending order  
                foreach (Entity ent in triggerCommCollection.Entities)
                {
                    TriggerCommList.Add(((OptionSetValue)ent.Attributes["scrum9_action"]).Value);
                }
                TriggerCommList.Sort();

                return TriggerCommList.ElementAtOrDefault(0);
            }

            else //No matching Trigger Communications record found
            {
                return -1;
            }
        }

        public bool IsCustomerEligibleforSurvey(int surveyFrequency, DateTime lastSurveySentTime, bool lastSurveySentDateExists, int isCustomerOptedOut)
        {
            bool isEligible = Convert.ToBoolean(BooleanValue.No);

            //If customers survey opt-out flag is FALSE and last survey sent exists.
            if ((isCustomerOptedOut == (int)BooleanValue.No) && (lastSurveySentDateExists == Convert.ToBoolean(BooleanValue.Yes)) && lastSurveySentTime != DateTime.MinValue && surveyFrequency != -1 && (surveyFrequency * 24 * 60 * 60) < (DateTime.UtcNow.Subtract(lastSurveySentTime).TotalSeconds))
            {
                isEligible = Convert.ToBoolean(BooleanValue.Yes);
                return isEligible;
            }

            //If customers survey opt-out flag is NULL and last survey sent exists.
            else if ((isCustomerOptedOut == -1) && (lastSurveySentDateExists == Convert.ToBoolean(BooleanValue.Yes)) && lastSurveySentTime != DateTime.MinValue && surveyFrequency != -1 && (surveyFrequency * 24 * 60 * 60) < (DateTime.UtcNow.Subtract(lastSurveySentTime).TotalSeconds))
            {
                isEligible = Convert.ToBoolean(BooleanValue.Yes);
                return isEligible;
            }

            //If customers survey opt-out flag is FALSE and last survey sent on is NULL
            else if (isCustomerOptedOut == 0 && (lastSurveySentDateExists == Convert.ToBoolean(BooleanValue.No)))
            {
                isEligible = Convert.ToBoolean(BooleanValue.Yes);
                return isEligible;
            }

            //If customers survey opt-out flag & last survey sent on are NULL then its first time we can fire the survey workflow
            else if (isCustomerOptedOut == -1 && (lastSurveySentDateExists == Convert.ToBoolean(BooleanValue.No)))
            {
                isEligible = Convert.ToBoolean(BooleanValue.Yes);
                return isEligible;
            }

            return isEligible;
        }

        public CommunicationConfigArguments DetermineCommunicationConfiguration(int triggerCommunicationActionValue, string caseOriginAttribute, string customerSourceAttribute, Guid caseCurrentQueueId, IOrganizationService _iOrgServiceAdminContext, string companyCode)
        {
            CommunicationConfigArguments returnArgsObj = new CommunicationConfigArguments();

            #region commented by v-namuth
            //string communicationConfigurationQuery = @"<?xml version='1.0'?>";
            //communicationConfigurationQuery += "<fetch version='1.0' output-format='xml-platform' mapping='logical' distinct='true'>";
            //communicationConfigurationQuery += "<entity name='new_templateinfo'>";
            //communicationConfigurationQuery += "<attribute name='new_templateid' />";
            //communicationConfigurationQuery += "<attribute name='new_templatename' />";
            //communicationConfigurationQuery += "<attribute name='scrum5_surveylagtime' />";
            //communicationConfigurationQuery += "<attribute name='scrum5_surveyfrequency' />";
            //communicationConfigurationQuery += "<attribute name='scrum9_action' />";
            //communicationConfigurationQuery += "<attribute name='new_templateinfoid' />";
            //communicationConfigurationQuery += "<order attribute='createdon' descending='true' />";
            //communicationConfigurationQuery += "<filter type='and'>";
            //communicationConfigurationQuery += "<condition attribute='statecode' operator='eq' value='0' />";
            //communicationConfigurationQuery += "<condition attribute='new_templateid' operator='not-null'/>";
            //communicationConfigurationQuery += "<condition attribute='new_templatename' operator='not-null'/>";
            //communicationConfigurationQuery += "<condition attribute='scrum9_action' operator='eq' value='" + triggerCommunicationActionValue.ToString() + "' />";
            //communicationConfigurationQuery += "<condition attribute='" + customerSourceAttribute + "' operator='eq' value='1' />";
            //communicationConfigurationQuery += "<condition attribute='" + caseOriginAttribute + "' operator='eq' value='1' />";
            //communicationConfigurationQuery += "</filter>";
            //communicationConfigurationQuery += "<link-entity name='scrum9_new_templateinfo_queue' from='new_templateinfoid' to='new_templateinfoid' visible='false' intersect='true'>";
            //communicationConfigurationQuery += "<link-entity name='queue' from='queueid' to='queueid' alias='_QueueDetails'>";
            //communicationConfigurationQuery += "<filter type='and'>";
            //communicationConfigurationQuery += "<condition attribute='queueid' operator='eq' uitype='queue' value='" + caseCurrentQueueId.ToString() + "' />";
            //communicationConfigurationQuery += "</filter></link-entity></link-entity></entity></fetch>";
            #endregion

            string communicationConfigurationQuery = BuildFetchXML(triggerCommunicationActionValue, caseOriginAttribute, customerSourceAttribute, caseCurrentQueueId, companyCode);

            EntityCollection communicationConfigurationCollection = _iOrgServiceAdminContext.RetrieveMultiple(new FetchExpression(communicationConfigurationQuery));

            //If a Communications Config record matches
            if (communicationConfigurationCollection.Entities.Count > 0 && communicationConfigurationCollection.Entities[0] != null)
            {
                Entity ConfigEntity = communicationConfigurationCollection.Entities[0];

                returnArgsObj.templateName = ConfigEntity.Attributes.Contains("new_templatename") ? ConfigEntity.Attributes["new_templatename"].ToString() : string.Empty;
                returnArgsObj.templateGuid = (ConfigEntity.Attributes.Contains("new_templateid") && new Guid(ConfigEntity.Attributes["new_templateid"].ToString().Trim()) != Guid.Empty) ? new Guid(ConfigEntity.Attributes["new_templateid"].ToString().Trim()) : Guid.Empty;
                returnArgsObj.LagTime = ConfigEntity.Attributes.Contains("scrum5_surveylagtime") ? int.Parse(ConfigEntity.Attributes["scrum5_surveylagtime"].ToString()) : -1;
                returnArgsObj.SurveyFrequency = ConfigEntity.Attributes.Contains("scrum5_surveyfrequency") ? int.Parse(ConfigEntity.Attributes["scrum5_surveyfrequency"].ToString()) : -1;
            }
            else if (communicationConfigurationCollection.Entities.Count == 0)
            {
                communicationConfigurationQuery = string.Empty;
                communicationConfigurationQuery = BuildFetchXML(triggerCommunicationActionValue, caseOriginAttribute, customerSourceAttribute, caseCurrentQueueId);
                communicationConfigurationCollection = _iOrgServiceAdminContext.RetrieveMultiple(new FetchExpression(communicationConfigurationQuery));
                ///as logic to get only Communication Configuration records without Company Code is not working on N:N relation with outer join
                ///we are using Linq to achieve the same 
                IEnumerable<Entity> communicationConfigurations = from communicationConfiguration in communicationConfigurationCollection.Entities.AsEnumerable()
                                                                  where !communicationConfiguration.Contains("_CompanyCode.scrum10_companycodeid")
                                                                  select communicationConfiguration;

                if (communicationConfigurations.Count<Entity>() > 0)
                {
                    Entity ConfigEntity = communicationConfigurations.First<Entity>();
                    returnArgsObj.templateName = ConfigEntity.Attributes.Contains("new_templatename") ? ConfigEntity.Attributes["new_templatename"].ToString() : string.Empty;
                    returnArgsObj.templateGuid = (ConfigEntity.Attributes.Contains("new_templateid") && new Guid(ConfigEntity.Attributes["new_templateid"].ToString().Trim()) != Guid.Empty) ? new Guid(ConfigEntity.Attributes["new_templateid"].ToString().Trim()) : Guid.Empty;
                    returnArgsObj.LagTime = ConfigEntity.Attributes.Contains("scrum5_surveylagtime") ? int.Parse(ConfigEntity.Attributes["scrum5_surveylagtime"].ToString()) : -1;
                    returnArgsObj.SurveyFrequency = ConfigEntity.Attributes.Contains("scrum5_surveyfrequency") ? int.Parse(ConfigEntity.Attributes["scrum5_surveyfrequency"].ToString()) : -1;
                }
            }

            return returnArgsObj;
        }

        public enum BooleanValue { No, Yes };

        public enum CaseOriginValues
        {
            Phone = 1,
            Email,
            Web,
            Chat = 5,
            Walkin,
            Post,
            EDMTool
        }

        public enum CaseTypeValues
        {
            Blank = 0,
            Inquiry,
            Task
        }

        public enum InteractionRequiredValues
        {
            Blank = 0,
            Yes,
            No
        }

        public enum ActionTypeValues
        {
            CaseCreation = 1,
            CaseResolution = 2
        }

        public enum CustomerSourceValue { External = 1, Internal }

        //v-degort: Made below methods public
        public string FetchAttributeSchema_CustomerSource(int _customerSource)
        {
            string customerSourceSchemaname = string.Empty;
            switch (_customerSource)
            {
                case (int)CustomerSourceValue.External:
                    customerSourceSchemaname = "scrum9_customersourceexternal";
                    break;
                case (int)CustomerSourceValue.Internal:
                    customerSourceSchemaname = "scrum9_customersourceinternal";
                    break;
                default: throw new ArgumentNullException("_customerSource");
            }
            return customerSourceSchemaname;
        }

        public string FetchAttributeSchema_CaseOrigin(int caseorigindatavalue)
        {
            string caseoriginschemaname = string.Empty;
            switch (caseorigindatavalue)
            {
                case (int)CaseOriginValues.Phone:
                    caseoriginschemaname = "scrum9_originphone";
                    break;
                case (int)CaseOriginValues.Email:
                    caseoriginschemaname = "scrum9_originemail";
                    break;
                case (int)CaseOriginValues.Web:
                    caseoriginschemaname = "scrum9_originweb";
                    break;
                case (int)CaseOriginValues.Chat:
                    caseoriginschemaname = "scrum9_originchat";
                    break;
                case (int)CaseOriginValues.Walkin:
                    caseoriginschemaname = "scrum9_originwalkin";
                    break;
                case (int)CaseOriginValues.Post:
                    caseoriginschemaname = "scrum9_originpost";
                    break;
                case (int)CaseOriginValues.EDMTool:
                    caseoriginschemaname = "scrum9_originedmtool";
                    break;
            }
            return caseoriginschemaname;
        }

        public string FetchAttributeSchema_CaseType(int casetypedatavalue)
        {
            string casetypeschemaname = string.Empty;
            switch (casetypedatavalue)
            {
                case (int)CaseTypeValues.Blank:
                    casetypeschemaname = "scrum9_casetypeblank";
                    break;
                case (int)CaseTypeValues.Inquiry:
                    casetypeschemaname = "scrum9_casetypeinquiry";
                    break;
                case (int)CaseTypeValues.Task:
                    casetypeschemaname = "scrum9_casetypetask";
                    break;
            }
            return casetypeschemaname;
        }

        public string FetchAttributeSchema_InteractionRequired(int interactionrequireddatavalue)
        {
            string interactionrequiredschemaname = string.Empty;
            switch (interactionrequireddatavalue)
            {
                case (int)InteractionRequiredValues.Blank:
                    interactionrequiredschemaname = "scrum9_interactionisblank";
                    break;
                case (int)InteractionRequiredValues.Yes:
                    interactionrequiredschemaname = "scrum9_interactionisrequired";
                    break;
                case (int)InteractionRequiredValues.No:
                    interactionrequiredschemaname = "scrum9_interactionnotrequired";
                    break;
            }
            return interactionrequiredschemaname;
        }


        #endregion

        /// added by v-namuth (Wave 7 Release)
        /// for retrieving CC records based on Company Code
        #region BuildFetchXML with Company Code
        /// <summary>
        /// Build Fetch XML for Determining Communication Configuration 
        /// if Company Code is passes from calling method
        /// returns the fetch XML   
        /// </summary>
        /// 
        /// <param name="triggerCommunicationActionValue"> Contains trigger CommunicationAction Value
        /// <param name="caseOriginAttribute">Contains case Origin Attribute
        /// <param name="customerSourceAttribute">Contains customer Source Attribute
        /// <param name="caseCurrentQueueId">Contains cas eCurrent QueueId 
        /// <param name="caseCurrentQueueId">Contains company Code
        /// </param>
        //
        public string BuildFetchXML(int triggerCommunicationActionValue, string caseOriginAttribute, string customerSourceAttribute, Guid caseCurrentQueueId, string companyCode)
        {

            string communicationConfigurationQuery = @"<?xml version='1.0'?>";
            communicationConfigurationQuery += "<fetch version='1.0' output-format='xml-platform' mapping='logical' distinct='true'>";
            communicationConfigurationQuery += "<entity name='new_templateinfo'>";
            communicationConfigurationQuery += "<attribute name='new_templateid' />";
            communicationConfigurationQuery += "<attribute name='new_templatename' />";
            communicationConfigurationQuery += "<attribute name='scrum5_surveylagtime' />";
            communicationConfigurationQuery += "<attribute name='scrum5_surveyfrequency' />";
            communicationConfigurationQuery += "<attribute name='scrum9_action' />";
            communicationConfigurationQuery += "<attribute name='new_templateinfoid' />";
            communicationConfigurationQuery += "<order attribute='createdon' descending='true' />";
            communicationConfigurationQuery += "<filter type='and'>";
            communicationConfigurationQuery += "<condition attribute='statecode' operator='eq' value='0' />";
            communicationConfigurationQuery += "<condition attribute='new_templateid' operator='not-null'/>";
            communicationConfigurationQuery += "<condition attribute='new_templatename' operator='not-null'/>";
            communicationConfigurationQuery += "<condition attribute='scrum9_action' operator='eq' value='" + triggerCommunicationActionValue.ToString() + "' />";
            communicationConfigurationQuery += "<condition attribute='" + customerSourceAttribute + "' operator='eq' value='1' />";
            communicationConfigurationQuery += "<condition attribute='" + caseOriginAttribute + "' operator='eq' value='1' />";
            communicationConfigurationQuery += "</filter>";
            communicationConfigurationQuery += "<link-entity name='scrum9_new_templateinfo_queue' from='new_templateinfoid' to='new_templateinfoid' visible='false' intersect='true'>";
            communicationConfigurationQuery += "<link-entity name='queue' from='queueid' to='queueid' alias='_QueueDetails'>";
            communicationConfigurationQuery += "<filter type='and'>";
            communicationConfigurationQuery += "<condition attribute='queueid' operator='eq' uitype='queue' value='" + caseCurrentQueueId.ToString() + "' />";
            communicationConfigurationQuery += "</filter></link-entity></link-entity>";

            communicationConfigurationQuery += "<link-entity name='scrum10_companycode_new_templateinfo' from='new_templateinfoid' to='new_templateinfoid' visible='false' intersect='true'>";
            communicationConfigurationQuery += "<link-entity name='scrum10_companycode' from='scrum10_companycodeid' to='scrum10_companycodeid' alias='_CompanyCode'>";
            communicationConfigurationQuery += "<filter type='and'>";
            communicationConfigurationQuery += "<condition attribute='scrum10_name' operator='eq' value='" + companyCode + "' />";
            //communicationConfigurationQuery += "<condition attribute='statecode' operator='eq' value='0' />";
            communicationConfigurationQuery += "</filter>";
            communicationConfigurationQuery += "</link-entity></link-entity>";

            communicationConfigurationQuery += "</entity></fetch>";

            return communicationConfigurationQuery;
        }

        #endregion

        /// added by v-namuth (Wave 7 Release)
        /// for retrieving CC records based on Company Code
        #region BuildFetchXML without Company Code
        /// <summary>
        /// Build Fetch XML for Determining Communication Configuration 
        /// if Company Code is not passes from calling method
        /// returns the fetch XML   
        /// </summary>
        /// 
        /// <param name="triggerCommunicationActionValue"> Contains trigger CommunicationAction Value
        /// <param name="caseOriginAttribute">Contains case Origin Attribute
        /// <param name="customerSourceAttribute">Contains customer Source Attribute
        /// <param name="caseCurrentQueueId">Contains cas eCurrent QueueId 
        /// </param>
        public string BuildFetchXML(int triggerCommunicationActionValue, string caseOriginAttribute, string customerSourceAttribute, Guid caseCurrentQueueId)
        {
            string communicationConfigurationQuery = @"<?xml version='1.0'?>";
            communicationConfigurationQuery += "<fetch version='1.0' output-format='xml-platform' mapping='logical' distinct='true'>";
            communicationConfigurationQuery += "<entity name='new_templateinfo'>";
            communicationConfigurationQuery += "<attribute name='new_templateid' />";
            communicationConfigurationQuery += "<attribute name='new_templatename' />";
            communicationConfigurationQuery += "<attribute name='scrum5_surveylagtime' />";
            communicationConfigurationQuery += "<attribute name='scrum5_surveyfrequency' />";
            communicationConfigurationQuery += "<attribute name='scrum9_action' />";
            communicationConfigurationQuery += "<attribute name='new_templateinfoid' />";
            communicationConfigurationQuery += "<order attribute='createdon' descending='true' />";
            communicationConfigurationQuery += "<filter type='and'>";
            communicationConfigurationQuery += "<condition attribute='statecode' operator='eq' value='0' />";
            communicationConfigurationQuery += "<condition attribute='new_templateid' operator='not-null'/>";
            communicationConfigurationQuery += "<condition attribute='new_templatename' operator='not-null'/>";
            communicationConfigurationQuery += "<condition attribute='scrum9_action' operator='eq' value='" + triggerCommunicationActionValue.ToString() + "' />";
            communicationConfigurationQuery += "<condition attribute='" + customerSourceAttribute + "' operator='eq' value='1' />";
            communicationConfigurationQuery += "<condition attribute='" + caseOriginAttribute + "' operator='eq' value='1' />";
            communicationConfigurationQuery += "</filter>";
            communicationConfigurationQuery += "<link-entity name='scrum9_new_templateinfo_queue' from='new_templateinfoid' to='new_templateinfoid' visible='false' intersect='true'>";
            communicationConfigurationQuery += "<link-entity name='queue' from='queueid' to='queueid' alias='_QueueDetails'>";
            communicationConfigurationQuery += "<filter type='and'>";
            communicationConfigurationQuery += "<condition attribute='queueid' operator='eq' uitype='queue' value='" + caseCurrentQueueId.ToString() + "' />";
            communicationConfigurationQuery += "</filter></link-entity></link-entity>";

            communicationConfigurationQuery += "<link-entity name='scrum10_companycode_new_templateinfo' from='new_templateinfoid' to='new_templateinfoid' visible='false' link-type='outer'>";
            communicationConfigurationQuery += "<link-entity name='scrum10_companycode' from='scrum10_companycodeid' to='scrum10_companycodeid' alias='_CompanyCode' link-type='outer'>";
            communicationConfigurationQuery += "<attribute name='scrum10_companycodeid' />";
            communicationConfigurationQuery += "<filter type='and'>";
            communicationConfigurationQuery += "<condition attribute='statecode' operator='eq' value='0'  />";
            //communicationConfigurationQuery += "<condition attribute='scrum10_name' operator='null'  />";
            communicationConfigurationQuery += "</filter></link-entity></link-entity>";
            communicationConfigurationQuery += "</entity></fetch>";

            return communicationConfigurationQuery;
        }
        #endregion

    }

    public class CommunicationConfigArguments
    {
        public CommunicationConfigArguments()
        {
            templateName = string.Empty;
            templateGuid = Guid.Empty;
            LagTime = -1;
            SurveyFrequency = -1;
        }

        public string templateName
        { get; set; }

        public Guid templateGuid
        { get; set; }

        public int LagTime
        { get; set; }

        public int SurveyFrequency
        { get; set; }

    }
    #endregion
}
