﻿using System;
using Microsoft.VisualStudio.TestTools.UnitTesting;
using CustomerActivity;
using Moq;
using Microsoft.Xrm.Sdk.Query;
using Microsoft.Xrm.Sdk;

namespace UnitTestProject
{
    [TestClass]
    public class ReactivateCaseTest
    {
        [TestMethod]
        public void Execute_Test1()
        {
            var serviceMock = new Mock<IOrganizationService>();
            var factoryMock = new Mock<IOrganizationServiceFactory>();
            var tracingServiceMock = new Mock<ITracingService>();
            var notificationServiceMock = new Mock<IServiceEndpointNotificationService>();
            var pluginContextMock = new Mock<IPluginExecutionContext>();
            var serviceProviderMock = new Mock<IServiceProvider>();


            Entity actualEntity = new Entity();
            //serviceMock.Setup(t => t.Create(It.IsAny<Entity>()));
            var notificationService = notificationServiceMock.Object;


            Guid userId = new Guid("EFFD5189-95FB-E711-810D-FC15B4281C08");
            Guid currentUserid = new Guid("EFFD5189-95FB-E711-810D-FC15B4281C08");
            var approvalGuid = new Guid("661AEEF4-2F05-EA11-A991-000D3A15A153");//Guid.NewGuid();

            serviceMock.Setup(s => s.Retrieve(It.IsAny<string>(), It.IsAny<Guid>(), It.IsAny<ColumnSet>()))
               .Returns(CustomerActivityEntity(approvalGuid));
            // serviceMock.Setup(s => s.Retrieve("relonl6_internalapproval", approvalGuid, new Microsoft.Xrm.Sdk.Query.ColumnSet("relonl6_approvalstatus", "relonl6_statuschangeddate", "ownerid", "regardingobjectid", "relonl6_actualapprover")))
            serviceMock.Setup(s => s.Retrieve(It.IsAny<string>(), It.IsAny<Guid>(), It.IsAny<ColumnSet>()))
               .Returns(RetrieveCaseEntity(approvalGuid));
            serviceMock.Setup(s => s.Update(CustActEntity(approvalGuid)));
            IOrganizationService service = serviceMock.Object;
            factoryMock.Setup(t => t.CreateOrganizationService(It.IsAny<Guid>())).Returns(service);
            var factory = factoryMock.Object;
            tracingServiceMock.Setup(t => t.Trace(It.IsAny<string>(), It.IsAny<object[]>())).Callback<string, object[]>((t1, t2) => Console.WriteLine(t1, t2));
            var tracingService = tracingServiceMock.Object;

            //EntityImageCollection imgCollection = new EntityImageCollection();
            //imgCollection.Add("", "");

            ParameterCollection inputParameters = new ParameterCollection();
            inputParameters.Add("Target", CustomerActivityEntity(approvalGuid));
            pluginContextMock.Setup(t => t.InputParameters).Returns(inputParameters);
            pluginContextMock.Setup(t => t.UserId).Returns(userId);
            pluginContextMock.Setup(t => t.InitiatingUserId).Returns(currentUserid);



            //finish preparing the plugincontextmock
            pluginContextMock.Setup(t => t.InputParameters).Returns(inputParameters);
            //pluginContextMock.Setup(t => t.OutputParameters).Returns(outputParameters);
            pluginContextMock.Setup(t => t.UserId).Returns(userId);
            pluginContextMock.Setup(t => t.PrimaryEntityName).Returns("rel13_customeractivity");
            var pluginContext = pluginContextMock.Object;

            //set up a serviceprovidermock
            serviceProviderMock.Setup(t => t.GetService(It.Is<Type>(i => i == typeof(IServiceEndpointNotificationService)))).Returns(notificationService);
            serviceProviderMock.Setup(t => t.GetService(It.Is<Type>(i => i == typeof(ITracingService)))).Returns(tracingService);
            serviceProviderMock.Setup(t => t.GetService(It.Is<Type>(i => i == typeof(IOrganizationServiceFactory)))).Returns(factory);
            serviceProviderMock.Setup(t => t.GetService(It.Is<Type>(i => i == typeof(IPluginExecutionContext)))).Returns(pluginContext);
            var serviceProvider = serviceProviderMock.Object;

            string a = "abc";
            string b = "bcs";
            ReactivateCase approvalobj = new ReactivateCase(a, b);
            approvalobj.Execute(serviceProvider);
        }


        [TestMethod]
        public void Execute_Test()
        {
            //ARRANGE
            var serviceMock = new Mock<IOrganizationService>();
            var factoryMock = new Mock<IOrganizationServiceFactory>();
            var tracingServiceMock = new Mock<ITracingService>();
            var notificationServiceMock = new Mock<IServiceEndpointNotificationService>();
            var pluginContextMock = new Mock<IPluginExecutionContext>();
            var serviceProviderMock = new Mock<IServiceProvider>();

            //create a guid that we want our mock CRM organization service Create method to return when called
            Guid idToReturn = Guid.NewGuid();

            //next - create an entity object that will allow us to capture the entity record that is passed to the Create method
            Entity actualEntity = new Entity();

            //setup the CRM service mock
            serviceMock.Setup(t =>
                t.Create(It.IsAny<Entity>()))

                //when Create is called with any entity as an invocation parameter
                .Returns(idToReturn) //return the idToReturn guid
                .Callback<Entity>(s => actualEntity = s); //store the Create method invocation parameter for inspection later
            IOrganizationService service = serviceMock.Object;

            //set up a mock servicefactory using the CRM service mock
            factoryMock.Setup(t => t.CreateOrganizationService(It.IsAny<Guid>())).Returns(service);
            var factory = factoryMock.Object;

            //set up a mock tracingservice - will write output to console
            tracingServiceMock.Setup(t => t.Trace(It.IsAny<string>(), It.IsAny<object[]>())).Callback<string, object[]>((t1, t2) => Console.WriteLine(t1, t2));
            var tracingService = tracingServiceMock.Object;

            //set up mock notificationservice - not going to do anything with this
            var notificationService = notificationServiceMock.Object;

            //set up mock plugincontext with input/output parameters, etc.
            Entity targetEntity = new Entity("rel13_customeractivity");
            targetEntity.LogicalName = "rel13_customeractivity";

            //userid to be used inside the plug-in
            Guid userId = Guid.NewGuid();

            //"generated" account id
            Guid accountId = Guid.NewGuid();

            //get parameter collections ready
            ParameterCollection inputParameters = new ParameterCollection();
            inputParameters.Add("Target", targetEntity);
            ParameterCollection outputParameters = new ParameterCollection();
            outputParameters.Add("id", accountId);

            //finish preparing the plugincontextmock
            pluginContextMock.Setup(t => t.InputParameters).Returns(inputParameters);
            pluginContextMock.Setup(t => t.OutputParameters).Returns(outputParameters);
            pluginContextMock.Setup(t => t.UserId).Returns(userId);
            pluginContextMock.Setup(t => t.PrimaryEntityName).Returns("rel13_customeractivity");
            var pluginContext = pluginContextMock.Object;

            //set up a serviceprovidermock
            serviceProviderMock.Setup(t => t.GetService(It.Is<Type>(i => i == typeof(IServiceEndpointNotificationService)))).Returns(notificationService);
            serviceProviderMock.Setup(t => t.GetService(It.Is<Type>(i => i == typeof(ITracingService)))).Returns(tracingService);
            serviceProviderMock.Setup(t => t.GetService(It.Is<Type>(i => i == typeof(IOrganizationServiceFactory)))).Returns(factory);
            serviceProviderMock.Setup(t => t.GetService(It.Is<Type>(i => i == typeof(IPluginExecutionContext)))).Returns(pluginContext);
            var serviceProvider = serviceProviderMock.Object;

            //ACT
            //instantiate the plugin object and execute it with the testserviceprovider
            //FollowupPlugin followupPlugin = new FollowupPlugin();
            //followupPlugin.Execute(serviceProvider);

            //ASSERT
            //verify the entity created inside the plugin the values we expect
            Assert.AreEqual("Send e-mail to the new customer.", actualEntity["subject"]);
            Assert.AreEqual("Follow up with the customer. Check if there are any new issues that need resolution.", actualEntity["description"]);
            Assert.AreEqual(DateTime.Now.AddDays(7).ToLongDateString(), ((DateTime)actualEntity["scheduledstart"]).ToLongDateString()); //lazy way to get around milliseconds being different
            Assert.AreEqual(DateTime.Now.AddDays(7).ToLongDateString(), ((DateTime)actualEntity["scheduledend"]).ToLongDateString()); //lazy way to get around milliseconds being different
            Assert.AreEqual("account", actualEntity["category"]);
            Assert.AreEqual(accountId, ((EntityReference)actualEntity["regardingobjectid"]).Id);
        }

        public Entity CustomerActivityEntity(Guid approvalID)
        {
            Entity customeractivityEntity = new Entity("rel13_customeractivity") { Id = approvalID };
            customeractivityEntity.Attributes.Add("rel13_caseid", "D8778E585B65E811810BC4346BDC7121,C4D4193776234DC590F30C4491EA8A20");
            customeractivityEntity.Attributes.Add("rel13_reactivatecase", true);
            customeractivityEntity.Attributes.Add("rel13_requestupdate", true);
            //approvalEntity.Attributes.Add("ownerid", new EntityReference("D8778E585B65E811810BC4346BDC7121"));
            //approvalEntity.Attributes.Add("regardingobjectid", new Guid("DC778E585B65E811810BC4346BDC7121"));
            //approvalEntity.Attributes.Add("relonl6_actualapprover", new Guid("C4D4193776234DC590F30C4491EA8A20"));
            return customeractivityEntity;
        }


        public Entity RetrieveCaseEntity(Guid approvalID)
        {
            Entity incidentEntity = new Entity("incident") { Id = approvalID };
            incidentEntity.Attributes.Add("statecode", new OptionSetValue(0));
            return incidentEntity;
        }

        public Entity CustActEntity(Guid approvalID)
        {
            Entity CustActEntity = new Entity("rel13_customeractivity") { Id = approvalID };
            CustActEntity.Attributes["subject"] = "Customer Activity: Reactivated case";
            CustActEntity.Attributes["rel13_requesttype"] = new OptionSetValue(347870002);
            CustActEntity.Attributes["regardingobjectid"] = new EntityReference("incident", Guid.NewGuid());
            CustActEntity.Attributes["rel13_currentqueue"] = new EntityReference("queue", Guid.NewGuid());
            CustActEntity.Id = Guid.NewGuid();

            return CustActEntity;
        }

    }
}
