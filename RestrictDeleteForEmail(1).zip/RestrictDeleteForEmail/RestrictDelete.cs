﻿using System;
using Microsoft.Xrm.Sdk.Query;
using Microsoft.Xrm.Sdk;

namespace RestrictDeleteForEmail
{
    public class RestrictDelete : IPlugin
    {
        IOrganizationService service = null;
        //OrganizationServiceContext organizationContext = null;
        IExecutionContext context = null;
        public void Execute(IServiceProvider serviceProvider)
        {
            context = (Microsoft.Xrm.Sdk.IPluginExecutionContext)serviceProvider.GetService(typeof(Microsoft.Xrm.Sdk.IPluginExecutionContext));
            IOrganizationServiceFactory factory = (IOrganizationServiceFactory)serviceProvider.GetService(typeof(IOrganizationServiceFactory));
            service = factory.CreateOrganizationService(context.UserId);

            if (context.InputParameters.Contains("Target") && context.InputParameters["Target"] is EntityReference)
            {
                Guid currentUser = context.InitiatingUserId;
                QueryExpression queryExpression = new QueryExpression();
                queryExpression.EntityName = "role"; //role entity name
                ColumnSet cols = new ColumnSet();
                cols.AddColumn("name"); //We only need role name
                queryExpression.ColumnSet = cols;
                ConditionExpression ce = new ConditionExpression();
                ce.AttributeName = "systemuserid";
                ce.Operator = ConditionOperator.Equal;
                ce.Values.Add(currentUser);
                //system roles
                LinkEntity lnkEntityRole = new LinkEntity();
                lnkEntityRole.LinkFromAttributeName = "roleid";
                lnkEntityRole.LinkFromEntityName = "role"; //FROM
                lnkEntityRole.LinkToEntityName = "systemuserroles";
                lnkEntityRole.LinkToAttributeName = "roleid";
                //system users
                LinkEntity lnkEntitySystemusers = new LinkEntity();
                lnkEntitySystemusers.LinkFromEntityName = "systemuserroles";
                lnkEntitySystemusers.LinkFromAttributeName = "systemuserid";
                lnkEntitySystemusers.LinkToEntityName = "systemuser";
                lnkEntitySystemusers.LinkToAttributeName = "systemuserid";
                lnkEntitySystemusers.LinkCriteria = new FilterExpression();
                lnkEntitySystemusers.LinkCriteria.Conditions.Add(ce);
                lnkEntityRole.LinkEntities.Add(lnkEntitySystemusers);
                queryExpression.LinkEntities.Add(lnkEntityRole);
                EntityCollection entColRoles = service.RetrieveMultiple(queryExpression);
                if (entColRoles != null && entColRoles.Entities.Count > 0)
                {
                    foreach (Entity entRole in entColRoles.Entities)
                    {
                        if (entRole.Attributes["name"].ToString().ToLower() == "askhr support representative")
                        {
                            EntityReference entity = (EntityReference)context.InputParameters["Target"];
                            Guid EntityId = entity.Id;
                            //Entity email = service.Retrieve(entity.LogicalName, EntityId, newColumnSet(true));
                            Entity email = service.Retrieve(entity.LogicalName, EntityId, new ColumnSet(true));

                            int status = ((OptionSetValue)email.Attributes["statuscode"]).Value;
                            if (status != 1)
                            {
                                throw new InvalidPluginExecutionException("You are not allowed to perform delete operation on this Email");
                            }
                        }
                    }
                }

            }
        }
    }
}


