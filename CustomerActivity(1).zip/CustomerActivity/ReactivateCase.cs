﻿using Microsoft.Crm.Sdk.Messages;
using Microsoft.Xrm.Sdk;
using Microsoft.Xrm.Sdk.Query;
using System;
using System.Collections.Generic;
using System.Linq;
using System.ServiceModel;
using System.Text;
using System.Threading.Tasks;
using System.Xml;

namespace CustomerActivity
{
    public class ReactivateCase : IPlugin
    {
        bool traceEnabled = false;
        string ReactivateTemplate = string.Empty;
        string ClosureTemplate = string.Empty;
        string updateTemplate = string.Empty;
        bool CaseActive = false;
        public ReactivateCase(string unsecureString, string secureString)
        {
            try
            {
                if (String.IsNullOrWhiteSpace(unsecureString) || String.IsNullOrWhiteSpace(secureString))
                {
                    XmlDocument doc = new XmlDocument();
                    doc.LoadXml(unsecureString);
                    traceEnabled = PluginConfiguration.GetConfigDataBool(doc, "TraceEnabled");
                    ReactivateTemplate = PluginConfiguration.GetConfigDataString(doc, "ReactivateTemplateID");
                    ClosureTemplate = PluginConfiguration.GetConfigDataString(doc, "RequestClosureTemplateID");
                    updateTemplate = PluginConfiguration.GetConfigDataString(doc, "RequestUpdateTemplateID");
                }
            }
            catch (FaultException<OrganizationServiceFault>)
            {
                throw;
            }
            catch (Exception)
            {
                throw;
            }
        }

        #region Plug In Configuration class to retrieve corresponding values for the passed in keys from an unsecured configuration

        internal class PluginConfiguration
        {
            private static string GetValueNode(XmlDocument doc, string key)
            {
                XmlNode node = doc.SelectSingleNode(String.Format("Settings/setting[@name='{0}']", key));
                if (node != null)
                {
                    return node.SelectSingleNode("value").InnerText;
                }
                return string.Empty;
            }

            public static Guid GetConfigDataGuid(XmlDocument doc, string label)
            {
                string tempString = GetValueNode(doc, label);
                if (tempString != string.Empty)
                {
                    return new Guid(tempString);
                }
                return Guid.Empty;
            }

            public static bool GetConfigDataBool(XmlDocument doc, string label)
            {
                bool retVar;
                if (bool.TryParse(GetValueNode(doc, label), out retVar))
                {
                    return retVar;
                }
                else
                {
                    return false;
                }
            }

            public static string GetConfigDataString(XmlDocument doc, string label)
            {
                return GetValueNode(doc, label);
            }
        }
        # endregion
        public void Execute(IServiceProvider serviceProvider)
        {
            ITracingService tracingService = (ITracingService)serviceProvider.GetService(typeof(ITracingService));
            IPluginExecutionContext context = (IPluginExecutionContext)serviceProvider.GetService(typeof(IPluginExecutionContext));
            IOrganizationServiceFactory serviceFactory = (IOrganizationServiceFactory)serviceProvider.GetService(typeof(IOrganizationServiceFactory));
            IOrganizationService service = serviceFactory.CreateOrganizationService(context.UserId);

            string caseids = string.Empty;
            Guid regardingobjectid = Guid.Empty;
            Guid CurrentQueueid = Guid.Empty;

            tracingService.Trace(string.Concat("ReactivateCase", "Entered Execution Method", DateTime.Now.ToString(), "Error"));
            if (context.InputParameters.Contains("Target") && context.InputParameters["Target"] is Entity)
            {
                Entity CustomerActivityEnt = (Entity)context.InputParameters["Target"];

                if (CustomerActivityEnt.Attributes.Contains("rel13_caseid"))
                    caseids = CustomerActivityEnt.Attributes["rel13_caseid"].ToString();

                //if (CustomerActivityEnt.Attributes.Contains("regardingobjectid"))
                //    regardingobjectid = CustomerActivityEnt.Attributes["regardingobjectid"];

                //if (CustomerActivityEnt.Attributes.Contains("rel13_currentqueue"))
                //    CurrentQueueid = ((EntityReference)(CustomerActivityEnt.Attributes["rel13_currentqueue"]));

                if (CustomerActivityEnt.LogicalName != "rel13_customeractivity")
                    return;
                try
                {
                    if (caseids != null || caseids != string.Empty)
                    {
                        string[] values = caseids.Split(',');

                        regardingobjectid = new Guid(values[0]);
                        CurrentQueueid = new Guid(values[1]);

                       
                        ColumnSet caseattributes = new ColumnSet(new string[] { "statecode" });

                        Entity Caseentity = service.Retrieve("incident", regardingobjectid, caseattributes);

                        if (Caseentity.Attributes.Contains("statecode"))
                        {
                            tracingService.Trace("statecode received");
                            if (((OptionSetValue)Caseentity.Attributes["statecode"]).Value == 0)
                            {
                                tracingService.Trace("bool setstarted");
                                CaseActive = true;
                                tracingService.Trace(CaseActive.ToString());
                            }
                        }

                        //re-activate case--------------------
                        if (CustomerActivityEnt.Attributes.Contains("rel13_reactivatecase") && (bool)CustomerActivityEnt.Attributes["rel13_reactivatecase"] == true && CaseActive == false)
                        {
                            Entity CustActEntity = new Entity("rel13_customeractivity");
                            CustActEntity.Attributes["subject"] = "Customer Activity: Reactivated case";
                            CustActEntity.Attributes["rel13_requesttype"] = new OptionSetValue(347870002);
                            CustActEntity.Attributes["regardingobjectid"] = new EntityReference("incident", regardingobjectid);
                            CustActEntity.Attributes["rel13_currentqueue"] = new EntityReference("queue", CurrentQueueid);
                            CustActEntity.Id = CustomerActivityEnt.Id;
                            service.Update(CustActEntity);

                            // Reactivatecase
                            SetStateRequest req = new SetStateRequest();
                            req.EntityMoniker = new EntityReference("incident", regardingobjectid);
                            req.State = new OptionSetValue(0);
                            req.Status = new OptionSetValue(-1);
                            service.Execute(req);

                            //Below update lines commented by v-kumadh for 1908 sprint
                            //Entity CaseEntity = new Entity("incident");
                            //CaseEntity.Attributes["scrum5_workedby"] = null;
                            //CaseEntity.Id = regardingobjectid;
                            //service.Update(CaseEntity);

                            // set activity to complete state
                            SetStateRequest SetActivitytoCompleteReq = new SetStateRequest
                            {
                                EntityMoniker = new EntityReference("rel13_customeractivity", CustomerActivityEnt.Id),
                                State = new OptionSetValue(1),
                                Status = new OptionSetValue(2)
                            };
                            service.Execute(SetActivitytoCompleteReq);

                            // Route activity to current queue
                            AddToQueueRequest routePortaltoCurrentQ = new AddToQueueRequest
                            {
                                Target = new EntityReference("rel13_customeractivity", CustomerActivityEnt.Id),
                                DestinationQueueId = CurrentQueueid
                            };

                            service.Execute(routePortaltoCurrentQ);

                            //Below code is used to send the alert to the workedby user if the any customer activity updates for 1908-4822597
                            if (regardingobjectid != null)
                            {                               
                                Guid emailTemplateGuid = new Guid(ReactivateTemplate); 
                                TriggerSendEmail(regardingobjectid, emailTemplateGuid, service, tracingService);
                            }

                        }
                        // Requet Update.................
                        //if ((bool)CustomerActivityEnt.Attributes["rel13_requestclosure"] == true && CustomerActivityEnt.Attributes.Contains("rel13_requestclosure"))
                        if ((bool)CustomerActivityEnt.Attributes["rel13_requestupdate"] == true && CustomerActivityEnt.Attributes.Contains("rel13_requestupdate") && CaseActive == true)
                        {
                            tracingService.Trace(string.Concat("Request closure", "update condition 1", DateTime.Now.ToString(), "Error"));
                            //CustomerActivityEnt.Attributes["subject"] = "Customer Activity: Request an update";

                            tracingService.Trace(string.Concat("ReactivateCase", "update condition 2", DateTime.Now.ToString(), "Error"));
                            // set activity to complete state

                            Entity CustActEntity = new Entity("rel13_customeractivity");
                            CustActEntity.Attributes["subject"] = "Customer Activity:Request to close case";
                            CustActEntity.Attributes["rel13_requesttype"] = new OptionSetValue(347870001);
                            CustActEntity.Attributes["regardingobjectid"] = new EntityReference("incident", regardingobjectid);
                            CustActEntity.Attributes["rel13_currentqueue"] = new EntityReference("queue", CurrentQueueid);
                            CustActEntity.Id = CustomerActivityEnt.Id;
                            service.Update(CustActEntity);


                            SetStateRequest SetActivitytoCompleteReq = new SetStateRequest
                            {
                                EntityMoniker = new EntityReference("rel13_customeractivity", CustomerActivityEnt.Id),
                                State = new OptionSetValue(1),
                                Status = new OptionSetValue(2)
                            };
                            service.Execute(SetActivitytoCompleteReq);



                            tracingService.Trace(string.Concat("Request closure", "update condition 3", DateTime.Now.ToString(), "Error"));
                            // Route activity to current queue
                            AddToQueueRequest routePortaltoCurrentQ = new AddToQueueRequest
                            {
                                Target = new EntityReference("rel13_customeractivity", CustomerActivityEnt.Id),
                                DestinationQueueId = CurrentQueueid
                            };

                            service.Execute(routePortaltoCurrentQ);
                            tracingService.Trace(string.Concat("ReactivateCase", "update condition 4", DateTime.Now.ToString(), "Error"));

                            //Below code is used to send the alert to the workedby user if the any customer activity updates for 1908-4822597
                            if (regardingobjectid != null)
                            {                              
                                    Guid emailTemplateGuid = new Guid(ClosureTemplate);
                                    TriggerSendEmail(regardingobjectid, emailTemplateGuid, service, tracingService);                               
                            }
                        }
                        //if ((bool)CustomerActivityEnt.Attributes["rel13_requestupdate"] == true && CustomerActivityEnt.Attributes.Contains("rel13_requestupdate"))
                        else if ((bool)CustomerActivityEnt.Attributes["rel13_requestupdate"] == false && CustomerActivityEnt.Attributes.Contains("rel13_requestupdate") && CaseActive == true)
                        {
                            tracingService.Trace(string.Concat("Request update", "update condition 5", DateTime.Now.ToString(), "Error"));


                            Entity CustActEntity = new Entity("rel13_customeractivity");
                            CustActEntity.Attributes["subject"] = "Customer Activity: Request an update";
                            CustActEntity.Attributes["rel13_requesttype"] = new OptionSetValue(347870000);
                            CustActEntity.Attributes["regardingobjectid"] = new EntityReference("incident", regardingobjectid);
                            CustActEntity.Attributes["rel13_currentqueue"] = new EntityReference("queue", CurrentQueueid);
                            CustActEntity.Id = CustomerActivityEnt.Id;
                            service.Update(CustActEntity);

                            // set activity to complete state
                            SetStateRequest SetActivitytoCompleteReq = new SetStateRequest
                            {
                                EntityMoniker = new EntityReference("rel13_customeractivity", CustomerActivityEnt.Id),
                                State = new OptionSetValue(1),
                                Status = new OptionSetValue(2)
                            };
                            service.Execute(SetActivitytoCompleteReq);
                            // Route activity to current queue
                            AddToQueueRequest routePortaltoCurrentQ = new AddToQueueRequest
                            {
                                Target = new EntityReference("rel13_customeractivity", CustomerActivityEnt.Id),
                                DestinationQueueId = CurrentQueueid
                            };

                            service.Execute(routePortaltoCurrentQ);

                            //Below code is used to send the alert to the workedby user if the any customer activity updates for 1908-4822597
                            if (regardingobjectid != null)
                            {
                                //Guid emailTemplateGuid = new Guid("b3f53203-7abe-e911-a992-000d3a1a9efb");
                                Guid emailTemplateGuid = new Guid(updateTemplate);
                                TriggerSendEmail(regardingobjectid, emailTemplateGuid, service, tracingService);
                            }
                        }


                    }
                }

                catch (FaultException<OrganizationServiceFault> ex)
                {
                    throw new InvalidPluginExecutionException("An error occurred in the customer activity plug-in.", ex);
                }

                catch (Exception ex)
                {
                    throw;
                }
            }
        }

        private void SendMailToWorkedBy(Guid _incidentId, Guid _workedBy, Guid _from, Guid _caseOwner, IOrganizationService _service, ITracingService _trace, Guid emailTemplateGuid)
        {
            try
            {
                Entity fromParty = new Entity("activityparty");
                Entity toParty = new Entity("activityparty");


                fromParty["partyid"] = new EntityReference("queue", _from);
                toParty["partyid"] = new EntityReference("systemuser", _workedBy);

                //create email and set attributes           
                Entity emailEntity = new Entity("email");
                emailEntity["from"] = new Entity[] { fromParty };
                emailEntity["to"] = new Entity[] { toParty };
                emailEntity["regardingobjectid"] = new EntityReference("incident", _incidentId);
                emailEntity["ownerid"] = new EntityReference("team", _caseOwner);
                emailEntity["ownerid"] = new EntityReference("team", _caseOwner);
                emailEntity["isworkflowcreated"] = true;

                // Create the request to send email using template
                SendEmailFromTemplateRequest emailUsingTemplateReq = new SendEmailFromTemplateRequest
                {
                    Target = emailEntity,
                    TemplateId = emailTemplateGuid,
                    RegardingId = _incidentId,
                    RegardingType = "incident"
                };

                SendEmailFromTemplateResponse emailUsingTemplateResp = (SendEmailFromTemplateResponse)_service.Execute(emailUsingTemplateReq);

                // Verify that the e-mail has been created
                Guid GuidOfEmailSent = emailUsingTemplateResp.Id;
                if (!GuidOfEmailSent.Equals(Guid.Empty))
                {
                    _trace.Trace(string.Format("Email created with guid {0} and sent to the Worked By of the case", Convert.ToString(GuidOfEmailSent)));
                }
            }
            catch (Exception ex)
            {
                _trace.Trace("Exception in SendMailToWorkedBy" + ex.Message);
            }
        }

        private void TriggerSendEmail(Guid regardingobjectid, Guid emailTemplateGuid, IOrganizationService service, ITracingService _trace)
        {
            if (regardingobjectid != null)
            {
                try
                {

                    ColumnSet attributes = new ColumnSet(new string[] { "scrum5_workedby", "ownerid", "new_currentqueue", "new_currentqueuet1" });

                    Entity entityCase = service.Retrieve("incident", regardingobjectid, attributes);
                    if (entityCase != null)
                    {
                        if (entityCase.Contains("scrum5_workedby"))
                        {
                            Guid _workedby = ((EntityReference)entityCase["scrum5_workedby"]).Id;
                            Guid _currentQueue = Guid.Empty; //Current queue can not be null
                            if (entityCase.Contains("new_currentqueuet1"))
                                _currentQueue = ((EntityReference)(entityCase["new_currentqueuet1"])).Id;
                            else if (entityCase.Contains("new_currentqueue"))
                                _currentQueue = ((EntityReference)(entityCase["new_currentqueue"])).Id;

                            //Send email using template                    
                            Guid _caseOwner = ((EntityReference)(entityCase["ownerid"])).Id;
                            if (FetchCustomerResponse(_workedby, service, _trace)) //This method is to check whether user subscribed for alert or not
                            {
                                SendMailToWorkedBy(regardingobjectid, _workedby, _currentQueue, _caseOwner, service, _trace, emailTemplateGuid);
                            }
                            else
                            {
                                _trace.Trace("User not subscribed for alert");
                            }
                        }
                        else
                        {
                            _trace.Trace("Case is not having workedby value hence no notification sent.");
                        }
                    }
                    else
                    {
                        _trace.Trace("No case record found");
                    }
                }
                catch(Exception ex)
                {
                    _trace.Trace("Error while retrieving case info. " + ex.Message);
                }

            }
        }

        private Boolean FetchCustomerResponse(Guid _userId, IOrganizationService _orgServ, ITracingService _trace)
        {
            Boolean _result = false;
            try
            {
                string _fetchXml = @"<?xml version='1.0'?>
                                     <fetch distinct='false' mapping='logical' output-format='xml-platform' version='1.0'>
                                    <entity name='systemuser'>
                                        <attribute name='fullname'/>
                                        <attribute name='systemuserid'/>
                                        <attribute name='rel12_subscribedforcustomeralerts'/>
                                        <order descending='false' attribute='fullname'/>
                                        <filter type='and'>" +
                                        "<condition attribute='systemuserid' value='" + _userId + "' uitype='systemuser' operator='eq'/>" +
                                        "</filter>" +
                                        "</entity>" +
                                        "</fetch>";
                EntityCollection _ent = _orgServ.RetrieveMultiple(new FetchExpression(_fetchXml));
                if (_ent != null)
                {
                    if (_ent.Entities.Count > 0)
                    {
                        if (_ent.Entities[0].Contains("rel12_subscribedforcustomeralerts"))
                            _result = Convert.ToBoolean(_ent.Entities[0]["rel12_subscribedforcustomeralerts"]);
                        return _result;
                    }
                }
                else
                {
                    _trace.Trace("User not subscribed for user alert");
                }

                return _result;
            }
            catch (Exception ex)
            {
                _trace.Trace("Error inFetchCustomerResponse" + ex.Message);
                return _result;
            }
        }
    }
}
