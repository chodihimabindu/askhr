﻿using System;
using Microsoft.VisualStudio.TestTools.UnitTesting;
using CustomerActivity;
using Moq;
using Microsoft.Xrm.Sdk.Query;
using Microsoft.Xrm.Sdk;

namespace UnitTestProject
{
    [TestClass]
    public class ReactivateCaseTest
    {
        [TestMethod]
        public void Execute_Test1()
        {
            var serviceMock = new Mock<IOrganizationService>();
            var factoryMock = new Mock<IOrganizationServiceFactory>();
            var tracingServiceMock = new Mock<ITracingService>();
            var notificationServiceMock = new Mock<IServiceEndpointNotificationService>();
            var pluginContextMock = new Mock<IPluginExecutionContext>();
            var serviceProviderMock = new Mock<IServiceProvider>();

            var notificationService = notificationServiceMock.Object;

            Guid userId = new Guid("EFFD5189-95FB-E711-810D-FC15B4281C08");
            Guid currentUserid = new Guid("EFFD5189-95FB-E711-810D-FC15B4281C08");
            var rel13_customeractivityId = new Guid("661AEEF4-2F05-EA11-A991-000D3A15A153");//Guid.NewGuid();

            //serviceMock.Setup(s => s.Retrieve(It.IsAny<string>(), It.IsAny<Guid>(), It.IsAny<ColumnSet>()))
            //   .Returns(CustomerActivityEntity(approvalGuid));
            // serviceMock.Setup(s => s.Retrieve("relonl6_internalapproval", approvalGuid, new Microsoft.Xrm.Sdk.Query.ColumnSet("relonl6_approvalstatus", "relonl6_statuschangeddate", "ownerid", "regardingobjectid", "relonl6_actualapprover")))

            IOrganizationService service = serviceMock.Object;
            factoryMock.Setup(t => t.CreateOrganizationService(It.IsAny<Guid>())).Returns(service);
            var factory = factoryMock.Object;
            tracingServiceMock.Setup(t => t.Trace(It.IsAny<string>(), It.IsAny<object[]>())).Callback<string, object[]>((t1, t2) => Console.WriteLine(t1, t2));
            var tracingService = tracingServiceMock.Object;

            //EntityImageCollection imgCollection = new EntityImageCollection();
            //imgCollection.Add("", "");

            ParameterCollection inputParameters = new ParameterCollection();
            inputParameters.Add("Target", CustomerActivityEntity(rel13_customeractivityId));
            pluginContextMock.Setup(t => t.InputParameters).Returns(inputParameters);
            pluginContextMock.Setup(t => t.UserId).Returns(userId);
            pluginContextMock.Setup(t => t.InitiatingUserId).Returns(currentUserid);

            //finish preparing the plugincontextmock
            pluginContextMock.Setup(t => t.InputParameters).Returns(inputParameters);
            //pluginContextMock.Setup(t => t.OutputParameters).Returns(outputParameters);
            pluginContextMock.Setup(t => t.UserId).Returns(userId);
            pluginContextMock.Setup(t => t.PrimaryEntityName).Returns("rel13_customeractivity");
            var pluginContext = pluginContextMock.Object;

            //set up a serviceprovidermock
            serviceProviderMock.Setup(t => t.GetService(It.Is<Type>(i => i == typeof(IServiceEndpointNotificationService)))).Returns(notificationService);
            serviceProviderMock.Setup(t => t.GetService(It.Is<Type>(i => i == typeof(ITracingService)))).Returns(tracingService);
            serviceProviderMock.Setup(t => t.GetService(It.Is<Type>(i => i == typeof(IOrganizationServiceFactory)))).Returns(factory);
            serviceProviderMock.Setup(t => t.GetService(It.Is<Type>(i => i == typeof(IPluginExecutionContext)))).Returns(pluginContext);
            var serviceProvider = serviceProviderMock.Object;

            // Retrieve and Update Logic
            serviceMock.Setup(s => s.Retrieve(It.IsAny<string>(), It.IsAny<Guid>(), It.IsAny<ColumnSet>()))
              .Returns(RetrieveCaseEntity(rel13_customeractivityId));
            serviceMock.Setup(s => s.Update(CustActEntity(rel13_customeractivityId)));

            string unSecure = @"<Settings>" +
                              "<setting name='TraceEnabled'>" +
                                "<value>true</value>" +
                              "</setting>" +
                            "<setting name='ReactivateTemplateID'>" +
                                "<value>EFFD5189-95FB-E711-810D-FC15B4281C08</value>" +
                              "</setting>" +
                            "<setting name='RequestClosureTemplateID'>" +
                                "<value>EFFD5189-95FB-E711-810D-FC15B4281C08</value>" +
                              "</setting>" +
                            "<setting name='RequestUpdateTemplateID'>" +
                                "<value>EFFD5189-95FB-E711-810D-FC15B4281C08</value>" +
                              "</setting>" +
                            "</Settings>";
            string secure = "abc";
            //string unSecure = "<Settings><setting name = 'TraceEnabled'> <value> true </value></setting><setting name = 'ReactivateTemplateID'> <value>EFFD5189 - 95FB - E711 - 810D - FC15B4281C08 </value></setting ><setting name = 'RequestClosureTemplateID'> <value>EFFD5189 - 95FB - E711 - 810D - FC15B4281C08</value> </setting> <setting name = 'RequestUpdateTemplateID'><value>EFFD5189 - 95FB - E711 - 810D - FC15B4281C08 </value></setting ></Settings>";
            ReactivateCase reactivateCase = new ReactivateCase(unSecure, secure);
            reactivateCase.Execute(serviceProvider);
        }

        public Entity CustomerActivityEntity(Guid approvalID)
        {
            Entity customeractivityEntity = new Entity("rel13_customeractivity") { Id = approvalID };
            customeractivityEntity.Attributes.Add("rel13_caseid", "D8778E585B65E811810BC4346BDC7121,C4D4193776234DC590F30C4491EA8A20");
            customeractivityEntity.Attributes.Add("rel13_reactivatecase", true);
            customeractivityEntity.Attributes.Add("rel13_requestupdate", false);
            //approvalEntity.Attributes.Add("ownerid", new EntityReference("D8778E585B65E811810BC4346BDC7121"));
            //approvalEntity.Attributes.Add("regardingobjectid", new Guid("DC778E585B65E811810BC4346BDC7121"));
            //approvalEntity.Attributes.Add("relonl6_actualapprover", new Guid("C4D4193776234DC590F30C4491EA8A20"));
            return customeractivityEntity;
        }


        public Entity RetrieveCaseEntity(Guid approvalID)
        {
            Entity incidentEntity = new Entity("incident") { Id = approvalID };
            incidentEntity.Attributes.Add("statecode", new OptionSetValue(0));
            return incidentEntity;
        }

        public Entity CustActEntity(Guid approvalID)
        {
            Entity CustActEntity = new Entity("rel13_customeractivity") { Id = approvalID };
            CustActEntity.Attributes["subject"] = "Customer Activity: Reactivated case";
            CustActEntity.Attributes["rel13_requesttype"] = new OptionSetValue(347870002);
            CustActEntity.Attributes["regardingobjectid"] = new EntityReference("incident", Guid.NewGuid());
            CustActEntity.Attributes["rel13_currentqueue"] = new EntityReference("queue", Guid.NewGuid());
            CustActEntity.Id = Guid.NewGuid();

            return CustActEntity;
        }

        [TestMethod]
        public void Execute_Test2()
        {
            var serviceMock = new Mock<IOrganizationService>();
            var factoryMock = new Mock<IOrganizationServiceFactory>();
            var tracingServiceMock = new Mock<ITracingService>();
            var notificationServiceMock = new Mock<IServiceEndpointNotificationService>();
            var pluginContextMock = new Mock<IPluginExecutionContext>();
            var serviceProviderMock = new Mock<IServiceProvider>();

            var notificationService = notificationServiceMock.Object;

            Guid userId = new Guid("EFFD5189-95FB-E711-810D-FC15B4281C08");
            Guid currentUserid = new Guid("EFFD5189-95FB-E711-810D-FC15B4281C08");
            var rel13_customeractivityId = new Guid("661AEEF4-2F05-EA11-A991-000D3A15A153");//Guid.NewGuid();

            //serviceMock.Setup(s => s.Retrieve(It.IsAny<string>(), It.IsAny<Guid>(), It.IsAny<ColumnSet>()))
            //   .Returns(CustomerActivityEntity(approvalGuid));
            // serviceMock.Setup(s => s.Retrieve("relonl6_internalapproval", approvalGuid, new Microsoft.Xrm.Sdk.Query.ColumnSet("relonl6_approvalstatus", "relonl6_statuschangeddate", "ownerid", "regardingobjectid", "relonl6_actualapprover")))

            IOrganizationService service = serviceMock.Object;
            factoryMock.Setup(t => t.CreateOrganizationService(It.IsAny<Guid>())).Returns(service);
            var factory = factoryMock.Object;
            tracingServiceMock.Setup(t => t.Trace(It.IsAny<string>(), It.IsAny<object[]>())).Callback<string, object[]>((t1, t2) => Console.WriteLine(t1, t2));
            var tracingService = tracingServiceMock.Object;

            //EntityImageCollection imgCollection = new EntityImageCollection();
            //imgCollection.Add("", "");

            ParameterCollection inputParameters = new ParameterCollection();
            inputParameters.Add("Target", CustomerActivityEntity2(rel13_customeractivityId));
            pluginContextMock.Setup(t => t.InputParameters).Returns(inputParameters);
            pluginContextMock.Setup(t => t.UserId).Returns(userId);
            pluginContextMock.Setup(t => t.InitiatingUserId).Returns(currentUserid);

            //finish preparing the plugincontextmock
            pluginContextMock.Setup(t => t.InputParameters).Returns(inputParameters);
            //pluginContextMock.Setup(t => t.OutputParameters).Returns(outputParameters);
            pluginContextMock.Setup(t => t.UserId).Returns(userId);
            pluginContextMock.Setup(t => t.PrimaryEntityName).Returns("rel13_customeractivity");
            var pluginContext = pluginContextMock.Object;

            //set up a serviceprovidermock
            serviceProviderMock.Setup(t => t.GetService(It.Is<Type>(i => i == typeof(IServiceEndpointNotificationService)))).Returns(notificationService);
            serviceProviderMock.Setup(t => t.GetService(It.Is<Type>(i => i == typeof(ITracingService)))).Returns(tracingService);
            serviceProviderMock.Setup(t => t.GetService(It.Is<Type>(i => i == typeof(IOrganizationServiceFactory)))).Returns(factory);
            serviceProviderMock.Setup(t => t.GetService(It.Is<Type>(i => i == typeof(IPluginExecutionContext)))).Returns(pluginContext);
            var serviceProvider = serviceProviderMock.Object;

            // Retrieve and Update Logic
            serviceMock.Setup(s => s.Retrieve(It.IsAny<string>(), It.IsAny<Guid>(), It.IsAny<ColumnSet>()))
              .Returns(RetrieveCaseEntity2(rel13_customeractivityId));
            serviceMock.Setup(s => s.Update(CustActEntity2(rel13_customeractivityId)));

            string unSecure = @"<Settings>" +
                              "<setting name='TraceEnabled'>" +
                                "<value>true</value>" +
                              "</setting>" +
                            "<setting name='ReactivateTemplateID'>" +
                                "<value>EFFD5189-95FB-E711-810D-FC15B4281C08</value>" +
                              "</setting>" +
                            "<setting name='RequestClosureTemplateID'>" +
                                "<value>EFFD5189-95FB-E711-810D-FC15B4281C08</value>" +
                              "</setting>" +
                            "<setting name='RequestUpdateTemplateID'>" +
                                "<value>EFFD5189-95FB-E711-810D-FC15B4281C08</value>" +
                              "</setting>" +
                            "</Settings>";
            string secure = "abc";
            //string unSecure = "<Settings><setting name = 'TraceEnabled'> <value> true </value></setting><setting name = 'ReactivateTemplateID'> <value>EFFD5189 - 95FB - E711 - 810D - FC15B4281C08 </value></setting ><setting name = 'RequestClosureTemplateID'> <value>EFFD5189 - 95FB - E711 - 810D - FC15B4281C08</value> </setting> <setting name = 'RequestUpdateTemplateID'><value>EFFD5189 - 95FB - E711 - 810D - FC15B4281C08 </value></setting ></Settings>";
            ReactivateCase reactivateCase = new ReactivateCase(unSecure, secure);
            reactivateCase.Execute(serviceProvider);
        }

        public Entity CustomerActivityEntity2(Guid approvalID)
        {
            Entity customeractivityEntity = new Entity("rel13_customeractivity") { Id = approvalID };
            customeractivityEntity.Attributes.Add("rel13_caseid", "D8778E585B65E811810BC4346BDC7121,C4D4193776234DC590F30C4491EA8A20");
            customeractivityEntity.Attributes.Add("rel13_reactivatecase", true);
            customeractivityEntity.Attributes.Add("rel13_requestupdate", true);
            //approvalEntity.Attributes.Add("ownerid", new EntityReference("D8778E585B65E811810BC4346BDC7121"));
            //approvalEntity.Attributes.Add("regardingobjectid", new Guid("DC778E585B65E811810BC4346BDC7121"));
            //approvalEntity.Attributes.Add("relonl6_actualapprover", new Guid("C4D4193776234DC590F30C4491EA8A20"));
            return customeractivityEntity;
        }


        public Entity RetrieveCaseEntity2(Guid approvalID)
        {
            Entity incidentEntity = new Entity("incident") { Id = approvalID };
            incidentEntity.Attributes.Add("statecode", new OptionSetValue(1));
            return incidentEntity;
        }

        public Entity CustActEntity2(Guid approvalID)
        {
            Entity CustActEntity = new Entity("rel13_customeractivity") { Id = approvalID };
            CustActEntity.Attributes["subject"] = "Customer Activity: Reactivated case";
            CustActEntity.Attributes["rel13_requesttype"] = new OptionSetValue(347870002);
            CustActEntity.Attributes["regardingobjectid"] = new EntityReference("incident", Guid.NewGuid());
            CustActEntity.Attributes["rel13_currentqueue"] = new EntityReference("queue", Guid.NewGuid());
            CustActEntity.Id = Guid.NewGuid();

            return CustActEntity;
        }


        [TestMethod]
        public void Execute_Test3()
        {
            var serviceMock = new Mock<IOrganizationService>();
            var factoryMock = new Mock<IOrganizationServiceFactory>();
            var tracingServiceMock = new Mock<ITracingService>();
            var notificationServiceMock = new Mock<IServiceEndpointNotificationService>();
            var pluginContextMock = new Mock<IPluginExecutionContext>();
            var serviceProviderMock = new Mock<IServiceProvider>();

            var notificationService = notificationServiceMock.Object;

            Guid userId = new Guid("EFFD5189-95FB-E711-810D-FC15B4281C08");
            Guid currentUserid = new Guid("EFFD5189-95FB-E711-810D-FC15B4281C08");
            var rel13_customeractivityId = new Guid("661AEEF4-2F05-EA11-A991-000D3A15A153");//Guid.NewGuid();

            //serviceMock.Setup(s => s.Retrieve(It.IsAny<string>(), It.IsAny<Guid>(), It.IsAny<ColumnSet>()))
            //   .Returns(CustomerActivityEntity(approvalGuid));
            // serviceMock.Setup(s => s.Retrieve("relonl6_internalapproval", approvalGuid, new Microsoft.Xrm.Sdk.Query.ColumnSet("relonl6_approvalstatus", "relonl6_statuschangeddate", "ownerid", "regardingobjectid", "relonl6_actualapprover")))

            IOrganizationService service = serviceMock.Object;
            factoryMock.Setup(t => t.CreateOrganizationService(It.IsAny<Guid>())).Returns(service);
            var factory = factoryMock.Object;
            tracingServiceMock.Setup(t => t.Trace(It.IsAny<string>(), It.IsAny<object[]>())).Callback<string, object[]>((t1, t2) => Console.WriteLine(t1, t2));
            var tracingService = tracingServiceMock.Object;

            //EntityImageCollection imgCollection = new EntityImageCollection();
            //imgCollection.Add("", "");

            ParameterCollection inputParameters = new ParameterCollection();
            inputParameters.Add("Target", CustomerActivityEntity3(rel13_customeractivityId));
            pluginContextMock.Setup(t => t.InputParameters).Returns(inputParameters);
            pluginContextMock.Setup(t => t.UserId).Returns(userId);
            pluginContextMock.Setup(t => t.InitiatingUserId).Returns(currentUserid);

            //finish preparing the plugincontextmock
            pluginContextMock.Setup(t => t.InputParameters).Returns(inputParameters);
            //pluginContextMock.Setup(t => t.OutputParameters).Returns(outputParameters);
            pluginContextMock.Setup(t => t.UserId).Returns(userId);
            pluginContextMock.Setup(t => t.PrimaryEntityName).Returns("rel13_customeractivity");
            var pluginContext = pluginContextMock.Object;

            //set up a serviceprovidermock
            serviceProviderMock.Setup(t => t.GetService(It.Is<Type>(i => i == typeof(IServiceEndpointNotificationService)))).Returns(notificationService);
            serviceProviderMock.Setup(t => t.GetService(It.Is<Type>(i => i == typeof(ITracingService)))).Returns(tracingService);
            serviceProviderMock.Setup(t => t.GetService(It.Is<Type>(i => i == typeof(IOrganizationServiceFactory)))).Returns(factory);
            serviceProviderMock.Setup(t => t.GetService(It.Is<Type>(i => i == typeof(IPluginExecutionContext)))).Returns(pluginContext);
            var serviceProvider = serviceProviderMock.Object;

            // Retrieve and Update Logic
            serviceMock.Setup(s => s.Retrieve(It.IsAny<string>(), It.IsAny<Guid>(), It.IsAny<ColumnSet>()))
              .Returns(RetrieveCaseEntity3(rel13_customeractivityId));
            serviceMock.Setup(s => s.Update(CustActEntity2(rel13_customeractivityId)));
            // Add Logic for Add to Queue and Set State and Send Email


            string unSecure = @"<Settings>" +
                              "<setting name='TraceEnabled'>" +
                                "<value>true</value>" +
                              "</setting>" +
                            "<setting name='ReactivateTemplateID'>" +
                                "<value>EFFD5189-95FB-E711-810D-FC15B4281C08</value>" +
                              "</setting>" +
                            "<setting name='RequestClosureTemplateID'>" +
                                "<value>EFFD5189-95FB-E711-810D-FC15B4281C08</value>" +
                              "</setting>" +
                            "<setting name='RequestUpdateTemplateID'>" +
                                "<value>EFFD5189-95FB-E711-810D-FC15B4281C08</value>" +
                              "</setting>" +
                            "</Settings>";
            string secure = "abc";
            //string unSecure = "<Settings><setting name = 'TraceEnabled'> <value> true </value></setting><setting name = 'ReactivateTemplateID'> <value>EFFD5189 - 95FB - E711 - 810D - FC15B4281C08 </value></setting ><setting name = 'RequestClosureTemplateID'> <value>EFFD5189 - 95FB - E711 - 810D - FC15B4281C08</value> </setting> <setting name = 'RequestUpdateTemplateID'><value>EFFD5189 - 95FB - E711 - 810D - FC15B4281C08 </value></setting ></Settings>";
            ReactivateCase reactivateCase = new ReactivateCase(unSecure, secure);
            reactivateCase.Execute(serviceProvider);
        }


        public Entity CustomerActivityEntity3(Guid approvalID)
        {
            Entity customeractivityEntity = new Entity("rel13_customeractivity") { Id = approvalID };
            customeractivityEntity.Attributes.Add("rel13_caseid", "D8778E585B65E811810BC4346BDC7121,C4D4193776234DC590F30C4491EA8A20");
            customeractivityEntity.Attributes.Add("rel13_reactivatecase", true);
            customeractivityEntity.Attributes.Add("rel13_requestupdate", false);
            //approvalEntity.Attributes.Add("ownerid", new EntityReference("D8778E585B65E811810BC4346BDC7121"));
            //approvalEntity.Attributes.Add("regardingobjectid", new Guid("DC778E585B65E811810BC4346BDC7121"));
            //approvalEntity.Attributes.Add("relonl6_actualapprover", new Guid("C4D4193776234DC590F30C4491EA8A20"));
            return customeractivityEntity;
        }

        public Entity RetrieveCaseEntity3(Guid approvalID)
        {
            Entity incidentEntity = new Entity("incident") { Id = approvalID };
            incidentEntity.Attributes.Add("statecode", new OptionSetValue(0));
            return incidentEntity;
        }
    }
}
